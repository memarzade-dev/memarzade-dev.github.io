export * from './InsertFinalNewline'
export * from './PreSaveTransformation'
export * from './SetEndOfLine'
export * from './TrimTrailingWhitespace'
