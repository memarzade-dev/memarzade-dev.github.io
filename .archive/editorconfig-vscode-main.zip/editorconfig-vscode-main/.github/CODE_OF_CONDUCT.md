### Please refer to the [EditorConfig Code of Conduct](https://github.com/editorconfig/editorconfig/blob/main/CODE_OF_CONDUCT.md)
