# Typography System

**System:** PixelPulse × macOS Sequoia Game Store  
**Version:** 1.0.0  
**Purpose:** Complete typography scale, font usage, and sizing guidelines

---

## 🎯 Typography Philosophy

### Core Principle: SF Pro System + Semantic HTML

**Critical Rule**: **NEVER use Tailwind typography classes** (`text-2xl`, `font-bold`, `leading-tight`)

**Why?** We have automatic typography in `/styles/globals.css` that applies to semantic HTML elements.

---

## 📐 Font Stack

### Primary Fonts

```css
font-family: -apple-system, BlinkMacSystemFont, 
             "SF Pro Display", "SF Pro Text", 
             system-ui, sans-serif;
```

**SF Pro Display**: Headings, large text  
**SF Pro Text**: Body text, UI elements  
**System fallback**: Ensures native feel on all platforms

### Font Rendering

```css
-webkit-font-smoothing: antialiased;
-moz-osx-font-smoothing: grayscale;
```

Applied globally for crisp text rendering.

---

## 📏 Type Scale (CSS Variables)

### Defined in `globals.css` (Tailwind v4)

```css
--text-xs: 0.75rem;      /* 12px */
--text-sm: 0.875rem;     /* 14px */
--text-base: 1rem;       /* 16px */
--text-lg: 1.125rem;     /* 18px */
--text-xl: 1.25rem;      /* 20px */
--text-2xl: 1.5rem;      /* 24px */
--text-3xl: 1.875rem;    /* 30px */
--text-4xl: 2.25rem;     /* 36px */
```

**Base Size**: `--font-size: 16px` (set on `:root`)

---

## ⚖️ Font Weights

### Available Weights

```css
--font-weight-normal: 400;   /* Body text */
--font-weight-medium: 500;   /* Labels, buttons */
```

**Missing Weights** (add if needed):
```css
--font-weight-semibold: 600; /* Subheadings */
--font-weight-bold: 700;     /* Emphasis */
```

**Usage**:
```tsx
// ✅ Correct
style={{ fontWeight: 'var(--font-weight-medium)' }}

// ❌ Wrong
className="font-bold"
```

---

## 🏷️ Semantic HTML Typography (Auto-Applied)

### Automatic Styles from `globals.css`

**These apply automatically — DON'T override with Tailwind classes:**

```css
h1 {
  font-size: var(--text-2xl);  /* 24px */
  font-weight: var(--font-weight-medium);
  line-height: 1.5;
}

h2 {
  font-size: var(--text-xl);   /* 20px */
  font-weight: var(--font-weight-medium);
  line-height: 1.5;
}

h3 {
  font-size: var(--text-lg);   /* 18px */
  font-weight: var(--font-weight-medium);
  line-height: 1.5;
}

h4 {
  font-size: var(--text-base); /* 16px */
  font-weight: var(--font-weight-medium);
  line-height: 1.5;
}

p, input {
  font-size: var(--text-base);
  font-weight: var(--font-weight-normal);
  line-height: 1.5;
}

label, button {
  font-size: var(--text-base);
  font-weight: var(--font-weight-medium);
  line-height: 1.5;
}
```

**Usage**:
```tsx
// ✅ Correct: Let semantic HTML handle styling
<h1>Dashboard</h1>
<p>Welcome back!</p>

// ❌ Wrong: Overriding with Tailwind
<h1 className="text-4xl font-bold">Dashboard</h1>
```

---

## 📊 Typography Hierarchy

### When to Use Each Level

| Element | Size | Weight | Use Case | Example |
|---------|------|--------|----------|---------|
| Page Title | Custom large | 600 | PageHeader | "Dashboard" (28px inline) |
| `<h1>` | 24px | 500 | Section headings | Revenue Overview |
| `<h2>` | 20px | 500 | Subsections | Top Selling Games |
| `<h3>` | 18px | 500 | Card titles | Card header |
| `<h4>` | 16px | 500 | Minor headings | Metadata labels |
| `<p>` | 16px | 400 | Body text | Descriptions |
| `<label>` | 16px | 500 | Form labels | Input labels |
| `<button>` | 16px | 500 | Button text | CTA text |
| Small text | 14px | 400 | Metadata | Dates, counts |
| Tiny text | 12px | 400 | Fine print | Disclaimers |

---

## 🎨 Typography Patterns

### Pattern 1: Page Title (Custom Size)

```tsx
<h1 
  className="tracking-tight"
  style={{ 
    color: 'var(--txt-primary)',
    fontWeight: 600,
    fontSize: '28px',  // Custom, larger than h1 default
  }}
>
  Dashboard
</h1>
```

**Used in**: `PageHeader` component

---

### Pattern 2: Card Title

```tsx
<h3
  className="truncate mb-1"
  style={{
    fontSize: '16px',  // Or use var(--text-base)
    fontWeight: 600,
    color: 'var(--txt-primary)',
  }}
>
  {game.title}
</h3>
```

**Used in**: `GameCard`, `AppCard`, etc.

---

### Pattern 3: Body Text

```tsx
<p
  className="truncate"
  style={{
    fontSize: '13px',  // Slightly smaller than base
    color: 'var(--txt-tertiary)',
  }}
>
  {game.subtitle}
</p>
```

**Used in**: Card subtitles, descriptions

---

### Pattern 4: Metadata Text

```tsx
<span
  style={{
    fontSize: '13px',
    color: 'var(--txt-secondary)',
    fontWeight: 500,
  }}
>
  {game.genre}
</span>
```

**Used in**: Labels, categories, genres

---

### Pattern 5: Price/Number Display

```tsx
<span
  className="tabular-nums"
  style={{
    fontSize: '18px',
    fontWeight: 700,
    color: 'var(--txt-primary)',
  }}
>
  {formatPrice(game.price)}
</span>
```

**Special**: `tabular-nums` class for aligned number columns

---

## 🔢 Tabular Numerals

### What Are Tabular Numerals?

Monospaced number glyphs that align vertically in tables/lists.

**When to Use**:
- Prices
- Scores/ratings
- Statistics
- Any columnar numbers

**How to Use**:
```tsx
<span className="tabular-nums">
  $29.99
</span>
```

**Examples in Codebase**:
- `GameCard.tsx` line 86, 127 (rating, price)
- `StatCard` components
- Dashboard metrics

---

## 🎯 Typography Rules

### Rule 1: NO Tailwind Typography Classes

❌ **NEVER**:
```tsx
<h1 className="text-2xl font-bold leading-tight">
<p className="text-sm text-gray-400">
```

✅ **ALWAYS**:
```tsx
<h1>Title</h1>  {/* Auto-styled */}
<p style={{ fontSize: '14px', color: 'var(--txt-secondary)' }}>
```

---

### Rule 2: Use Semantic HTML

✅ **Correct**:
```tsx
<h2>Section Title</h2>
<p>Body content</p>
<label>Input Label</label>
```

❌ **Wrong**:
```tsx
<div className="text-xl font-semibold">Section Title</div>
<div>Body content</div>
<span>Input Label</span>
```

---

### Rule 3: Inline Styles for Custom Sizes

When default semantic styles don't fit:

```tsx
<h2 style={{ fontSize: '22px', fontWeight: 600 }}>
  Custom Heading
</h2>
```

This is **allowed** because:
- Tailwind text classes are forbidden
- Custom sizes sometimes needed
- Design tokens used for consistency

---

### Rule 4: Color Always Uses Tokens

✅ **Correct**:
```tsx
style={{ color: 'var(--txt-primary)' }}
style={{ color: 'var(--txt-secondary)' }}
```

❌ **Wrong**:
```tsx
style={{ color: '#F4F7FF' }}
className="text-white"
```

---

## 📱 Responsive Typography

### Mobile-First Scaling

**Pattern**: Smaller on mobile, larger on desktop

```tsx
<h1 className="text-2xl lg:text-4xl">
  {/* This VIOLATES the rule — DON'T DO THIS */}
</h1>

// Instead, use inline styles:
<h1 style={{ 
  fontSize: isMobile ? '24px' : '32px',
  fontWeight: 600 
}}>
```

**OR** use semantic HTML + CSS media queries (preferred):
```css
/* In component CSS or globals */
.page-title {
  font-size: 24px;
}

@media (min-width: 1024px) {
  .page-title {
    font-size: 32px;
  }
}
```

---

## 🎨 Typography Recipes

### Recipe: Card Header

```tsx
<div>
  <h3
    className="truncate mb-1"
    style={{
      fontSize: '16px',
      fontWeight: 600,
      color: 'var(--txt-primary)',
    }}
  >
    {title}
  </h3>
  <p
    className="truncate"
    style={{
      fontSize: '13px',
      color: 'var(--txt-tertiary)',
    }}
  >
    {subtitle}
  </p>
</div>
```

---

### Recipe: Page Header

```tsx
<div>
  <h1
    className="tracking-tight"
    style={{
      fontSize: '28px',
      fontWeight: 600,
      color: 'var(--txt-primary)',
    }}
  >
    {title}
  </h1>
  {subtitle && (
    <p style={{ 
      fontSize: '14px', 
      color: 'var(--txt-secondary)',
      marginTop: '4px'
    }}>
      {subtitle}
    </p>
  )}
</div>
```

---

### Recipe: Stat Display

```tsx
<div>
  <div
    className="tabular-nums"
    style={{
      fontSize: '32px',
      fontWeight: 700,
      color: 'var(--txt-primary)',
    }}
  >
    $62,450
  </div>
  <div
    style={{
      fontSize: '14px',
      color: 'var(--txt-secondary)',
      marginTop: '4px',
    }}
  >
    Total Revenue
  </div>
</div>
```

---

## 🚫 Common Mistakes

### ❌ Mistake 1: Using Tailwind Text Classes

```tsx
// WRONG
<h1 className="text-4xl font-bold">Title</h1>

// CORRECT
<h1>Title</h1>  // Uses auto-applied styles
// OR
<h1 style={{ fontSize: '36px', fontWeight: 700 }}>Title</h1>
```

---

### ❌ Mistake 2: Hardcoding Colors

```tsx
// WRONG
<p className="text-gray-400">Text</p>
<p style={{ color: '#B9C2D0' }}>Text</p>

// CORRECT
<p style={{ color: 'var(--txt-secondary)' }}>Text</p>
```

---

### ❌ Mistake 3: Not Using Tabular Numerals

```tsx
// WRONG: Numbers won't align
<div style={{ fontSize: '18px' }}>
  $29.99
</div>

// CORRECT: Numbers align
<div className="tabular-nums" style={{ fontSize: '18px' }}>
  $29.99
</div>
```

---

## ✅ Typography Checklist

Before completing any component with text:

- [ ] NO Tailwind typography classes used
- [ ] Semantic HTML used where appropriate
- [ ] Custom sizes use inline styles with CSS variables when possible
- [ ] Colors use design tokens (never hardcoded)
- [ ] `tabular-nums` applied to prices/metrics
- [ ] Font weights use CSS variables
- [ ] Line heights appropriate for readability
- [ ] Text contrast meets WCAG AA (see colors.md)

---

## 📚 Related Documentation

- **Color Tokens**: `guidelines/design-tokens/colors.md` (for text colors)
- **Component Catalog**: `guidelines/overview-components.md`
- **Master Guidelines**: `guidelines/Guidelines.md`

---

**Remember: Let semantic HTML handle default typography. Override only when necessary with inline styles using CSS variables. NEVER use Tailwind typography classes.**
