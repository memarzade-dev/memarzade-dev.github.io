# Spacing & Layout System

**System:** PixelPulse × macOS Sequoia Game Store  
**Version:** 1.0.0  
**Purpose:** Spacing scale, layout patterns, and grid system

---

## 📐 Spacing Philosophy

### 8px Base Unit

All spacing uses multiples of **8px** for visual rhythm and consistency.

**Scale**: 4px (half unit) → 8px → 16px → 24px → 32px → 48px → 64px

---

## 📏 Tailwind Spacing Scale

### Standard Scale (Use These)

| Class | Value | Use Case |
|-------|-------|----------|
| `gap-2` | 8px | Tight spacing (tags, chips) |
| `gap-4` | 16px | Card grids, button groups |
| `gap-6` | 24px | Section spacing |
| `gap-8` | 32px | Major sections |
| `p-4` | 16px | Small cards, buttons |
| `p-6` | 24px | Standard cards |
| `p-8` | 32px | Page containers |
| `px-8 py-6` | 32px / 24px | Page padding (standard) |
| `space-y-4` | 16px | List item spacing |
| `space-y-6` | 24px | Component spacing |
| `space-y-8` | 32px | Section spacing |

---

## 🎯 Common Spacing Patterns

### Page Container Padding

```tsx
<main className="flex-1 overflow-y-auto">
  <div className="px-8 py-6 space-y-8">
    {/* Page content */}
  </div>
</main>
```

**Breakdown**:
- `px-8`: 32px horizontal padding
- `py-6`: 24px vertical padding
- `space-y-8`: 32px between sections

---

### Card Padding

```tsx
// Standard card
<div className="p-6 rounded-2xl">

// Large card
<div className="p-8 rounded-2xl">

// Compact card
<div className="p-4 rounded-xl">
```

---

### Grid Gaps

```tsx
// Standard grid
<div className="grid grid-cols-3 gap-6">

// Tight grid
<div className="grid grid-cols-4 gap-4">

// Loose grid
<div className="grid grid-cols-2 gap-8">
```

---

### Vertical Stacking

```tsx
// Standard sections
<div className="space-y-8">
  <Section1 />
  <Section2 />
</div>

// Compact sections
<div className="space-y-4">
  <Item1 />
  <Item2 />
</div>
```

---

## 🏗️ Grid System

### Responsive Grid Pattern

**Standard Pattern**:
```tsx
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
```

**Breakpoints**:
- Base (mobile): 1 column
- `md` (768px+): 2 columns
- `lg` (1024px+): 3 columns
- `xl` (1280px+): 4 columns

---

### Common Grid Configurations

| Layout | Classes | Use Case |
|--------|---------|----------|
| Single column | `grid-cols-1` | Mobile, narrow content |
| Two column | `grid-cols-1 lg:grid-cols-2` | Dashboard charts |
| Three column | `grid-cols-1 md:grid-cols-2 lg:grid-cols-3` | Game catalog |
| Four column | `grid-cols-2 md:grid-cols-3 lg:grid-cols-4` | Dense grids |
| Auto-fit | `grid-cols-[repeat(auto-fit,minmax(280px,1fr))]` | Flexible cards |

---

## 📐 Layout Dimensions

### Fixed Dimensions

```css
/* Sidebar */
--sidebar-width: 240px;
--sidebar-collapsed: 80px;

/* Header */
--header-height: 72px;

/* Card Widths */
--card-width-sm: 240px;
--card-width-md: 280px;
--card-width-lg: 320px;
```

**Usage**:
```tsx
// GameCard.tsx (hardcoded — should be variable)
style={{ width: '280px' }}

// Better approach:
style={{ width: 'var(--card-width-md)' }}
```

---

### Container Max-Widths

**Currently**: No max-width constraints (full-width layout)

**Future** (if needed):
```css
--container-sm: 640px;
--container-md: 768px;
--container-lg: 1024px;
--container-xl: 1280px;
```

---

## 🎨 Spacing Recipes

### Recipe: Card Layout

```tsx
<div 
  className="p-6 rounded-2xl space-y-4"
  style={{ background: 'var(--bg-panel)' }}
>
  <h3>Card Title</h3>
  <p>Card content</p>
  <div className="flex gap-4">
    <button>Action 1</button>
    <button>Action 2</button>
  </div>
</div>
```

---

### Recipe: Page Layout

```tsx
<>
  <PageHeader title="Page Title" />
  <main className="flex-1 overflow-y-auto">
    <div className="px-8 py-6 space-y-8">
      <section className="space-y-6">
        <h2>Section 1</h2>
        <div className="grid grid-cols-3 gap-6">
          {/* Cards */}
        </div>
      </section>
      
      <section className="space-y-6">
        <h2>Section 2</h2>
        {/* Content */}
      </section>
    </div>
  </main>
</>
```

---

### Recipe: Button Group

```tsx
<div className="flex items-center gap-4">
  <button>Primary</button>
  <button>Secondary</button>
  <button>Tertiary</button>
</div>
```

---

## 📏 Radius System

### Border Radius Tokens

```css
--radius: 0.625rem;  /* 10px - base */
--radius-sm: calc(var(--radius) - 4px);  /* 6px */
--radius-md: calc(var(--radius) - 2px);  /* 8px */
--radius-lg: var(--radius);              /* 10px */
--radius-xl: calc(var(--radius) + 4px);  /* 14px */

/* Custom (not in tokens yet) */
--radius-card: 16px;  /* Card corners */
```

**Tailwind Classes**:
- `rounded-lg` → 10px (var(--radius))
- `rounded-xl` → 12px
- `rounded-2xl` → 16px
- `rounded-full` → 9999px (pills, circles)

---

### When to Use Each Radius

| Radius | Use Case |
|--------|----------|
| `rounded-lg` (10px) | Buttons, inputs |
| `rounded-xl` (12px) | Small cards |
| `rounded-2xl` (16px) | Standard cards |
| `rounded-3xl` (24px) | Large cards, modals |
| `rounded-full` | Pills, badges, avatars |

**Example**:
```tsx
<div className="p-6 rounded-2xl">  {/* 16px corners */}
  <button className="rounded-xl">  {/* 12px corners */}
    Click me
  </button>
</div>
```

---

## 🚫 Spacing Anti-Patterns

### ❌ Random Spacing Values

```tsx
// WRONG: Random values
<div className="p-5 gap-3 space-y-7">

// CORRECT: Use scale
<div className="p-6 gap-4 space-y-8">
```

---

### ❌ Inconsistent Padding

```tsx
// WRONG: Different padding on same-level cards
<Card className="p-4" />
<Card className="p-6" />

// CORRECT: Consistent padding
<Card className="p-6" />
<Card className="p-6" />
```

---

### ❌ No Vertical Rhythm

```tsx
// WRONG: Uneven spacing
<Section1 />
<div className="mt-6" />
<Section2 />
<div className="mt-4" />
<Section3 />

// CORRECT: Consistent rhythm
<div className="space-y-8">
  <Section1 />
  <Section2 />
  <Section3 />
</div>
```

---

## ✅ Spacing Checklist

- [ ] All spacing uses 8px scale (4, 8, 16, 24, 32...)
- [ ] Page padding is `px-8 py-6`
- [ ] Major sections use `space-y-8`
- [ ] Cards use `p-6` or `p-8`
- [ ] Grids use `gap-4` or `gap-6`
- [ ] Border radius matches component size
- [ ] No random spacing values

---

## 📚 Related Documentation

- **Layout Patterns**: `guidelines/overview-system-design.md`
- **Radius**: `guidelines/design-tokens/radius.md` (when created)
- **Component Catalog**: `guidelines/overview-components.md`

---

**Always use the 8px spacing scale. When in doubt, use gap-6 (24px) for comfortable spacing.**
