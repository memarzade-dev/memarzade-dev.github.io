# Blur & Glassmorphism Effects

**System:** PixelPulse × macOS Sequoia Game Store  
**Version:** 1.0.0  
**Purpose:** Backdrop blur system and glassmorphic effect implementation

---

## 🌫️ Blur Philosophy

**Glassmorphism** is the signature visual style of this system. It combines:
1. Semi-transparent backgrounds
2. Backdrop blur effects
3. Subtle borders
4. Layered depth

This creates the iconic "frosted glass" aesthetic of macOS interfaces.

---

## 📐 Blur Tokens

### Defined in `globals.css`

```css
/* Blur Effects */
--blur-xs: blur(4px);
--blur-sm: blur(8px);
--blur-md: blur(16px);
--blur-lg: blur(24px);
--blur-xl: blur(40px);

/* Combined Surface Effect */
--surface-blur: blur(24px);  /* Alias for --blur-lg */
```

---

## 🎨 Blur Scale Usage

### When to Use Each Blur

| Blur Level | Strength | Use Case | Components |
|------------|----------|----------|------------|
| `--blur-xs` | Minimal | Subtle overlays | Hover states |
| `--blur-sm` | Light | Background elements | Decorative |
| `--blur-md` | Standard | Cards, panels | GameCard, Sidebar |
| `--blur-lg` | Strong | Headers, modals | PageHeader, SearchModal |
| `--blur-xl` | Maximum | Full overlays | Modal backgrounds |

---

## 🏗️ Glassmorphic Surface Pattern (STANDARD)

### The Complete Glass Effect

**ALL glassmorphic surfaces MUST use these 3 properties:**

```tsx
style={{
  background: 'var(--surface-glass)',        // 1. Semi-transparent BG
  backdropFilter: 'var(--blur-md)',          // 2. Blur
  border: '1px solid var(--border-glass)',   // 3. Subtle border
}}
```

**Why all 3?**
- Background: Provides base color
- Blur: Creates frosted glass effect
- Border: Defines edges, adds polish

---

## 🎯 Glass Surface Patterns

### Pattern 1: Standard Glass Card

```tsx
<div
  className="p-6 rounded-2xl"
  style={{
    background: 'var(--surface-glass)',
    backdropFilter: 'var(--blur-md)',
    border: '1px solid var(--border-glass)',
  }}
>
  Glass card content
</div>
```

**Used in**: Custom glassmorphic components

---

### Pattern 2: Elevated Glass Panel

```tsx
<div
  className="p-8 rounded-3xl"
  style={{
    background: 'var(--surface-glass-light)',  // More opaque
    backdropFilter: 'var(--blur-lg)',          // Stronger blur
    border: '1px solid var(--border-glass)',
    boxShadow: 'var(--shadow-lg)',
  }}
>
  Important panel content
</div>
```

**Used in**: Modals, important overlays

---

### Pattern 3: Header Glass

```tsx
<header
  className="sticky top-0 z-30"
  style={{
    background: 'var(--surface-glass)',
    backdropFilter: 'var(--blur-md) saturate(1.1)',  // Extra saturation
    border-bottom: '1px solid var(--border-glass)',
  }}
>
  Navigation content
</header>
```

**Extra Effect**: `saturate(1.1)` enhances colors behind glass

**Used in**: AppSidebar, PageHeader (with saturate)

---

### Pattern 4: Modal Overlay Background

```tsx
<div
  className="fixed inset-0 z-40"
  style={{
    background: 'rgba(14, 15, 19, 0.6)',      // Darkened overlay
    backdropFilter: 'var(--blur-xl)',         // Heavy blur
  }}
>
  {/* Modal content on top */}
</div>
```

**Effect**: Blurs and darkens everything behind modal

---

## 🌈 Advanced Blur Techniques

### Technique 1: Layered Blur (Depth)

```tsx
{/* Background layer */}
<div style={{
  background: 'var(--bg-base)',
}}>
  {/* Middle layer with light blur */}
  <div style={{
    background: 'var(--surface-glass)',
    backdropFilter: 'var(--blur-sm)',
  }}>
    {/* Top layer with strong blur */}
    <div style={{
      background: 'var(--surface-glass-light)',
      backdropFilter: 'var(--blur-md)',
    }}>
      Content
    </div>
  </div>
</div>
```

**Effect**: Creates visual depth through layered transparency

---

### Technique 2: Blur + Saturate (Enhanced Glass)

```tsx
style={{
  backdropFilter: 'var(--blur-md) saturate(1.2) brightness(1.05)',
}}
```

**Filters**:
- `blur()`: Frosted glass effect
- `saturate()`: Enhance colors (1.1–1.3)
- `brightness()`: Slightly lighten (1.05–1.1)

**Used in**: Premium glass surfaces, headers

---

### Technique 3: Gradient Glass

```tsx
style={{
  background: `
    linear-gradient(135deg, 
      rgba(111, 125, 255, 0.15), 
      rgba(155, 111, 255, 0.15)
    )
  `,
  backdropFilter: 'var(--blur-md)',
  border: '1px solid var(--border-glass)',
}}
```

**Effect**: Subtle brand-colored glass

---

## 🎨 Blur Recipes

### Recipe: Search Input (Glass)

```tsx
<div
  className="flex items-center gap-3 px-4 py-2.5 rounded-full"
  style={{
    background: 'rgba(255, 255, 255, 0.04)',
    border: '1px solid var(--border-glass)',
    backdropFilter: 'var(--blur-sm)',
  }}
>
  <Search size={18} />
  <input 
    type="text" 
    placeholder="Search..."
    className="flex-1 bg-transparent"
  />
</div>
```

---

### Recipe: Badge (Glass Pill)

```tsx
<span
  className="px-3 py-1.5 rounded-lg backdrop-blur-xl"
  style={{
    background: 'rgba(111, 125, 255, 0.2)',
    border: '1px solid rgba(111, 125, 255, 0.4)',
  }}
>
  New
</span>
```

**Note**: `backdrop-blur-xl` is Tailwind class (equivalent to `var(--blur-xl)`)

---

### Recipe: Floating Panel

```tsx
<div
  className="absolute top-full mt-2 p-4 rounded-xl"
  style={{
    background: 'var(--surface-glass-light)',
    backdropFilter: 'var(--blur-lg)',
    border: '1px solid var(--border-glass)',
    boxShadow: 'var(--shadow-lg)',
  }}
>
  Panel content
</div>
```

---

## ⚡ Performance Considerations

### Blur Performance Impact

**Backdrop filters are expensive** — use strategically:

✅ **Good Use**:
- Headers (1 element)
- Modals (few at a time)
- Cards (limit to ~20 visible)

❌ **Bad Use**:
- 100+ cards with blur on one page
- Animated elements with blur
- Rapidly changing blur values

---

### Optimization Tips

**1. Use `will-change` for Animated Glass**:
```tsx
style={{
  backdropFilter: 'var(--blur-md)',
  willChange: 'backdrop-filter',  // GPU acceleration
}}
```

**2. Reduce Blur on Lower-End Devices**:
```tsx
const blurLevel = isLowEndDevice ? 'var(--blur-sm)' : 'var(--blur-md)';
```

**3. Disable Blur on Scroll (If Performance Issue)**:
```tsx
const [isScrolling, setIsScrolling] = useState(false);

style={{
  backdropFilter: isScrolling ? 'none' : 'var(--blur-md)',
}}
```

---

## 🚫 Blur Anti-Patterns

### ❌ Blur Without Background

```tsx
// WRONG: Blur does nothing without semi-transparent background
<div style={{
  background: 'var(--bg-panel)',  // Solid, not transparent
  backdropFilter: 'var(--blur-md)',  // No effect!
}}>
```

**Fix**: Use transparent/translucent background

---

### ❌ Blur Without Border

```tsx
// WRONG: Edges undefined, looks unfinished
<div style={{
  background: 'var(--surface-glass)',
  backdropFilter: 'var(--blur-md)',
  // Missing border!
}}>
```

**Fix**: Always add `border: '1px solid var(--border-glass)'`

---

### ❌ Too Much Blur

```tsx
// WRONG: Excessive blur looks muddy
<div style={{
  backdropFilter: 'blur(100px)',  // Way too much
}}>
```

**Fix**: Stick to token scale (max `--blur-xl` / 40px)

---

### ❌ Blur on Non-Glass Surfaces

```tsx
// WRONG: Solid card doesn't need blur
<div style={{
  background: 'var(--bg-panel)',  // Solid
  backdropFilter: 'var(--blur-md)',  // Unnecessary
}}>
```

**Fix**: Use blur only for glassmorphic surfaces

---

## 🌓 Blur in Dark UI

### Why Blur Works in Dark Mode

Dark backgrounds + blur create:
1. Depth through layering
2. Focus on foreground
3. Premium aesthetic
4. Content hierarchy

**Our system is optimized for dark mode**, so blur effects look best.

---

## 📐 Blur + Other Effects

### Common Combinations

**Blur + Shadow**:
```tsx
style={{
  backdropFilter: 'var(--blur-md)',
  boxShadow: 'var(--shadow-sm)',
}}
```

**Blur + Gradient**:
```tsx
style={{
  background: 'var(--gradient-brand)',
  backdropFilter: 'var(--blur-sm)',  // Subtle blur over gradient
}}
```

**Blur + Saturate**:
```tsx
style={{
  backdropFilter: 'var(--blur-md) saturate(1.2)',
}}
```

---

## ✅ Glassmorphism Checklist

When creating glass surfaces:

- [ ] Background is semi-transparent (`rgba` or `var(--surface-glass)`)
- [ ] `backdropFilter` applied with blur token
- [ ] Border added (`1px solid var(--border-glass)`)
- [ ] Shadow added if elevated
- [ ] Performance considered (not too many at once)
- [ ] Works on various backgrounds (test with content behind)

---

## 📚 Related Documentation

- **Color Tokens**: `guidelines/design-tokens/colors.md` (glass surface colors)
- **Shadows**: `guidelines/design-tokens/shadows.md` (elevation)
- **Component Examples**: `guidelines/overview-components.md`

---

**Glassmorphism requires 3 properties: transparent background + backdrop blur + border. Never skip any of these for authentic glass effect.**
