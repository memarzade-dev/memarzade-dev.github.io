# Shadow & Elevation System

**System:** PixelPulse × macOS Sequoia Game Store  
**Version:** 1.0.0  
**Purpose:** Shadow tokens and elevation hierarchy

---

## 🌑 Shadow Philosophy

Shadows create **depth** and **visual hierarchy** in the glassmorphic interface. Combined with blur effects, they enhance the layered aesthetic.

---

## 📐 Shadow Tokens

### Defined in `globals.css`

```css
/* Shadow System */
--shadow-xs: 0 1px 2px rgba(0, 0, 0, 0.25);
--shadow-sm: 0 2px 8px rgba(0, 0, 0, 0.3);
--shadow-md: 0 4px 16px rgba(0, 0, 0, 0.35);
--shadow-lg: 0 8px 32px rgba(0, 0, 0, 0.4);
--shadow-xl: 0 16px 48px rgba(0, 0, 0, 0.45);
--shadow-glow: 0 0 24px rgba(111, 125, 255, 0.4);
```

---

## 🎨 Shadow Usage

### When to Use Each Shadow

| Shadow | Elevation | Use Case | Components |
|--------|-----------|----------|------------|
| `--shadow-xs` | Minimal | Hover states, subtle depth | Buttons on hover |
| `--shadow-sm` | Low | Cards, tiles | GameCard, StatCard |
| `--shadow-md` | Medium | Raised cards, panels | Modal content |
| `--shadow-lg` | High | Floating elements | Dropdowns, tooltips |
| `--shadow-xl` | Highest | Modals, overlays | AppDetailModal |
| `--shadow-glow` | Special | Brand glow effect | Primary buttons, hover |

---

## 🏗️ Elevation Hierarchy

### Visual Layers (Bottom to Top)

```
1. Base Background         → No shadow
2. Cards/Panels            → --shadow-sm
3. Raised Cards            → --shadow-md
4. Floating Panels         → --shadow-lg
5. Modals/Overlays         → --shadow-xl
```

---

## 🎯 Shadow Patterns

### Pattern 1: Standard Card

```tsx
<div
  className="p-6 rounded-2xl"
  style={{
    background: 'var(--bg-panel)',
    boxShadow: 'var(--shadow-sm)',
  }}
>
  Card content
</div>
```

**Used in**: GameCard, AppCard, StatCard

---

### Pattern 2: Hover Glow Effect

```tsx
<div className="group relative">
  {/* Card content */}
  <div
    className="p-6 rounded-2xl transition-all"
    style={{
      background: 'var(--bg-panel)',
      boxShadow: 'var(--shadow-sm)',
    }}
  >
    Content
  </div>

  {/* Glow on hover */}
  <div
    className="absolute -inset-0.5 rounded-[calc(var(--radius-card)+2px)] opacity-0 group-hover:opacity-100 transition-opacity duration-300"
    style={{
      background: 'var(--gradient-brand)',
      filter: 'blur(12px)',
      zIndex: -1,
    }}
  />
</div>
```

**Effect**: Card glows with brand gradient on hover

---

### Pattern 3: Modal

```tsx
<div
  className="fixed inset-0 z-50 flex items-center justify-center"
  style={{
    background: 'rgba(14, 15, 19, 0.8)',
    backdropFilter: 'var(--blur-lg)',
  }}
>
  <div
    className="w-full max-w-4xl p-8 rounded-3xl"
    style={{
      background: 'var(--surface-glass-light)',
      backdropFilter: 'var(--blur-xl)',
      border: '1px solid var(--border-glass)',
      boxShadow: 'var(--shadow-xl)',
    }}
  >
    Modal content
  </div>
</div>
```

---

### Pattern 4: Floating Dropdown

```tsx
<div
  className="absolute top-full mt-2 rounded-xl"
  style={{
    background: 'var(--bg-panel)',
    border: '1px solid var(--border-glass)',
    boxShadow: 'var(--shadow-lg)',
    backdropFilter: 'var(--blur-md)',
  }}
>
  Dropdown items
</div>
```

---

## 🌈 Special Effects

### Glow Shadow

**Token**: `--shadow-glow: 0 0 24px rgba(111, 125, 255, 0.4);`

**Usage**: Brand-colored glow for emphasis

**Example**:
```tsx
<button
  style={{
    background: 'var(--gradient-brand)',
    boxShadow: 'var(--shadow-glow)',
  }}
>
  Get Game
</button>
```

**Also used for**: Hover glows (via blur filter, not shadow directly)

---

## 🎨 Shadow Recipes

### Recipe: Card with Hover Elevation

```tsx
<div
  className="p-6 rounded-2xl transition-all hover:scale-[1.02]"
  style={{
    background: 'var(--bg-panel)',
    boxShadow: 'var(--shadow-sm)',
    transition: 'box-shadow 220ms ease-out, transform 220ms ease-out',
  }}
  onMouseEnter={(e) => {
    e.currentTarget.style.boxShadow = 'var(--shadow-md)';
  }}
  onMouseLeave={(e) => {
    e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
  }}
>
  Hover me
</div>
```

**OR** use inline hover (simpler):
```tsx
<div
  className="p-6 rounded-2xl transition-all hover:scale-[1.02]"
  style={{
    background: 'var(--bg-panel)',
    boxShadow: 'var(--shadow-sm)',
  }}
>
  {/* Shadow elevation handled by scale */}
</div>
```

---

### Recipe: Layered Shadow (Deep Elevation)

```tsx
style={{
  boxShadow: `
    var(--shadow-md),
    0 0 0 1px var(--border-glass)
  `
}}
```

**Effect**: Combines shadow with border for enhanced depth

---

## 📏 Shadow Intensity Guidelines

### When to Use Subtle vs Deep Shadows

**Subtle** (`--shadow-xs`, `--shadow-sm`):
- Resting state cards
- Low-emphasis elements
- Background elements

**Medium** (`--shadow-md`):
- Active elements
- Interactive cards
- Section containers

**Deep** (`--shadow-lg`, `--shadow-xl`):
- Modals
- Floating menus
- Critical overlays

**Glow** (`--shadow-glow`):
- Primary CTAs
- Active states
- Brand highlights

---

## 🚫 Shadow Anti-Patterns

### ❌ Over-Shadowing

```tsx
// WRONG: Too many deep shadows
<Card style={{ boxShadow: 'var(--shadow-xl)' }} />
<Card style={{ boxShadow: 'var(--shadow-xl)' }} />
<Card style={{ boxShadow: 'var(--shadow-xl)' }} />

// CORRECT: Reserve deep shadows for emphasis
<Card style={{ boxShadow: 'var(--shadow-sm)' }} />
<Card style={{ boxShadow: 'var(--shadow-sm)' }} />
<Modal style={{ boxShadow: 'var(--shadow-xl)' }} />
```

---

### ❌ Inconsistent Elevation

```tsx
// WRONG: Random shadow values
<div style={{ boxShadow: '0 2px 10px rgba(0,0,0,0.2)' }} />

// CORRECT: Use tokens
<div style={{ boxShadow: 'var(--shadow-sm)' }} />
```

---

### ❌ Shadows on Transparent Surfaces

```tsx
// WRONG: Shadow on glassmorphic surface looks off
<div style={{
  background: 'var(--surface-glass)',
  boxShadow: 'var(--shadow-lg)',  // Too heavy
}} />

// CORRECT: Use lighter shadow
<div style={{
  background: 'var(--surface-glass)',
  boxShadow: 'var(--shadow-sm)',  // Subtle
  border: '1px solid var(--border-glass)',
}} />
```

---

## 🌓 Dark Mode Considerations

### Shadow Visibility in Dark UI

**Current shadows use black** (`rgba(0, 0, 0, ...)`) which works well on dark backgrounds.

**If needed** (not currently implemented):
```css
/* Lighter shadows for dark mode */
.dark {
  --shadow-sm: 0 2px 8px rgba(0, 0, 0, 0.5);  /* Darker for more contrast */
}
```

Our dark-first design already optimized, no changes needed.

---

## ✅ Shadow Checklist

- [ ] All shadows use tokens (no hardcoded)
- [ ] Elevation matches visual hierarchy
- [ ] Modals use `--shadow-xl`
- [ ] Cards use `--shadow-sm`
- [ ] Glow effects use `--shadow-glow` or blur
- [ ] Hover states increase elevation subtly
- [ ] Glassmorphic surfaces use light shadows

---

## 📚 Related Documentation

- **Blur Effects**: `guidelines/design-tokens/blur.md`
- **Colors**: `guidelines/design-tokens/colors.md` (for shadow colors)
- **Component Patterns**: `guidelines/overview-components.md`

---

**Shadows create depth. Use them strategically to guide attention and reinforce visual hierarchy.**
