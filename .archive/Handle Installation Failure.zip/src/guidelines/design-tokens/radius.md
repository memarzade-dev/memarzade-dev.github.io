# Border Radius System

**System:** PixelPulse × macOS Sequoia Game Store  
**Version:** 1.0.0  
**Purpose:** Border radius scale and usage guidelines

---

## 📐 Radius Philosophy

**Rounded corners** create a friendly, modern, approachable aesthetic. This system uses generous radii (10px–24px) to match macOS Sequoia's soft, flowing design language.

---

## 📏 Radius Tokens

### Defined in `globals.css`

```css
--radius: 0.625rem;  /* 10px - base value */

/* Calculated Scale */
--radius-sm: calc(var(--radius) - 4px);  /* 6px */
--radius-md: calc(var(--radius) - 2px);  /* 8px */
--radius-lg: var(--radius);              /* 10px */
--radius-xl: calc(var(--radius) + 4px);  /* 14px */
```

### Custom Radii (Not in Tokens, But Used)

```css
/* Used in components */
--radius-card: 16px;    /* Standard cards */
--radius-modal: 24px;   /* Modals, large panels */
```

*(Recommended: Add these to globals.css)*

---

## 🎨 Tailwind Radius Classes

### Standard Classes (Use These)

| Class | Value | Use Case |
|-------|-------|----------|
| `rounded-md` | 6px | Tight elements |
| `rounded-lg` | 10px | Buttons, inputs |
| `rounded-xl` | 12px | Small cards, badges |
| `rounded-2xl` | 16px | Standard cards |
| `rounded-3xl` | 24px | Large cards, modals |
| `rounded-full` | 9999px | Pills, circles, avatars |

---

## 🎯 Radius Usage by Component

### Component Radius Matrix

| Component Type | Radius | Tailwind Class | Example |
|----------------|--------|----------------|---------|
| Buttons | 10-12px | `rounded-lg` / `rounded-xl` | Primary CTA |
| Inputs | 10-12px | `rounded-lg` / `rounded-xl` | Text input |
| Badges/Pills | Full | `rounded-full` | "New" badge |
| Small Cards | 12-16px | `rounded-xl` / `rounded-2xl` | Stat card |
| Standard Cards | 16px | `rounded-2xl` | GameCard |
| Large Cards | 16-24px | `rounded-2xl` / `rounded-3xl` | Featured hero |
| Modals | 24px | `rounded-3xl` | AppDetailModal |
| Dropdown Menus | 12px | `rounded-xl` | Context menu |
| Tooltips | 8px | `rounded-lg` | Small tooltip |
| Avatars | Full | `rounded-full` | User avatar |

---

## 🏗️ Radius Patterns

### Pattern 1: Standard Card

```tsx
<div className="p-6 rounded-2xl">  {/* 16px corners */}
  Card content
</div>
```

---

### Pattern 2: Button

```tsx
<button className="px-4 py-2 rounded-xl">  {/* 12px corners */}
  Click me
</button>
```

---

### Pattern 3: Input Field

```tsx
<input
  type="text"
  className="px-4 py-2 rounded-lg"  {/* 10px corners */}
/>
```

---

### Pattern 4: Badge/Pill

```tsx
<span className="px-3 py-1.5 rounded-full">
  New
</span>
```

---

### Pattern 5: Modal

```tsx
<div className="p-8 rounded-3xl">  {/* 24px corners */}
  Modal content
</div>
```

---

## 🎨 Radius Recipes

### Recipe: Card with Inner Elements

```tsx
<div className="p-6 rounded-2xl">  {/* Outer: 16px */}
  <div className="mb-4 rounded-xl overflow-hidden">  {/* Inner: 12px */}
    <img src="..." alt="..." className="w-full" />
  </div>
  <button className="w-full rounded-xl">  {/* Button: 12px */}
    Action
  </button>
</div>
```

**Hierarchy**: Outer radius larger than inner elements

---

### Recipe: Layered Radius (Nested)

```tsx
<div className="rounded-3xl overflow-hidden">  {/* Container: 24px */}
  <img src="..." className="w-full" />  {/* Image fills, inherits rounded top */}
  <div className="p-6">  {/* Content below image */}
    ...
  </div>
</div>
```

**Tip**: `overflow-hidden` on parent ensures image respects border radius

---

### Recipe: Image with Radius

```tsx
{/* Image Container Method */}
<div className="relative overflow-hidden rounded-2xl">
  <img src="..." alt="..." className="w-full h-full object-cover" />
</div>
```

**Why container?** Ensures radius clips image properly

---

## 📐 Radius Guidelines

### Rule 1: Larger Elements = Larger Radius

**Scale with size:**
- Small buttons: `rounded-lg` (10px)
- Large hero cards: `rounded-3xl` (24px)

**Example**:
```tsx
<button className="px-3 py-1.5 rounded-lg">Small</button>
<button className="px-6 py-3 rounded-xl">Large</button>
```

---

### Rule 2: Maintain Visual Consistency

**Within same context, use same radius:**

❌ **Wrong**:
```tsx
<div className="rounded-xl">Card 1</div>
<div className="rounded-2xl">Card 2</div>  {/* Inconsistent */}
```

✅ **Correct**:
```tsx
<div className="rounded-2xl">Card 1</div>
<div className="rounded-2xl">Card 2</div>  {/* Consistent */}
```

---

### Rule 3: Inner Radius Smaller Than Outer

**Nested elements:**

```tsx
<div className="p-6 rounded-2xl">  {/* Outer: 16px */}
  <img className="rounded-xl" />    {/* Inner: 12px */}
  <button className="rounded-xl" /> {/* Inner: 12px */}
</div>
```

**Visual harmony**: Inner elements never larger radius than container

---

### Rule 4: Pills Always Use `rounded-full`

```tsx
{/* Badges, tags, pills */}
<span className="px-3 py-1 rounded-full">Tag</span>
<span className="px-4 py-2 rounded-full">Chip</span>
```

**Don't use**: `rounded-3xl` for pills (not truly round)

---

## 🎨 Special Cases

### Image Cards with Gradient Overlay

```tsx
<div className="relative overflow-hidden rounded-2xl">
  <img src={image} className="w-full" />
  <div 
    className="absolute inset-0"
    style={{
      background: 'linear-gradient(to bottom, transparent, rgba(0,0,0,0.8))',
    }}
  />
  <div className="absolute bottom-0 p-6">
    <h3>Title</h3>
  </div>
</div>
```

**Key**: `overflow-hidden` on parent clips both image and gradient

---

### Radius with Glassmorphic Effects

```tsx
<div
  className="p-6 rounded-2xl"
  style={{
    background: 'var(--surface-glass)',
    backdropFilter: 'var(--blur-md)',
    border: '1px solid var(--border-glass)',
  }}
>
  Glass card
</div>
```

**Border radius + glass = perfect frosted effect**

---

## 🚫 Radius Anti-Patterns

### ❌ Inconsistent Radius

```tsx
// WRONG: Random radii
<div className="rounded-lg">Card 1</div>
<div className="rounded-2xl">Card 2</div>
<div className="rounded-xl">Card 3</div>
```

---

### ❌ Too Much Radius

```tsx
// WRONG: Excessive radius on small element
<button className="px-4 py-2 rounded-3xl">
  Button
</button>
```

**Fix**: Use `rounded-xl` for standard buttons

---

### ❌ No Radius on Cards

```tsx
// WRONG: Sharp corners don't match design system
<div className="p-6">
  Card content
</div>
```

**Fix**: Always add radius to cards (`rounded-2xl`)

---

### ❌ Image Not Clipped

```tsx
// WRONG: Image corners overflow card
<div className="rounded-2xl">
  <img src="..." className="w-full" />  {/* No overflow control */}
</div>
```

**Fix**: Add `overflow-hidden` to container OR round the image

---

## 📐 Radius + Other Properties

### Radius + Border

```tsx
<div className="rounded-2xl border border-[var(--border-glass)]">
  Content
</div>
```

**Border respects radius automatically**

---

### Radius + Shadow

```tsx
<div 
  className="rounded-2xl"
  style={{ boxShadow: 'var(--shadow-md)' }}
>
  Content
</div>
```

**Shadow follows border radius shape**

---

### Radius + Transform

```tsx
<div className="rounded-2xl transform hover:scale-105">
  Hover me
</div>
```

**Radius maintained during scale transform**

---

## 📱 Responsive Radius

### Adjusting for Mobile

**Generally**: Keep same radius across breakpoints  
**Exception**: Very large radii can be reduced on mobile

```tsx
<div className="rounded-2xl lg:rounded-3xl">
  {/* 16px mobile, 24px desktop */}
</div>
```

**Rare use case** — usually keep consistent

---

## ✅ Radius Checklist

- [ ] All cards use `rounded-2xl` (16px)
- [ ] Buttons use `rounded-xl` (12px)
- [ ] Inputs use `rounded-lg` (10px)
- [ ] Modals use `rounded-3xl` (24px)
- [ ] Badges/pills use `rounded-full`
- [ ] Radius consistent across similar components
- [ ] Inner radius smaller than outer
- [ ] Images clipped properly (`overflow-hidden`)

---

## 📚 Related Documentation

- **Spacing System**: `guidelines/design-tokens/spacing.md`
- **Shadows**: `guidelines/design-tokens/shadows.md`
- **Component Patterns**: `guidelines/overview-components.md`

---

**Use generous radii (10px+) to match the modern, friendly aesthetic. Consistency matters more than pixel perfection.**
