# Color System & Tokens

**System:** PixelPulse × macOS Sequoia Game Store  
**Version:** 1.0.0  
**Purpose:** Complete color token system, usage rules, and semantic guidelines

---

## 🎨 Color Philosophy

### Design Principle: Dark-First Glassmorphism

This system uses a **dark base** with **blue-purple gradient accents** and **glassmorphic surfaces** to create depth, premium feel, and visual hierarchy through layered transparency.

**Core Aesthetic:**
- Base: Deep dark backgrounds (#0E0F13, #191D28)
- Accent: Blue-purple gradients (#6F7DFF → #9B6FFF)
- Surface: Translucent glass effects with backdrop blur
- Text: High-contrast white/blue tints for readability

---

## 🏗️ Token Architecture

### Dual Token System (IMPORTANT)

This project has **TWO token systems** that coexist:

1. **PixelPulse Tokens** (PRIMARY — use these)
   - Located in `:root` after line 207 in `globals.css`
   - Prefixed: `--color-*`, `--bg-*`, `--txt-*`, `--brand-*`
   - Purpose: Custom game store design system

2. **shadcn Tokens** (SECONDARY — only for shadcn/ui components)
   - Located in `:root` lines 3-42 and `.dark` lines 44-79
   - Prefixed: `--primary`, `--secondary`, `--muted`, etc.
   - Purpose: shadcn/ui component theming

### Which System to Use?

**RULE: Always use PixelPulse tokens for custom components**

| Scenario | Token System | Example |
|----------|--------------|---------|
| Custom component background | PixelPulse | `var(--bg-panel)` |
| Custom component text | PixelPulse | `var(--txt-primary)` |
| shadcn Button component | shadcn | `bg-primary` (Tailwind class) |
| shadcn Dialog component | shadcn | `--popover` |
| Brand gradient | PixelPulse | `var(--gradient-brand)` |

**Why Two Systems?**
- shadcn components expect their token names
- Custom components use PixelPulse for design consistency
- Both systems themed for dark mode compatibility

---

## 🎨 PixelPulse Color Tokens (PRIMARY SYSTEM)

### Brand Colors

**Primary Brand:**
```css
--color-primary: #6F7DFF;     /* Main brand color (blue) */
--brand-start: #6F7DFF;       /* Gradient start */
```

**Usage**:
- Primary CTAs
- Interactive elements (buttons, links)
- Focus states
- Active indicators

**Example**:
```tsx
<button style={{ background: 'var(--color-primary)' }}>
  Primary Action
</button>
```

---

**Secondary Brand:**
```css
--color-secondary: #9B6FFF;   /* Secondary brand (purple) */
--brand-end: #9B6FFF;         /* Gradient end */
```

**Usage**:
- Secondary CTAs
- Gradient endpoints
- Accent elements
- Hover states

---

**Accent Color:**
```css
--color-accent: #55E6C1;      /* Teal accent */
```

**Usage**:
- Success states
- Highlights
- Interactive feedback
- Progress indicators

---

### Background Colors

**Base Background:**
```css
--color-background: #0E0F13;  /* Darkest background */
--bg-base: #0E0F13;           /* Alias */
```

**Usage**:
- App root background
- Fullscreen overlays
- Deep shadows

**Visual Effect**: Deepest layer, provides maximum contrast

---

**Panel Background:**
```css
--color-panel: #191D28;       /* Card/panel background */
--bg-panel: #191D28;          /* Alias */
```

**Usage**:
- Cards
- Modals
- Sidebar
- Any elevated surface

**Visual Effect**: Slightly lighter than base, creates depth

**Example**:
```tsx
<div className="rounded-2xl p-6" style={{ background: 'var(--bg-panel)' }}>
  Card Content
</div>
```

---

**Light Panel:**
```css
--bg-panel-light: #1F2430;    /* Lighter variation */
```

**Usage**:
- Nested panels
- Secondary surfaces within cards
- Input backgrounds on panels

**Visual Hierarchy**:
```
App Background (--bg-base)
  └─ Panel (--bg-panel)
       └─ Nested Panel (--bg-panel-light)
```

---

### Text Colors

**Primary Text:**
```css
--color-text-primary: #F4F7FF; /* Main text color */
--txt-primary: #F4F7FF;        /* Alias */
```

**Usage**:
- Headings
- Body text
- Important labels
- Primary content

**Contrast**: 15.8:1 on `--bg-base` (exceeds WCAG AAA)

---

**Secondary Text:**
```css
--color-text-secondary: #B9C2D0; /* Secondary text */
--txt-secondary: #B9C2D0;        /* Alias */
```

**Usage**:
- Supporting text
- Labels
- Metadata (dates, counts)
- Less important content

**Contrast**: 8.2:1 on `--bg-base` (exceeds WCAG AA)

---

**Tertiary Text:**
```css
--color-text-tertiary: #8B95AB; /* Muted text */
--txt-tertiary: #8B95AB;        /* Alias */
```

**Usage**:
- Placeholders
- Disabled text
- Fine print
- Very low-priority text

**Contrast**: 5.1:1 on `--bg-base` (meets WCAG AA for large text)

**Warning**: Do not use for body text under 18px

---

### Semantic Colors

**Success:**
```css
--color-success: #55E6C1;     /* Teal - success state */
```

**Usage**:
- Success messages
- Positive metrics (growth)
- Completed states
- Checkmarks

**Example**:
```tsx
<div style={{ color: 'var(--color-success)' }}>
  ✓ Purchase successful
</div>
```

---

**Warning:**
```css
--color-warning: #FFB84D;     /* Orange - warning state */
```

**Usage**:
- Warning messages
- Caution indicators
- Pending states
- Attention-grabbing (not critical)

---

**Error:**
```css
--color-error: #FF6B6B;       /* Red - error state */
```

**Usage**:
- Error messages
- Validation failures
- Destructive actions
- Critical alerts

---

**Info:**
```css
--color-info: #6F7DFF;        /* Blue - informational */
```

**Usage**:
- Info messages
- Tips
- Non-critical notifications

---

### Gradients

**Primary Brand Gradient:**
```css
--gradient-brand: linear-gradient(135deg, #6F7DFF, #9B6FFF);
--gradient-brand-90: linear-gradient(90deg, #6F7DFF, #9B6FFF);
```

**Usage**:
- Primary CTAs
- Hero sections
- Feature highlights
- Hover glows

**Angles**:
- `135deg`: Diagonal (default)
- `90deg`: Horizontal

**Example**:
```tsx
<button style={{ background: 'var(--gradient-brand)' }}>
  Get Game
</button>
```

---

**Gradient Overlays:**
```css
/* Defined in components, not global tokens */
/* Example: Image overlays */
background: linear-gradient(to bottom, transparent 0%, rgba(14, 15, 19, 0.8) 100%);
```

**Usage**:
- Image overlays (make text readable)
- Hero banner fades
- Card image treatments

---

### Glass Surface Colors

**Primary Glass:**
```css
--surface-glass: rgba(25, 29, 40, 0.72); /* Semi-transparent panel */
--color-glass: rgba(25, 29, 40, 0.72);   /* Alias */
```

**Usage**:
- Glassmorphic cards
- Floating panels
- Overlays
- Header/navigation bars

**Must Use With**:
```tsx
style={{
  background: 'var(--surface-glass)',
  backdropFilter: 'var(--blur-md)',  // See blur tokens
  border: '1px solid var(--border-glass)',
}}
```

---

**Light Glass:**
```css
--surface-glass-light: rgba(31, 36, 48, 0.82); /* Less transparent */
```

**Usage**:
- Important glassmorphic elements
- Modals (more solid)
- Elevated glass surfaces

**Visual Difference**:
- `--surface-glass`: 72% opacity (more see-through)
- `--surface-glass-light`: 82% opacity (more solid)

---

### Border Colors

**Primary Border:**
```css
--border-glass: rgba(255, 255, 255, 0.1); /* Subtle glass border */
```

**Usage**:
- Glass surface borders
- Card outlines
- Dividers
- Input borders

**Visual Effect**: Creates subtle edge definition on glass

**Example**:
```tsx
<div style={{ 
  background: 'var(--surface-glass)',
  border: '1px solid var(--border-glass)'
}}>
```

---

**Stronger Borders:**
```css
--border-subtle: rgba(255, 255, 255, 0.15);  /* More visible */
--border-medium: rgba(255, 255, 255, 0.2);   /* Standard */
```

**Usage**:
- Table borders
- Form field borders
- Section dividers

*(Note: These may not be defined yet, add to globals.css if needed)*

---

## 🎨 shadcn Color Tokens (SECONDARY SYSTEM)

### Light Mode (`:root`)

**Used by shadcn/ui components in light mode context:**

```css
--background: #ffffff;
--foreground: oklch(0.145 0 0);  /* Near black */
--primary: #030213;               /* Dark primary */
--secondary: oklch(0.95 0.0058 264.53); /* Light purple tint */
--muted: #ececf0;                 /* Light gray */
--accent: #e9ebef;                /* Light accent */
--destructive: #d4183d;           /* Red */
--border: rgba(0, 0, 0, 0.1);     /* Light border */
```

**When Used**: Rarely (app is dark-first), only if shadcn components force light mode

---

### Dark Mode (`.dark`)

**Used by shadcn/ui components — maps to dark theme:**

```css
--background: oklch(0.145 0 0);    /* Dark background */
--foreground: oklch(0.985 0 0);    /* Near white */
--primary: oklch(0.985 0 0);       /* Light primary */
--secondary: oklch(0.269 0 0);     /* Dark gray */
--muted: oklch(0.269 0 0);         /* Muted dark */
--destructive: oklch(0.396 0.141 25.723); /* Red */
```

**When Used**: Automatically applied to shadcn/ui Button, Dialog, etc. when `.dark` class present

---

## 📐 Color Usage Rules

### Rule 1: Never Hardcode Colors

❌ **WRONG**:
```tsx
<div style={{ background: '#191D28' }}>
<div style={{ color: '#F4F7FF' }}>
```

✅ **CORRECT**:
```tsx
<div style={{ background: 'var(--bg-panel)' }}>
<div style={{ color: 'var(--txt-primary)' }}>
```

---

### Rule 2: Use Semantic Tokens for Meaning

❌ **WRONG** (using brand color for error):
```tsx
<span style={{ color: 'var(--color-primary)' }}>Error occurred</span>
```

✅ **CORRECT**:
```tsx
<span style={{ color: 'var(--color-error)' }}>Error occurred</span>
```

---

### Rule 3: Maintain Visual Hierarchy

**Text Color Hierarchy** (from most to least important):
1. `--txt-primary` — Headings, critical content
2. `--txt-secondary` — Body text, labels
3. `--txt-tertiary` — Metadata, placeholders

**Background Hierarchy** (from deepest to highest):
1. `--bg-base` — App background
2. `--bg-panel` — Cards, primary surfaces
3. `--bg-panel-light` — Nested panels, inputs

---

### Rule 4: Gradients Only on Primary Actions

✅ **Use gradients for**:
- Primary CTA buttons
- Hero sections
- Featured content highlights

❌ **Don't use gradients for**:
- Multiple buttons in same area (breaks hierarchy)
- Body text
- Backgrounds (unless hero/feature)

---

### Rule 5: Glass Effects Need 3 Properties

**ALWAYS use together**:
```tsx
style={{
  background: 'var(--surface-glass)',
  backdropFilter: 'var(--blur-md)',
  border: '1px solid var(--border-glass)',
}}
```

Missing any = Not true glassmorphism

---

## 🎯 Common Color Combinations

### Card (Standard)
```tsx
style={{
  background: 'var(--bg-panel)',
  border: '1px solid var(--border-glass)',
  color: 'var(--txt-primary)',
}}
```

### Card (Glassmorphic)
```tsx
style={{
  background: 'var(--surface-glass)',
  backdropFilter: 'var(--blur-md)',
  border: '1px solid var(--border-glass)',
  color: 'var(--txt-primary)',
}}
```

### Primary Button
```tsx
style={{
  background: 'var(--gradient-brand)',
  color: 'white',
}}
```

### Secondary Button
```tsx
style={{
  background: 'rgba(255, 255, 255, 0.06)',
  border: '1px solid var(--border-glass)',
  color: 'var(--txt-primary)',
}}
```

### Input Field
```tsx
style={{
  background: 'rgba(255, 255, 255, 0.04)',
  border: '1px solid var(--border-glass)',
  color: 'var(--txt-primary)',
}}
className="placeholder:text-[var(--txt-tertiary)]"
```

### Success Message
```tsx
style={{
  background: 'rgba(85, 230, 193, 0.1)',
  border: '1px solid var(--color-success)',
  color: 'var(--color-success)',
}}
```

### Error Message
```tsx
style={{
  background: 'rgba(255, 107, 107, 0.1)',
  border: '1px solid var(--color-error)',
  color: 'var(--color-error)',
}}
```

---

## ♿ Accessibility Guidelines

### Contrast Requirements

**WCAG AA Standards:**
- Normal text (< 18px): 4.5:1 minimum
- Large text (≥ 18px): 3:1 minimum

**Our Token Contrast Ratios:**

| Token | On --bg-base | On --bg-panel | WCAG Level |
|-------|--------------|---------------|------------|
| `--txt-primary` | 15.8:1 | 14.2:1 | AAA ✓ |
| `--txt-secondary` | 8.2:1 | 7.4:1 | AA ✓ |
| `--txt-tertiary` | 5.1:1 | 4.6:1 | AA (large only) |
| `--color-success` | 9.1:1 | 8.2:1 | AAA ✓ |
| `--color-error` | 5.8:1 | 5.2:1 | AA ✓ |

### Safe Text/Background Pairings

✅ **Always Safe**:
- `--txt-primary` on any background
- `--txt-secondary` on any background

⚠️ **Use Carefully**:
- `--txt-tertiary` on `--bg-panel-light` (only for large text 18px+)

❌ **Never Use**:
- `--txt-tertiary` on `--surface-glass` (insufficient contrast)
- Any text on `--gradient-brand` except white

---

## 🎨 Color Recipes

### Recipe: Hover Glow Effect

```tsx
<div className="relative group">
  {/* Content */}
  <div className="...">Card content</div>
  
  {/* Hover Glow */}
  <div
    className="absolute -inset-0.5 rounded-[calc(var(--radius-card)+2px)] opacity-0 group-hover:opacity-100 transition-opacity duration-300"
    style={{
      background: 'var(--gradient-brand)',
      filter: 'blur(12px)',
      zIndex: -1,
    }}
  />
</div>
```

### Recipe: Glass Modal Overlay

```tsx
<div
  className="fixed inset-0 z-50"
  style={{
    background: 'rgba(14, 15, 19, 0.6)',
    backdropFilter: 'var(--blur-lg)',
  }}
>
  <div
    className="..."
    style={{
      background: 'var(--surface-glass-light)',
      backdropFilter: 'var(--blur-xl)',
      border: '1px solid var(--border-glass)',
    }}
  >
    Modal content
  </div>
</div>
```

### Recipe: Badge/Pill

```tsx
<span
  className="px-3 py-1.5 rounded-full backdrop-blur-xl"
  style={{
    background: 'rgba(111, 125, 255, 0.2)',
    border: '1px solid rgba(111, 125, 255, 0.4)',
    color: 'white',
  }}
>
  New
</span>
```

---

## 🚫 Anti-Patterns

### ❌ Don't Mix Token Systems

```tsx
// WRONG: Mixing PixelPulse and shadcn tokens
<div style={{ 
  background: 'var(--bg-panel)',  // PixelPulse
  color: 'var(--foreground)'      // shadcn
}}>
```

### ❌ Don't Use RGB When Token Exists

```tsx
// WRONG
background: '#6F7DFF'

// CORRECT
background: 'var(--color-primary)'
```

### ❌ Don't Override Token Values Inline

```tsx
// WRONG
<div style={{ '--color-primary': '#FF0000' }}>

// CORRECT: Use the token as-is or create new semantic token
```

---

## 📚 Related Documentation

- **Typography Tokens**: `guidelines/design-tokens/typography.md`
- **Blur Effects**: `guidelines/design-tokens/blur.md`
- **Shadows**: `guidelines/design-tokens/shadows.md`
- **Complete Design System**: `/DESIGN_SYSTEM.md`

---

**Always use PixelPulse tokens for custom components. When in doubt, check existing components for color usage patterns.**
