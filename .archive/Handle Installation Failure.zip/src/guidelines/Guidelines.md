# Game Store Admin Panel - Master Guidelines

**Version:** 1.0.0  
**System:** PixelPulse × macOS Sequoia Game Store  
**Last Updated:** December 2024  
**Purpose:** System-level rules for Figma Make AI to ensure consistent, production-quality code generation

---

## 🎯 Overview

This project is a **macOS Sequoia-styled Game Store Admin Panel** with **PixelPulse glassmorphism** design language. It combines Apple Arcade aesthetics with modern glassmorphic effects, dark neumorphism, and smooth spring animations.

**Core Technologies:**
- React 18 + TypeScript
- Tailwind CSS v4.0
- shadcn/ui component primitives
- Custom design token system
- Context-based state management
- Mock data architecture (no backend)

---

## 📚 Required Reading Order

When generating or modifying code, you MUST read these files in order:

### 1. System Design & Architecture (READ FIRST)
- `guidelines/overview-system-design.md` — Page structure, routing, component composition
- `docs/architecture.md` — Technical architecture, folder structure, data flow

### 2. Design Tokens (READ SECOND)
- `guidelines/design-tokens/colors.md` — Color system and token usage
- `guidelines/design-tokens/typography.md` — Font scale, weights, semantic usage
- `guidelines/design-tokens/spacing.md` — Spacing scale and layout patterns
- `guidelines/design-tokens/radius.md` — Border radius scale
- `guidelines/design-tokens/shadows.md` — Elevation and shadow system
- `guidelines/design-tokens/blur.md` — Glassmorphic blur effects

### 3. Component System (READ THIRD)
- `guidelines/overview-components.md` — Component catalog and usage rules
- `guidelines/components/[component-name].md` — Specific component guidelines as needed

### 4. Reference Documentation
- `/DESIGN_SYSTEM.md` — Complete design specification (for visual understanding)
- `/types/index.ts` — TypeScript types and data models

---

## 🏗️ Architectural Principles

### Component Hierarchy

**ALWAYS follow this hierarchy:**

1. **Use Custom Components First** (if they exist for the use case)
   - Located in `/components/` (e.g., `GameCard`, `Header`, `PageHeader`)
   - These implement the design system correctly

2. **Use shadcn/ui Primitives Second** (for base UI elements)
   - Located in `/components/ui/` (e.g., `Button`, `Dialog`, `Card`)
   - These provide accessible, composable building blocks

3. **Use Raw HTML/Primitives Last** (only if no component exists)
   - For one-off layouts or unique patterns
   - Must follow design token system rigorously

### Component Creation Rules

**When creating NEW components:**

1. **Check if a similar component exists first**
   - Look in `/components/` for existing patterns
   - Reuse or extend existing components when possible
   - Don't create `GameCard2` when you can enhance `GameCard`

2. **Follow the component template:**
   ```tsx
   import { /* icons */ } from 'lucide-react';
   
   interface [ComponentName]Props {
     // Props with JSDoc comments
   }
   
   export function [ComponentName]({ ...props }: [ComponentName]Props) {
     // Component logic
     return (
       // JSX
     );
   }
   ```

3. **Use design tokens exclusively:**
   - ✅ `style={{ background: 'var(--bg-panel)' }}`
   - ❌ `style={{ background: '#191D28' }}`

4. **Place in correct folder:**
   - Custom domain components → `/components/`
   - Reusable UI primitives → `/components/ui/`
   - Page-level components → `/pages/`
   - Icon components → `/components/icons/`

---

## 🎨 Design System Rules

### Critical Design Rules (NEVER VIOLATE)

1. **NO Tailwind Typography Classes**
   - ❌ NEVER use: `text-2xl`, `text-lg`, `font-bold`, `font-semibold`, `leading-tight`
   - ✅ ALWAYS use: inline `fontSize`, `fontWeight` with CSS variables OR rely on base typography
   - **Why:** We have base typography in `globals.css` that auto-applies to semantic HTML

2. **Design Token System: PixelPulse Tokens Take Priority**
   - Use PixelPulse tokens for colors: `--color-primary`, `--bg-panel`, `--txt-primary`
   - Use shadcn tokens ONLY for shadcn/ui components
   - See `guidelines/design-tokens/colors.md` for complete token mapping

3. **Glassmorphic Effects Standard Pattern**
   ```tsx
   style={{
     background: 'var(--surface-glass)',
     backdropFilter: 'var(--blur-md) saturate(1.1)',
     border: '1px solid var(--border-glass)',
   }}
   ```

4. **Gradients: Use CSS Variables**
   - ✅ `background: 'var(--gradient-brand)'`
   - ❌ `background: 'linear-gradient(135deg, #6F7DFF, #9B6FFF)'`

5. **Animations: Spring Timing (220ms ease-out)**
   - All transitions use: `transition-all duration-[220ms] ease-out`
   - Or inline: `transition: 'all 220ms cubic-bezier(0.34, 1.56, 0.64, 1)'`

6. **Hover Effects: Scale + Glow**
   - Scale: `hover:scale-[1.02]`
   - Glow: Add pseudo-element with gradient + blur (see `GameCard.tsx` lines 35-42)

---

## 📐 Layout & Structure Rules

### Page Composition Pattern

**EVERY page MUST follow this structure:**

```tsx
export function [Page]Name() {
  return (
    <>
      <PageHeader 
        title="Page Title"
        subtitle="Optional description"
        rightContent={<OptionalButton />} // if needed
      />
      
      <main className="flex-1 overflow-y-auto">
        <div className="px-8 py-6 space-y-8">
          {/* Page content here */}
        </div>
      </main>
    </>
  );
}
```

**Why:** Ensures consistent spacing, scrolling behavior, and header treatment.

### Grid Layouts

**Use Tailwind grid with consistent breakpoints:**

```tsx
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
```

**Standard breakpoints:**
- `sm`: 640px (mobile landscape)
- `md`: 768px (tablet)
- `lg`: 1024px (desktop)
- `xl`: 1280px (large desktop)

### Spacing Scale

**ALWAYS use these spacing values:**
- Gap between items: `gap-4` (16px) or `gap-6` (24px)
- Section padding: `px-8 py-6` (page level), `p-6` (cards)
- Element spacing: `space-y-4`, `space-y-6`, `space-y-8`

---

## 🧩 Component Usage Rules

### Cards

**Use the correct card for each purpose:**

| Component | Purpose | When to Use |
|-----------|---------|-------------|
| `GameCard` | Game showcase in store | Games in catalog, carousels |
| `AppCard` | Apps in library view | User's owned apps |
| `ArcadeCard` | Apple Arcade-style games | Arcade page |
| `StatCard` | Metrics/statistics | Dashboard stats |
| `CategoryCard` | Category navigation | Category browsing |

**Don't create new card components** unless none of these fit.

### Buttons

**Button hierarchy:**

1. **Primary actions**: Use `GlassButton` or inline button with `var(--gradient-brand)`
2. **Secondary actions**: Use `components/ui/button.tsx` with `variant="outline"`
3. **Tertiary actions**: Use `variant="ghost"`
4. **Icon-only**: Use button with icon, add `aria-label`

### Modals & Dialogs

**ALWAYS use shadcn Dialog:**

```tsx
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './components/ui/dialog';

<Dialog open={open} onOpenChange={setOpen}>
  <DialogContent className="...">
    <DialogHeader>
      <DialogTitle>Title</DialogTitle>
    </DialogHeader>
    {/* Content */}
  </DialogContent>
</Dialog>
```

### Headers

- **Page-level**: Use `PageHeader` component
- **Section-level**: Use `<h2>` or `<h3>` with semantic HTML
- **Global nav**: AppSidebar handles this (don't recreate)

---

## ♿ Accessibility Requirements

### Non-Negotiable Rules

1. **All icon-only buttons need `aria-label`**
   ```tsx
   <button aria-label="Open settings">
     <Settings size={20} />
   </button>
   ```

2. **All images need meaningful `alt` text**
   ```tsx
   <img src={game.image} alt={`${game.title} game cover`} />
   ```

3. **Form inputs need associated labels**
   ```tsx
   <label htmlFor="email">Email</label>
   <input id="email" type="email" />
   ```

4. **Focus indicators must be visible**
   - Don't remove outlines
   - Use `focus-visible:ring-2 focus-visible:ring-primary`

5. **Keyboard navigation required**
   - All interactive elements must be keyboard accessible
   - Modal focus traps implemented (use `useFocusTrap` hook)

6. **Color contrast: WCAG AA minimum**
   - Text on glass: Use `--txt-primary` or `--txt-secondary`
   - Never use low-contrast colors for critical info

---

## 📁 File Organization Rules

### Import Order

**ALWAYS organize imports like this:**

```tsx
// 1. External libraries
import { useState } from 'react';
import { Search, Bell } from 'lucide-react';

// 2. Internal components (alphabetically)
import { Button } from './components/ui/button';
import { GameCard } from './components/GameCard';

// 3. Hooks
import { useDebounce } from './hooks/useDebounce';

// 4. Utils & types
import { formatPrice } from './utils/format';
import { Game } from './types';

// 5. Styles (if any)
import './styles/custom.css';
```

### Naming Conventions

- **Components**: PascalCase (`GameCard.tsx`)
- **Hooks**: camelCase with `use` prefix (`useDebounce.ts`)
- **Utils**: camelCase (`formatPrice`, `validateEmail`)
- **Types**: PascalCase (`Game`, `User`)
- **Constants**: UPPER_SNAKE_CASE (`MAX_ITEMS`, `API_ENDPOINT`)

### File Size Limits

- **Components**: Max 300 lines (split if larger)
- **Pages**: Max 400 lines (extract sections to components)
- **Utils**: Max 200 lines per file (split by domain)

---

## 🔧 TypeScript Rules

### Type Safety Requirements

1. **All component props MUST be typed**
   ```tsx
   interface GameCardProps {
     title: string;
     price: number | string; // Allow both for "Free" text
     image: string;
     onClick?: () => void; // Optional callback
   }
   ```

2. **Event handlers MUST be typed**
   ```tsx
   const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
     // ...
   };
   ```

3. **Use discriminated unions for variants**
   ```tsx
   type ButtonVariant = 
     | { variant: 'primary'; gradient: string }
     | { variant: 'secondary'; outline: boolean };
   ```

4. **Export prop types for composability**
   ```tsx
   export interface GameCardProps { /* ... */ }
   export function GameCard(props: GameCardProps) { /* ... */ }
   ```

---

## 🚫 Anti-Patterns (NEVER DO THIS)

### Code Anti-Patterns

1. ❌ **Hardcoding colors**
   ```tsx
   // WRONG
   <div style={{ background: '#191D28' }}>
   
   // RIGHT
   <div style={{ background: 'var(--bg-panel)' }}>
   ```

2. ❌ **Creating duplicate components**
   ```tsx
   // WRONG: Creating GameCard2 when GameCard exists
   // RIGHT: Extend GameCard with new props or variants
   ```

3. ❌ **Inline styles without design tokens**
   ```tsx
   // WRONG
   <div className="p-4 rounded-lg bg-gray-800">
   
   // RIGHT
   <div className="p-6 rounded-2xl" style={{ background: 'var(--bg-panel)' }}>
   ```

4. ❌ **Multiple return statements in components without clear logic**
   ```tsx
   // WRONG: Hard to follow
   if (loading) return <Spinner />;
   if (error) return <Error />;
   if (!data) return <Empty />;
   return <Content />;
   
   // RIGHT: Clear component composition
   if (loading) return <LoadingState />;
   if (error) return <ErrorState message={error.message} />;
   return data ? <ContentState data={data} /> : <EmptyState />;
   ```

5. ❌ **Props drilling beyond 2 levels**
   ```tsx
   // WRONG: Passing props through 3+ components
   // RIGHT: Use Context or component composition
   ```

### Design Anti-Patterns

1. ❌ **Inconsistent spacing**
   - Use `gap-6` everywhere, not random values

2. ❌ **Breaking visual hierarchy**
   - Don't use primary gradient on multiple buttons in same section

3. ❌ **Overusing glassmorphism**
   - Not every element needs glass effect
   - Reserve for cards, modals, header

4. ❌ **Ignoring responsive design**
   - All components must work 375px → 1920px+

---

## 🎯 Quality Checklist

**Before completing ANY generation, verify:**

- [ ] All colors use CSS custom properties
- [ ] No Tailwind typography classes used
- [ ] Component follows page composition pattern (if page)
- [ ] All icon-only buttons have `aria-label`
- [ ] All images have meaningful `alt` text
- [ ] TypeScript props are fully typed
- [ ] Imports are organized correctly
- [ ] Component is in correct folder
- [ ] Design tokens used for all styles
- [ ] Responsive breakpoints applied
- [ ] Hover/focus states implemented
- [ ] Animation timing matches design system (220ms)

---

## 🔄 Modification Protocol

**When user asks to modify existing code:**

1. **Read the existing file completely**
2. **Identify which guideline applies**
3. **Check if similar pattern exists elsewhere**
4. **Apply changes consistently across affected components**
5. **Verify against quality checklist above**

**When user asks to create new feature:**

1. **Read system-design.md to understand architecture**
2. **Check if components needed already exist**
3. **Design component composition before coding**
4. **Follow design token system strictly**
5. **Add to appropriate folder with correct naming**

---

## 📖 Additional Resources

- **Full Design Spec**: `/DESIGN_SYSTEM.md`
- **TypeScript Types**: `/types/index.ts`
- **Mock Data Patterns**: `/utils/mockData.ts`
- **Custom Hooks**: `/hooks/*`
- **Utilities**: `/utils/*`

---

## 🆘 When In Doubt

1. **Check if a similar component exists** → Reuse it
2. **Check design-tokens docs** → Use those tokens
3. **Check overview-components.md** → See usage examples
4. **Follow the pattern of existing code** → Stay consistent
5. **Ask yourself: Does this match the macOS Sequoia aesthetic?** → Visual quality matters

---

**Remember: Consistency is more important than cleverness. Follow these guidelines religiously to maintain a production-quality codebase.**
