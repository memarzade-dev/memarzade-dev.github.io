# System Design & Architecture Overview

**Component:** Game Store Admin Panel Architecture  
**Version:** 1.0.0  
**Purpose:** Document global layout patterns, routing structure, page composition, and component architecture

---

## 🏛️ System Architecture

### High-Level Structure

```
┌─────────────────────────────────────────────────────┐
│                    App.tsx (Root)                    │
│  ┌──────────────┐  ┌─────────────────────────────┐ │
│  │              │  │                               │ │
│  │  AppSidebar  │  │   Dynamic Page Rendering      │ │
│  │  (240px)     │  │   (flex-1)                    │ │
│  │              │  │                               │ │
│  │  Navigation  │  │  ┌─────────────────────────┐ │ │
│  │  Items       │  │  │   PageHeader (72px)     │ │ │
│  │              │  │  └─────────────────────────┘ │ │
│  │              │  │                               │ │
│  │              │  │  ┌─────────────────────────┐ │ │
│  │              │  │  │   main (flex-1)         │ │ │
│  │              │  │  │   overflow-y-auto       │ │ │
│  │              │  │  │                         │ │ │
│  │              │  │  │   Page Content          │ │ │
│  │              │  │  │   (px-8 py-6)           │ │ │
│  │              │  │  │                         │ │ │
│  │              │  │  └─────────────────────────┘ │ │
│  │              │  │                               │ │
│  └──────────────┘  └─────────────────────────────┘ │
└─────────────────────────────────────────────────────┘
       ▲                        ▲
       │                        │
   Persistent               Conditional
   Sidebar                  Modals/Overlays
   
   └── AppDetailModal
   └── SearchModal
   └── NotificationCenter
   └── Toaster
```

---

## 🗺️ Routing & Navigation

### Routing Strategy: State-Based (No React Router)

**Current Implementation:**
- Single-page application with state-based routing
- `currentPage` state in App.tsx determines which page component renders
- No URL synchronization (by design for this version)

**Page Type Enum:**
```typescript
export type PageType = 
  | 'dashboard'    // Analytics and overview
  | 'discover'     // Browse all games
  | 'arcade'       // Apple Arcade-style games
  | 'inventory'    // Stock management
  | 'categories'   // Browse by category
  | 'updates'      // App updates feed
  | 'account'      // User account settings
  | 'search';      // Search results (future)
```

**Navigation Flow:**
```
User clicks sidebar item
   ↓
onPageChange(page: PageType)
   ↓
setCurrentPage(page)
   ↓
renderPage() switch statement
   ↓
Appropriate <PageComponent /> rendered
```

### Why State-Based Routing?

✅ **Pros:**
- Simple implementation
- No routing library dependency
- Fast page transitions
- Easy state management

❌ **Cons:**
- No deep linking
- No browser history
- No URL sharing
- Not SEO-friendly (not relevant for admin panel)

**Future Migration Path:**
If URL routing needed, migrate to:
1. React Router v6 with similar structure
2. Map `PageType` to routes: `/dashboard`, `/discover`, etc.
3. Keep same component structure

---

## 📄 Page Composition Pattern

### Standard Page Structure (MANDATORY)

**Every page MUST follow this exact pattern:**

```tsx
export function [PageName]() {
  // 1. Local state
  const [localState, setLocalState] = useState();

  // 2. Event handlers
  const handleAction = () => { /* ... */ };

  // 3. Render
  return (
    <>
      {/* REQUIRED: PageHeader for title and actions */}
      <PageHeader 
        title="Page Title"
        subtitle="Optional subtitle"
        rightContent={<OptionalActions />}
      />

      {/* REQUIRED: Main content area with scroll */}
      <main className="flex-1 overflow-y-auto">
        {/* REQUIRED: Standard padding container */}
        <div className="px-8 py-6 space-y-8">
          {/* Page-specific content sections */}
          <Section1 />
          <Section2 />
        </div>
      </main>
    </>
  );
}
```

### Page Structure Breakdown

#### 1. PageHeader Component
- **Purpose**: Consistent page titles and action areas
- **Props**:
  - `title: string` — Main page heading
  - `subtitle?: string` — Optional description
  - `rightContent?: ReactNode` — Optional action buttons/controls
  - `showSearch?: boolean` — Show search input (rarely used, prefer SearchModal)

#### 2. Main Content Area
- **Classes**: `flex-1 overflow-y-auto`
- **Why**:
  - `flex-1`: Takes remaining vertical space
  - `overflow-y-auto`: Enables scrolling for long content
  - Sidebar and PageHeader remain fixed during scroll

#### 3. Content Container
- **Classes**: `px-8 py-6 space-y-8`
- **Spacing**:
  - `px-8`: 32px horizontal padding
  - `py-6`: 24px vertical padding
  - `space-y-8`: 32px gap between sections

**Why these values?**
- Provides comfortable reading width
- Consistent spacing across all pages
- Aligns with 8px spacing scale

---

## 🧱 Component Architecture Layers

### Layer 1: Page Components (`/pages/`)

**Purpose**: Top-level views that compose feature sections

**Responsibilities:**
- Implement page composition pattern
- Compose sections from feature components
- Handle page-level state
- Pass callbacks to child components

**Example Structure:**
```tsx
// /pages/DashboardPage.tsx
export function DashboardPage() {
  return (
    <>
      <PageHeader title="Dashboard" />
      <main className="flex-1 overflow-y-auto">
        <div className="px-8 py-6 space-y-8">
          <QuickStats {...statsData} />
          <ChartsGrid />
          <ActivityFeed activities={activities} />
        </div>
      </main>
    </>
  );
}
```

**Rules:**
- One page = one file
- Max 400 lines (split into components if larger)
- No complex business logic (extract to hooks/utils)
- Import data from `/utils/mockData.ts`

### Layer 2: Feature Components (`/components/`)

**Purpose**: Reusable sections and composite UI elements

**Categories:**

#### A. Layout Components
- `AppSidebar` — Main navigation sidebar
- `PageHeader` — Page title and actions bar
- `Header` — Legacy header (being phased out)

#### B. Display Components
- `GameCard`, `AppCard`, `ArcadeCard` — Game/app showcase cards
- `StatCard` — Metric display cards
- `CategoryCard` — Category navigation tiles
- `UpdateCard` — Update feed items

#### C. Composite Feature Components
- `CarouselRail` — Horizontal scrolling game rail
- `GameGrid` — Responsive grid of games
- `QuickStats` — Dashboard stats overview
- `ActivityFeed` — Activity timeline
- `FeaturedHero` — Hero banner with game highlight
- `HeroBanner` — Generic hero banner

#### D. Interactive Components
- `SearchModal` — Global search overlay (Cmd+K)
- `AppDetailModal` — Game detail modal
- `NotificationCenter` — Toast notifications manager
- `UserMenu` — User account dropdown
- `FilterBar` — Filter controls for lists
- `BulkActions` — Bulk selection actions

#### E. Form & Input Components
- `GlassInput` — Glassmorphic text input
- `GlassButton` — Glassmorphic button
- `DateRangePicker` — Date range selector

#### F. Feedback Components
- `LoadingSpinner` — Loading indicator
- `EmptyState` — Empty list state
- `ErrorBoundary` — Error handling wrapper
- `ConfirmDialog` — Confirmation dialog

**Component Responsibility Matrix:**

| Component Type | State | Logic | Styles | Props |
|----------------|-------|-------|--------|-------|
| Layout | Minimal | Navigation | Design system | Config only |
| Display | None | Formatting | Strict tokens | Data + callbacks |
| Composite | Local UI | Composition | Inherited | Feature data |
| Interactive | Form state | Validation | Design system | Handlers |
| Feedback | None | Conditional | Design system | Status |

### Layer 3: UI Primitives (`/components/ui/`)

**Purpose**: Accessible, unstyled base components from shadcn/ui

**Available Primitives:**
- `button.tsx` — Base button with variants
- `dialog.tsx` — Modal/dialog primitives
- `card.tsx` — Base card structure
- `input.tsx` — Base form input
- `select.tsx` — Dropdown select
- `dropdown-menu.tsx` — Dropdown menus
- `tooltip.tsx` — Tooltip overlays
- `tabs.tsx` — Tab navigation
- `table.tsx` — Data tables
- Plus 30+ more...

**When to Use:**
- Building new custom components
- Need accessible base behavior
- Want composable primitives

**When NOT to Use:**
- Custom component already exists for use case
- Need complex styling (wrap in custom component)

---

## 🔄 Data Flow Architecture

### Data Architecture: Mock-First

```
┌─────────────────────────────────────────────────┐
│          /utils/mockData.ts                     │
│  ┌───────────────────────────────────────────┐ │
│  │  generateMockGames()                      │ │
│  │  generateMockUser()                       │ │
│  │  generateMockCategories()                 │ │
│  │  generateMockTransactions()               │ │
│  └───────────────────────────────────────────┘ │
└─────────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────────┐
│          Page Component                         │
│  const games = generateMockGames(50);           │
│  const user = generateMockUser();               │
└─────────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────────┐
│          Feature Component                      │
│  <GameGrid games={games} />                     │
│  <GameCard {...game} onClick={handleClick} />   │
└─────────────────────────────────────────────────┘
```

### State Management: Context + Local State

**Global State (AppContext):**
```tsx
// /context/AppContext.tsx
interface AppContextType {
  user: User | null;
  cart: Game[];
  wishlist: string[];
  sidebarCollapsed: boolean;
  // + methods to update
}
```

**Usage Pattern:**
```tsx
import { useApp } from '../context/AppContext';

function Component() {
  const { user, cart, addToCart } = useApp();
  // Use global state
}
```

**When to Use Context:**
- User authentication state
- Shopping cart
- Wishlist
- Global UI state (sidebar collapsed)

**When to Use Local State:**
- Form inputs
- Modal open/close
- Component-specific UI state
- Temporary data

### Data Fetching Pattern (Future API Integration)

**Current**: All data from `mockData.ts`  
**Future**: Migrate to API calls

```tsx
// Future pattern with API
import { fetchGames } from '../utils/api';

function DiscoverPage() {
  const [games, setGames] = useState<Game[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchGames().then(setGames).finally(() => setLoading(false));
  }, []);

  if (loading) return <LoadingSpinner />;
  return <GameGrid games={games} />;
}
```

**Migration Path:**
1. Keep `mockData.ts` as fallback
2. Create API functions in `/utils/api.ts`
3. Replace direct mock calls with API calls
4. Add loading/error states to pages

---

## 📐 Layout System

### Grid System

**Responsive Grid Pattern:**
```tsx
// 1 column mobile, 2 tablet, 3 desktop, 4 large
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
  {items.map(item => <ItemCard key={item.id} {...item} />)}
</div>
```

**Standard Grid Configurations:**

| Layout Type | Classes | Use Case |
|-------------|---------|----------|
| Full Width Cards | `grid-cols-1` | Featured content, hero banners |
| Two Column | `grid-cols-1 lg:grid-cols-2` | Dashboard charts, metrics |
| Three Column | `grid-cols-1 md:grid-cols-2 lg:grid-cols-3` | Game catalog, category browse |
| Four Column | `grid-cols-2 md:grid-cols-3 lg:grid-cols-4` | Dense grids, icon grids |

### Carousel/Rail System

**Horizontal Scroll Pattern:**
```tsx
<CarouselRail title="Trending Games" subtitle="Most popular this week">
  {games.map(game => <GameCard key={game.id} {...game} />)}
</CarouselRail>
```

**How It Works:**
1. Container with `overflow-x-auto`
2. Inner flex container with `gap-4`
3. Scroll buttons (left/right arrows)
4. Momentum scrolling on touch devices

**Use Cases:**
- Game showcases
- Category browsing
- Featured collections
- Related items

### Spacing System

**Consistent Spacing Scale (8px base):**

```css
/* Tailwind spacing classes map to: */
gap-2  → 8px   (tight, chip groups)
gap-4  → 16px  (cards in grid)
gap-6  → 24px  (sections)
gap-8  → 32px  (major sections)

p-4    → 16px  (small cards)
p-6    → 24px  (standard cards)
p-8    → 32px  (page padding)
```

**Vertical Rhythm:**
```tsx
<div className="space-y-8">  {/* 32px between sections */}
  <Section1 />
  <Section2 />
  <Section3 />
</div>
```

---

## 🎨 Theming & Styling Strategy

### CSS Custom Properties (Design Tokens)

**Token Priority:**
1. **PixelPulse tokens** (primary system)
2. **shadcn tokens** (only for shadcn components)

**Token Files:**
- `/styles/globals.css` — All design tokens
- See `guidelines/design-tokens/` for usage

### Styling Methods Hierarchy

**Order of preference:**

1. **Use Existing Component**
   ```tsx
   <GameCard {...props} />
   ```

2. **Tailwind Utility Classes**
   ```tsx
   <div className="flex items-center gap-4 p-6 rounded-2xl">
   ```

3. **CSS Custom Properties (Inline)**
   ```tsx
   <div style={{ background: 'var(--bg-panel)', color: 'var(--txt-primary)' }}>
   ```

4. **CSS Modules** (if needed, rare)
   ```tsx
   import styles from './component.module.css';
   <div className={styles.container}>
   ```

**NEVER:**
- ❌ Hardcode colors: `background: '#191D28'`
- ❌ Use Tailwind text sizing: `text-2xl` (violates typography rule)
- ❌ Inline styles without tokens

---

## 🔌 Hooks Architecture

### Custom Hooks (`/hooks/`)

**Available Hooks:**

| Hook | Purpose | Usage |
|------|---------|-------|
| `useLocalStorage` | Persist data to localStorage | User preferences, cart |
| `useDebounce` | Debounce rapid changes | Search input |
| `useMediaQuery` | Responsive breakpoint detection | Conditional rendering |
| `useKeyboardNavigation` | Keyboard shortcuts | Arrow keys, Cmd+K |
| `useClickOutside` | Detect clicks outside element | Close dropdowns |
| `useFocusTrap` | Trap focus in modal | Accessibility |

**Hook Patterns:**

```tsx
// useLocalStorage example
const [cart, setCart] = useLocalStorage<Game[]>('cart', []);

// useDebounce example
const debouncedSearch = useDebounce(searchQuery, 300);

// useMediaQuery example
const isMobile = useMediaQuery('(max-width: 768px)');
```

**Creating New Hooks:**
1. Extract repeated logic from 2+ components
2. Prefix with `use`
3. Return tuple or object (not both)
4. Add TypeScript generics if reusable

---

## 📦 Utilities Architecture

### Utility Modules (`/utils/`)

**Module Responsibilities:**

| File | Purpose | Exports |
|------|---------|---------|
| `mockData.ts` | Generate test data | `generateMock*()` functions |
| `format.ts` | Data formatting | `formatPrice()`, `formatDate()` |
| `validators.ts` | Input validation | `validateEmail()`, `validatePrice()` |
| `helpers.ts` | General helpers | `cn()`, `sleep()`, `randomId()` |
| `constants.ts` | App constants | `MAX_ITEMS`, `ROUTES`, `CATEGORIES` |
| `api.ts` | API calls (future) | `fetchGames()`, `updateGame()` |
| `analytics.ts` | Analytics tracking | `trackEvent.*`, `analytics.*` |

**Pure Function Pattern:**
```tsx
// ✅ Good: Pure, testable
export function formatPrice(price: number | string): string {
  if (price === 0 || price === 'Free') return 'Free';
  if (typeof price === 'string') return price;
  return `$${price.toFixed(2)}`;
}

// ❌ Bad: Side effects
let priceCache = {};
export function formatPrice(price: number): string {
  if (priceCache[price]) return priceCache[price]; // Mutation!
  // ...
}
```

---

## 🧪 Error Handling Strategy

### Error Boundary Pattern

**Root Level:**
```tsx
// App.tsx
<ErrorBoundary>
  <div className="h-screen flex">
    {/* App content */}
  </div>
</ErrorBoundary>
```

**Page Level (future):**
```tsx
// For pages with risky operations
<ErrorBoundary fallback={<PageErrorFallback />}>
  <DashboardPage />
</ErrorBoundary>
```

### Error States in Components

**Pattern:**
```tsx
function GameGrid({ games }: GameGridProps) {
  if (!games || games.length === 0) {
    return <EmptyState message="No games found" />;
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {games.map(game => <GameCard key={game.id} {...game} />)}
    </div>
  );
}
```

---

## 🚀 Performance Considerations

### Current Optimizations

1. **Virtualization**: NOT implemented yet (needed for 1000+ item lists)
2. **Code Splitting**: NOT implemented (all pages imported eagerly)
3. **Image Lazy Loading**: NOT implemented (use `loading="lazy"` on images)
4. **Memoization**: NOT implemented (add React.memo for expensive components)

### Future Optimization Path

**Phase 1: Low-Hanging Fruit**
```tsx
// Lazy load pages
const DashboardPage = lazy(() => import('./pages/DashboardPage'));

// Image lazy loading
<img src={game.image} alt={game.title} loading="lazy" />

// Memo expensive lists
export const GameGrid = React.memo(function GameGrid({ games }) {
  // ...
});
```

**Phase 2: Virtual Scrolling**
```tsx
import { FixedSizeGrid } from 'react-window';

// For 1000+ item grids
<FixedSizeGrid
  columnCount={4}
  rowCount={Math.ceil(games.length / 4)}
  // ...
/>
```

---

## 📱 Responsive Design Strategy

### Breakpoint Strategy

**Mobile First Approach:**

```tsx
// Base: Mobile (375px+)
<div className="p-4 text-sm">

// Tablet (768px+)
<div className="md:p-6 md:text-base">

// Desktop (1024px+)
<div className="lg:p-8 lg:text-lg">
```

**Common Responsive Patterns:**

```tsx
// Sidebar: Hidden on mobile, visible on desktop
<AppSidebar className="hidden lg:flex" />

// Grid: Stack on mobile, grid on desktop
<div className="flex flex-col lg:grid lg:grid-cols-3">

// Text: Smaller on mobile, larger on desktop
<h1 className="text-2xl lg:text-4xl">
```

---

## 🎯 Best Practices Summary

### DO ✅

- Follow page composition pattern exactly
- Use existing components before creating new ones
- Keep components under 300 lines
- Use design tokens for ALL styling
- Implement loading/empty states
- Add TypeScript types to everything
- Use semantic HTML (`main`, `section`, `article`)
- Test responsive behavior 375px → 1920px

### DON'T ❌

- Create pages without PageHeader
- Hardcode colors or spacing values
- Use Tailwind text-sizing classes
- Duplicate component logic
- Ignore accessibility
- Mix styling approaches
- Create deep prop drilling (use context)
- Skip error handling

---

## 🔮 Future Enhancements

### Planned Architecture Changes

1. **React Router Integration**
   - Add URL routing
   - Keep same component structure
   - Map PageType to routes

2. **API Integration**
   - Replace mockData calls with API
   - Add loading/error states
   - Implement caching layer

3. **State Management Upgrade**
   - Add Zustand or Redux if context becomes complex
   - Keep current context as-is for now

4. **Performance Optimization**
   - Code splitting by page
   - Virtualize long lists
   - Image optimization

5. **Testing Infrastructure**
   - Add Vitest + React Testing Library
   - Component unit tests
   - Integration tests for pages

---

## 📚 Related Documentation

- **Component Catalog**: `guidelines/overview-components.md`
- **Design Tokens**: `guidelines/design-tokens/*.md`
- **Master Guidelines**: `guidelines/Guidelines.md`
- **TypeScript Types**: `/types/index.ts`

---

**This system design document is the source of truth for architectural decisions. When in doubt about structure, refer to this document first.**
