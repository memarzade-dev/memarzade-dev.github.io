# Component Library Overview

**System:** PixelPulse × macOS Sequoia Game Store  
**Version:** 1.0.0  
**Total Components:** 60+  
**Purpose:** Complete catalog of available components with usage guidelines

---

## 📋 Table of Contents

1. [Component Philosophy](#component-philosophy)
2. [Component Categories](#component-categories)
3. [Usage Decision Tree](#usage-decision-tree)
4. [Component Catalog](#component-catalog)
5. [Composition Patterns](#composition-patterns)
6. [Common Props Patterns](#common-props-patterns)

---

## 🎯 Component Philosophy

### Core Principles

**1. Reuse Over Reinvention**
- Always check if a component exists before creating new one
- Extend existing components with props rather than duplicating

**2. Composition Over Configuration**
- Components should be composable building blocks
- Complex UIs built from simple components

**3. Accessibility First**
- All components keyboard accessible
- ARIA attributes where needed
- Focus management in modals/overlays

**4. Design System Adherence**
- All components use design tokens
- Consistent spacing, colors, animations
- macOS Sequoia + glassmorphism aesthetic

---

## 📚 Component Categories

### A. Layout Components
Purpose: Page structure and navigation

| Component | Purpose | Location |
|-----------|---------|----------|
| `AppSidebar` | Main navigation sidebar | `/components/AppSidebar.tsx` |
| `PageHeader` | Page title and actions bar | `/components/PageHeader.tsx` |
| `Header` | Legacy global header (being phased out) | `/components/Header.tsx` |
| `ResponsiveContainer` | Responsive wrapper | `/components/ResponsiveContainer.tsx` |

### B. Display Components (Cards)
Purpose: Content showcase and information display

| Component | Purpose | Use Case |
|-----------|---------|----------|
| `GameCard` | Game showcase card | Store catalogs, carousels |
| `AppCard` | App library card | User's owned apps |
| `ArcadeCard` | Apple Arcade style card | Arcade page games |
| `CategoryCard` | Category navigation tile | Browse by category |
| `StatCard` | Metric display card | Dashboard statistics |
| `UpdateCard` | Update feed item | Updates/changelog feed |

### C. Composite Feature Components
Purpose: Multi-element UI sections

| Component | Purpose | Contains |
|-----------|---------|----------|
| `CarouselRail` | Horizontal scrolling rail | Title, scroll buttons, content |
| `GameGrid` | Responsive game grid | Grid layout + cards |
| `QuickStats` | Dashboard metrics overview | Multiple stat cards |
| `ActivityFeed` | Activity timeline | Activity items + timestamps |
| `FeaturedHero` | Featured game banner | Image, title, CTA |
| `HeroBanner` | Generic hero section | Custom content area |

### D. Interactive Components
Purpose: User input and interaction

| Component | Purpose | Type |
|-----------|---------|------|
| `SearchModal` | Global search (Cmd+K) | Modal overlay |
| `AppDetailModal` | Game detail view | Modal dialog |
| `AccountSettingsModal` | User settings | Modal form |
| `ContextMenu` | Right-click menu | Overlay menu |
| `UserMenu` | User account dropdown | Dropdown |
| `FilterBar` | Filter controls | Form controls |
| `BulkActions` | Multi-select actions | Action bar |
| `DateRangePicker` | Date range selector | Date picker |
| `ExportButton` | Export data button | Button + dropdown |

### E. Form & Input Components
Purpose: Data entry

| Component | Purpose | Style |
|-----------|---------|-------|
| `GlassInput` | Glassmorphic text input | PixelPulse design |
| `GlassButton` | Glassmorphic button | PixelPulse design |
| `components/ui/input` | Base input | shadcn primitive |
| `components/ui/button` | Base button | shadcn primitive |
| `components/ui/select` | Dropdown select | shadcn primitive |
| `components/ui/checkbox` | Checkbox input | shadcn primitive |
| `components/ui/switch` | Toggle switch | shadcn primitive |
| `components/ui/textarea` | Multi-line input | shadcn primitive |

### F. Feedback Components
Purpose: Status communication

| Component | Purpose | When to Use |
|-----------|---------|-------------|
| `LoadingSpinner` | Loading indicator | Async operations |
| `EmptyState` | Empty list state | No data scenarios |
| `ErrorBoundary` | Error handling wrapper | Wrap error-prone sections |
| `NotificationCenter` | Toast notifications | Success/error messages |
| `ConfirmDialog` | Confirmation dialog | Destructive actions |
| `FigmaInstallDialog` | Figma plugin prompt | First-time use |

### G. UI Primitives (`/components/ui/`)
Purpose: Accessible base components (shadcn/ui)

**Full List:**
- accordion, alert, alert-dialog, aspect-ratio, avatar
- badge, breadcrumb, button, calendar, card, carousel, chart
- checkbox, collapsible, command, context-menu, dialog, drawer
- dropdown-menu, form, hover-card, input, input-otp, label
- menubar, navigation-menu, pagination, popover, progress
- radio-group, resizable, scroll-area, select, separator, sheet
- sidebar, skeleton, slider, sonner, switch, table, tabs
- textarea, toggle, toggle-group, tooltip
- Plus utilities: `use-mobile.ts`, `utils.ts`

### H. Specialized Components
Purpose: Specific features

| Component | Purpose |
|-----------|---------|
| `CountdownTimer` | Countdown display |
| `ProgressBar` | Progress indicator |
| `AnimatedBackground` | Animated gradient background |
| `DownloadPanel` | Download queue manager |
| `Pagination` | Page navigation |
| `KeyboardShortcutsModal` | Keyboard shortcuts help |

---

## 🌳 Usage Decision Tree

### "What Component Should I Use?"

```
┌─────────────────────────────────────────┐
│  Need to display a game/app?            │
└─────────────────┬───────────────────────┘
                  │
     ┌────────────┴────────────┐
     │                         │
     v                         v
┌────────────────┐    ┌────────────────┐
│ Store catalog? │    │ User's library?│
│ → GameCard     │    │ → AppCard      │
└────────────────┘    └────────────────┘
                         │
                         v
              ┌────────────────────┐
              │ Arcade style?      │
              │ → ArcadeCard       │
              └────────────────────┘

┌─────────────────────────────────────────┐
│  Need to show a list of items?          │
└─────────────────┬───────────────────────┘
                  │
     ┌────────────┴────────────┐
     │                         │
     v                         v
┌────────────────┐    ┌────────────────┐
│ Horizontal?    │    │ Grid layout?   │
│ → CarouselRail │    │ → GameGrid     │
└────────────────┘    └────────────────┘

┌─────────────────────────────────────────┐
│  Need user input?                       │
└─────────────────┬───────────────────────┘
                  │
     ┌────────────┴────────────┐
     │                         │
     v                         v
┌────────────────┐    ┌────────────────┐
│ Glassmorphic?  │    │ Standard form? │
│ → GlassInput   │    │ → ui/input     │
│ → GlassButton  │    │ → ui/button    │
└────────────────┘    └────────────────┘

┌─────────────────────────────────────────┐
│  Need a modal/dialog?                   │
└─────────────────┬───────────────────────┘
                  │
     ┌────────────┴────────────────────────┐
     │                         │            │
     v                         v            v
┌──────────────┐    ┌───────────────┐ ┌────────────┐
│ Game detail? │    │ User settings?│ │ Custom?    │
│ → AppDetail  │    │ → AccountSett │ │ → ui/dialog│
│   Modal      │    │   ingsModal   │ └────────────┘
└──────────────┘    └───────────────┘

┌─────────────────────────────────────────┐
│  Need to show status/feedback?          │
└─────────────────┬───────────────────────┘
                  │
     ┌────────────┴────────────┐
     │                         │
     v                         v
┌────────────────┐    ┌────────────────┐
│ Loading?       │    │ No data?       │
│ → LoadingSpinn │    │ → EmptyState   │
└────────────────┘    └────────────────┘
                         │
                         v
              ┌────────────────────┐
              │ Success/error?     │
              │ → Notification     │
              │   Center + toast   │
              └────────────────────┘
```

---

## 🎨 Component Catalog (Detailed)

### Layout Components

#### AppSidebar
**Purpose**: Main navigation sidebar with collapsible state

**Props**:
```typescript
interface AppSidebarProps {
  currentPage: PageType;
  onPageChange: (page: PageType) => void;
}
```

**Features**:
- 240px width (expanded), 80px (collapsed)
- Glassmorphic background with blur
- Hover effects on nav items
- Active page indicator
- User profile section at bottom

**Usage**:
```tsx
<AppSidebar 
  currentPage="dashboard"
  onPageChange={(page) => setCurrentPage(page)}
/>
```

**When to Use**: Always use in App.tsx root, don't create custom sidebars

---

#### PageHeader
**Purpose**: Consistent page title and action area

**Props**:
```typescript
interface PageHeaderProps {
  title: string;
  subtitle?: string;
  rightContent?: ReactNode;
  showSearch?: boolean;
}
```

**Features**:
- 72px height
- Title + optional subtitle
- Optional right-side actions
- Optional search input
- Glassmorphic background

**Usage**:
```tsx
<PageHeader 
  title="Dashboard"
  subtitle="Welcome back!"
  rightContent={<Button>Export</Button>}
/>
```

**When to Use**: First element in EVERY page component

---

### Display Components (Cards)

#### GameCard
**Purpose**: Primary game showcase card for store catalogs

**Props**:
```typescript
interface GameCardProps {
  title: string;
  subtitle: string;
  genre: string;
  price: string;
  image: string;
  badge?: string;
  rating?: number;
  owned?: boolean;
  onClick?: () => void;
}
```

**Features**:
- 280px fixed width
- 140% aspect ratio image
- Gradient overlay on image
- Optional badge (top-left)
- Star rating (top-right)
- Hover glow effect
- Scale on hover (1.02x)
- Action button (Get/Download)

**Visual States**:
- Default: "Get" button with gradient
- Owned: "Download" button grayed out
- Hover: Scale + glow + image zoom

**Usage**:
```tsx
<GameCard
  title="Cyberpunk 2077"
  subtitle="CD Projekt Red"
  genre="RPG"
  price="$29.99"
  image={imageUrl}
  badge="New"
  rating={4.5}
  owned={false}
  onClick={() => handleGameClick(gameId)}
/>
```

**When to Use**:
- Store discovery pages
- Featured game carousels
- Search results
- Category browsing

**When NOT to Use**:
- User's library (use AppCard)
- Apple Arcade page (use ArcadeCard)

---

#### AppCard
**Purpose**: Apps in user's library/account

**Props**:
```typescript
interface AppCardProps {
  name: string;
  subtitle: string;
  icon: string;
  size: string;
  lastUpdated: string;
  onClick?: () => void;
}
```

**Features**:
- Horizontal layout
- App icon (64px)
- Size + update info
- Download/Open button
- Subtle hover effect

**Usage**:
```tsx
<AppCard
  name="GarageBand"
  subtitle="Music Creation"
  icon={iconUrl}
  size="2.3 GB"
  lastUpdated="2 days ago"
/>
```

**When to Use**: Account page, purchased apps list

---

#### ArcadeCard
**Purpose**: Apple Arcade-styled game cards

**Props**:
```typescript
interface ArcadeCardProps {
  name: string;
  subtitle: string;
  coverImage: string;
  category: string;
  onClick?: () => void;
}
```

**Features**:
- Wide aspect ratio (16:10)
- Minimal text overlay
- Premium feel
- Subtle animations

**Usage**:
```tsx
<ArcadeCard
  name="Monument Valley"
  subtitle="Puzzle Adventure"
  coverImage={imageUrl}
  category="Puzzle"
/>
```

**When to Use**: Arcade page exclusively

---

#### StatCard
**Purpose**: Display metrics and statistics

**Props**:
```typescript
interface StatCardProps {
  title: string;
  value: string | number;
  change?: number; // Percentage change
  icon?: ReactNode;
  trend?: 'up' | 'down' | 'neutral';
}
```

**Features**:
- Large value display
- Optional trend indicator
- Icon support
- Color-coded change (green/red)

**Usage**:
```tsx
<StatCard
  title="Total Revenue"
  value="$62,450"
  change={18.2}
  trend="up"
  icon={<DollarSign />}
/>
```

**When to Use**: Dashboards, analytics pages

---

### Composite Feature Components

#### CarouselRail
**Purpose**: Horizontal scrolling container for cards

**Props**:
```typescript
interface CarouselRailProps {
  title: string;
  subtitle?: string;
  children: ReactNode;
  onSeeAll?: () => void;
}
```

**Features**:
- Section header with title/subtitle
- Left/right scroll buttons
- Smooth momentum scrolling
- "See All" link
- Hides scroll buttons at edges

**Usage**:
```tsx
<CarouselRail 
  title="Trending Now" 
  subtitle="Most popular this week"
  onSeeAll={() => navigate('trending')}
>
  {games.map(game => <GameCard key={game.id} {...game} />)}
</CarouselRail>
```

**When to Use**:
- Homepage game showcases
- Category previews
- "You might also like" sections
- Any horizontal scrolling content

**Composition**:
- Can contain any card component
- Works best with 280px width cards
- Auto-handles spacing (gap-4)

---

#### GameGrid
**Purpose**: Responsive grid layout for games

**Props**:
```typescript
interface GameGridProps {
  games: Game[];
  onGameClick?: (gameId: string) => void;
}
```

**Features**:
- Responsive columns (1 → 2 → 3 → 4)
- Auto-creates GameCard components
- Handles empty state
- Consistent spacing

**Usage**:
```tsx
<GameGrid 
  games={filteredGames}
  onGameClick={handleClick}
/>
```

**When to Use**: Any full-width game listing page

---

#### QuickStats
**Purpose**: Dashboard metrics overview (4-stat layout)

**Props**:
```typescript
interface QuickStatsProps {
  totalRevenue: string;
  totalSales: number;
  activeUsers: number;
  growthRate: number;
}
```

**Usage**:
```tsx
<QuickStats
  totalRevenue="$62,450"
  totalSales={5800}
  activeUsers={12450}
  growthRate={18.2}
/>
```

**When to Use**: Dashboard page top section

---

#### ActivityFeed
**Purpose**: Timeline of activities/events

**Props**:
```typescript
interface Activity {
  id: string;
  type: 'purchase' | 'download' | 'review' | 'update';
  title: string;
  description: string;
  timestamp: Date;
}

interface ActivityFeedProps {
  activities: Activity[];
  maxItems?: number;
}
```

**Features**:
- Chronological ordering
- Type-based icons
- Relative timestamps
- Scrollable list

**Usage**:
```tsx
<ActivityFeed activities={recentActivities} maxItems={10} />
```

---

### Interactive Components

#### SearchModal
**Purpose**: Global search overlay (Cmd+K)

**Props**:
```typescript
interface SearchModalProps {
  open: boolean;
  onClose: () => void;
  onSearch: (query: string) => void;
}
```

**Features**:
- Full-screen glassmorphic overlay
- Cmd+K keyboard shortcut
- Recent searches
- Category filters
- Escape to close

**Usage**:
```tsx
<SearchModal
  open={searchOpen}
  onClose={() => setSearchOpen(false)}
  onSearch={handleSearch}
/>
```

**When to Use**: App root level, triggered by Cmd+K or search icon

---

#### AppDetailModal
**Purpose**: Full game/app detail view

**Props**:
```typescript
interface AppDetailModalProps {
  appId: string;
  onClose: () => void;
}
```

**Features**:
- Full screen modal
- Screenshot gallery
- Description and features
- Reviews section
- Purchase/download CTA
- Close button + Escape key

**Usage**:
```tsx
<AppDetailModal
  appId="game-123"
  onClose={() => setSelectedApp(null)}
/>
```

---

#### FilterBar
**Purpose**: Filtering controls for lists

**Props**:
```typescript
interface FilterBarProps {
  filters: Filter[];
  onFilterChange: (filters: Filter[]) => void;
  onSort?: (sort: SortOption) => void;
}
```

**Features**:
- Multiple filter dropdowns
- Sort options
- Clear all button
- Active filter count badge

**Usage**:
```tsx
<FilterBar
  filters={activeFilters}
  onFilterChange={setFilters}
  onSort={setSortOption}
/>
```

**When to Use**: Above GameGrid or any filterable list

---

### Form & Input Components

#### GlassInput
**Purpose**: Glassmorphic text input

**Props**:
```typescript
interface GlassInputProps extends InputHTMLAttributes<HTMLInputElement> {
  icon?: ReactNode;
  error?: string;
}
```

**Features**:
- Glassmorphic background
- Optional left icon
- Error state styling
- Focus glow effect

**Usage**:
```tsx
<GlassInput
  placeholder="Search games..."
  icon={<Search size={18} />}
  value={query}
  onChange={(e) => setQuery(e.target.value)}
/>
```

**When to Use**: Forms in modals, search inputs with glass aesthetic

---

#### GlassButton
**Purpose**: Glassmorphic button

**Props**:
```typescript
interface GlassButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
}
```

**Usage**:
```tsx
<GlassButton variant="primary" size="md">
  Get Game
</GlassButton>
```

**When to Use**: Primary CTAs in glassmorphic contexts

---

### Feedback Components

#### LoadingSpinner
**Purpose**: Loading state indicator

**Props**:
```typescript
interface LoadingSpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  message?: string;
}
```

**Usage**:
```tsx
<LoadingSpinner size="lg" message="Loading games..." />
```

---

#### EmptyState
**Purpose**: Empty list placeholder

**Props**:
```typescript
interface EmptyStateProps {
  icon?: ReactNode;
  title: string;
  message: string;
  action?: ReactNode;
}
```

**Features**:
- Icon illustration
- Title and message
- Optional CTA button

**Usage**:
```tsx
<EmptyState
  icon={<Package size={48} />}
  title="No games found"
  message="Try adjusting your filters"
  action={<Button onClick={clearFilters}>Clear Filters</Button>}
/>
```

**When to Use**: Any list that can be empty (search, filters, categories)

---

#### NotificationCenter + Toaster
**Purpose**: Toast notifications for actions

**Usage**:
```tsx
// In App.tsx root
<NotificationCenter notifications={notifications} onDismiss={dismiss} />
<Toaster position="bottom-right" />

// In components
import { toast } from 'sonner@2.0.3';
toast.success('Game added to cart!');
toast.error('Purchase failed');
```

**When to Use**: Action feedback (add to cart, save, delete, etc.)

---

## 🧩 Composition Patterns

### Pattern 1: Card in Rail

```tsx
<CarouselRail title="Trending Games">
  {games.map(game => (
    <GameCard key={game.id} {...game} onClick={handleClick} />
  ))}
</CarouselRail>
```

### Pattern 2: Grid with Filter

```tsx
<FilterBar filters={filters} onFilterChange={setFilters} />
<GameGrid games={filteredGames} onGameClick={handleClick} />
```

### Pattern 3: Modal with Form

```tsx
<Dialog open={open} onOpenChange={setOpen}>
  <DialogContent>
    <DialogHeader>
      <DialogTitle>Add Game</DialogTitle>
    </DialogHeader>
    <form onSubmit={handleSubmit}>
      <GlassInput placeholder="Game title" {...} />
      <GlassButton type="submit">Add</GlassButton>
    </form>
  </DialogContent>
</Dialog>
```

### Pattern 4: Page with Multiple Sections

```tsx
export function DashboardPage() {
  return (
    <>
      <PageHeader title="Dashboard" />
      <main className="flex-1 overflow-y-auto">
        <div className="px-8 py-6 space-y-8">
          <QuickStats {...} />
          <CarouselRail title="Featured">{...}</CarouselRail>
          <ActivityFeed activities={...} />
        </div>
      </main>
    </>
  );
}
```

---

## 🔧 Common Props Patterns

### Standard Callback Props

```typescript
// Click handlers
onClick?: () => void;
onSelect?: (id: string) => void;

// Form handlers
onChange?: (value: string) => void;
onSubmit?: (data: FormData) => void;

// Modal handlers
onClose?: () => void;
onConfirm?: () => void;
onCancel?: () => void;
```

### Standard Data Props

```typescript
// Display data
title: string;
subtitle?: string;
description?: string;

// Visual props
icon?: ReactNode;
image?: string;
badge?: string;

// State props
isActive?: boolean;
isLoading?: boolean;
isDisabled?: boolean;
```

### Render Props Pattern

```tsx
interface ComponentProps {
  children: ReactNode; // For composition
  renderAction?: () => ReactNode; // For custom actions
}
```

---

## 🎯 Component Selection Guidelines

### When to Use Which Card

| Scenario | Component | Reason |
|----------|-----------|--------|
| Store catalog | `GameCard` | Pricing, "Get" button, showcase |
| User's games | `AppCard` | "Download" action, size info |
| Arcade exclusive | `ArcadeCard` | Premium, minimal aesthetic |
| Category preview | `CategoryCard` | Icon-based navigation |
| Metrics | `StatCard` | Number-focused display |
| Updates list | `UpdateCard` | Version, changelog info |

### When to Use Which Input

| Scenario | Component | Reason |
|----------|-----------|--------|
| Glassmorphic form | `GlassInput` | Matches design aesthetic |
| Standard form | `ui/input` | Accessible, standard |
| Rich form | `ui/*` components | Full form primitives |

### When to Use Which Button

| Scenario | Component | Reason |
|----------|-----------|--------|
| Primary CTA | `GlassButton` + gradient | Attention-grabbing |
| Secondary action | `ui/button` variant="outline" | Standard UI |
| Tertiary | `ui/button` variant="ghost" | Subtle action |
| Icon only | `ui/button` variant="ghost" size="icon" | Minimal UI |

---

## ✅ Best Practices

### DO ✅

- **Check catalog before creating** — Component likely exists
- **Use semantic variants** — Don't create GameCard2, extend GameCard
- **Compose components** — Build complex UIs from simple parts
- **Follow prop patterns** — Consistent naming across components
- **Pass callbacks down** — Parent handles state, child triggers events
- **Use children prop** — For flexible composition

### DON'T ❌

- **Duplicate components** — Extend existing instead
- **Mix design systems** — Use either Glass* or ui/* consistently
- **Ignore accessibility** — All components must be accessible
- **Hardcode data** — Accept props for all display data
- **Create overly complex props** — Keep interfaces simple
- **Skip empty/loading states** — Handle all states

---

## 📚 Related Documentation

- **Individual Component Guidelines**: `guidelines/components/[name].md` (when created)
- **Design Tokens**: `guidelines/design-tokens/*.md`
- **System Architecture**: `guidelines/overview-system-design.md`
- **Master Guidelines**: `guidelines/Guidelines.md`

---

**This component catalog is comprehensive. Before creating a new component, consult this document to find if an existing component can be used or extended.**
