import { ChevronRight, X } from 'lucide-react';

interface AccountSettingsModalProps {
  onClose: () => void;
}

interface SettingRow {
  label: string;
  value?: string;
  showChevron?: boolean;
}

const settings: SettingRow[] = [
  { label: 'Apple Account', value: 'alimemarzade@icloud.com', showChevron: true },
  { label: 'Payment Methods', value: 'None', showChevron: true },
  { label: 'Billing Address', value: '3453 Memorial Road', showChevron: true },
  { label: 'Country or Region', value: 'Canada', showChevron: true },
  { label: 'Add Money to Account', showChevron: false },
  { label: 'Balance', value: '$10.00', showChevron: false },
  { label: 'Purchase History', showChevron: true },
  { label: 'Subscriptions', showChevron: true },
  { label: 'Hidden Purchases', showChevron: true },
  { label: 'Nickname', value: 'Memarzade.dev', showChevron: true },
];

export function AccountSettingsModal({ onClose }: AccountSettingsModalProps) {
  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center"
      style={{
        background: 'rgba(0, 0, 0, 0.65)',
        backdropFilter: 'blur(10px)',
      }}
      onClick={onClose}
    >
      <div
        className="relative rounded-2xl overflow-hidden"
        style={{
          width: '480px',
          background: 'rgba(44, 44, 46, 0.98)',
          backdropFilter: 'blur(40px) saturate(1.2)',
          boxShadow: '0 20px 60px rgba(0, 0, 0, 0.5)',
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-5 pt-5 pb-4 flex items-center justify-between">
          <h2
            style={{
              fontSize: '17px',
              fontWeight: 600,
              color: '#FFFFFF',
              fontFamily: '-apple-system, BlinkMacSystemFont, "SF Pro Display", sans-serif',
            }}
          >
            Account Settings
          </h2>
          <button
            onClick={onClose}
            className="p-1 rounded-lg transition-colors hover:bg-white/10"
            style={{ color: '#8E8E93' }}
          >
            <X size={18} />
          </button>
        </div>

        {/* Settings List */}
        <div className="px-5 pb-5">
          <div 
            className="rounded-xl overflow-hidden"
            style={{
              background: 'rgba(58, 58, 60, 0.5)',
            }}
          >
            {settings.map((setting, index) => (
              <div key={index}>
                <button
                  className="w-full px-4 py-3 flex items-center justify-between transition-colors hover:bg-white/5"
                  style={{
                    borderBottom: index < settings.length - 1 ? '1px solid rgba(255, 255, 255, 0.08)' : 'none',
                  }}
                >
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <span
                      className="truncate"
                      style={{
                        fontSize: '14px',
                        fontWeight: 400,
                        color: '#FFFFFF',
                        textAlign: 'left',
                      }}
                    >
                      {setting.label}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 flex-shrink-0">
                    {setting.value && (
                      <span
                        className="tabular-nums"
                        style={{
                          fontSize: '14px',
                          color: '#8E8E93',
                        }}
                      >
                        {setting.value}
                      </span>
                    )}
                    {setting.showChevron && (
                      <ChevronRight size={16} strokeWidth={2} style={{ color: '#8E8E93' }} />
                    )}
                  </div>
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Done Button */}
        <div className="px-5 pb-5 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 rounded-lg transition-colors"
            style={{
              background: '#007AFF',
              fontSize: '14px',
              fontWeight: 600,
              color: '#FFFFFF',
            }}
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
