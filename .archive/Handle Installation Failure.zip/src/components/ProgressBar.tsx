import { useEffect, useState } from 'react';
import { motion } from 'motion/react';

interface ProgressBarProps {
  value: number;
  max?: number;
  label?: string;
  showPercentage?: boolean;
  animated?: boolean;
  color?: 'primary' | 'success' | 'warning' | 'error';
  size?: 'sm' | 'md' | 'lg';
}

export function ProgressBar({
  value,
  max = 100,
  label,
  showPercentage = true,
  animated = true,
  color = 'primary',
  size = 'md',
}: ProgressBarProps) {
  const [displayValue, setDisplayValue] = useState(0);
  const percentage = Math.min((value / max) * 100, 100);

  useEffect(() => {
    if (animated) {
      const timer = setTimeout(() => setDisplayValue(percentage), 100);
      return () => clearTimeout(timer);
    } else {
      setDisplayValue(percentage);
    }
  }, [percentage, animated]);

  const sizeStyles = {
    sm: { height: '6px', fontSize: 'var(--text-xs)' },
    md: { height: '8px', fontSize: 'var(--text-sm)' },
    lg: { height: '12px', fontSize: 'var(--text-base)' },
  };

  const colorStyles = {
    primary: 'var(--gradient-brand-90)',
    success: 'linear-gradient(90deg, #55E6C1, #3ECAA0)',
    warning: 'linear-gradient(90deg, #FFB84D, #FF9F1C)',
    error: 'linear-gradient(90deg, #FF6B6B, #EE5A52)',
  };

  return (
    <div className="w-full">
      {(label || showPercentage) && (
        <div className="flex justify-between items-center mb-2">
          {label && (
            <label
              style={{
                fontSize: sizeStyles[size].fontSize,
                fontWeight: 'var(--font-weight-medium)',
                color: 'var(--txt-primary)',
              }}
            >
              {label}
            </label>
          )}
          {showPercentage && (
            <span
              className="tabular-nums"
              style={{
                fontSize: sizeStyles[size].fontSize,
                color: 'var(--txt-secondary)',
              }}
            >
              {Math.round(displayValue)}%
            </span>
          )}
        </div>
      )}

      <div
        className="relative w-full overflow-hidden"
        style={{
          height: sizeStyles[size].height,
          background: 'rgba(255, 255, 255, 0.05)',
          borderRadius: 'var(--radius-full)',
          border: '1px solid var(--border-glass)',
        }}
      >
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${displayValue}%` }}
          transition={{
            duration: animated ? 1 : 0,
            ease: 'easeOut',
          }}
          className="absolute inset-y-0 left-0"
          style={{
            background: colorStyles[color],
            borderRadius: 'var(--radius-full)',
            boxShadow: color === 'primary' ? 'var(--shadow-glow-primary)' : undefined,
          }}
        >
          {/* Shine effect */}
          <div
            className="absolute inset-0 animate-shimmer"
            style={{
              background: 'linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent)',
              backgroundSize: '200% 100%',
            }}
          />
        </motion.div>
      </div>
    </div>
  );
}

// Add shimmer animation to globals.css or inline styles
const shimmerKeyframes = `
@keyframes shimmer {
  0% { background-position: -200% 0; }
  100% { background-position: 200% 0; }
}

.animate-shimmer {
  animation: shimmer 2s infinite;
}
`;
