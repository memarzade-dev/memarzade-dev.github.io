import { useState, useEffect } from 'react';
import { X, Check, AlertCircle, Info, AlertTriangle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export type NotificationType = 'success' | 'error' | 'info' | 'warning';

export interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  message?: string;
  duration?: number;
}

interface NotificationCenterProps {
  notifications: Notification[];
  onDismiss: (id: string) => void;
}

export function NotificationCenter({ notifications, onDismiss }: NotificationCenterProps) {
  return (
    <div className="fixed top-4 right-4 z-50 space-y-3" style={{ maxWidth: '420px' }}>
      <AnimatePresence>
        {notifications.map((notification) => (
          <NotificationItem
            key={notification.id}
            notification={notification}
            onDismiss={onDismiss}
          />
        ))}
      </AnimatePresence>
    </div>
  );
}

function NotificationItem({
  notification,
  onDismiss,
}: {
  notification: Notification;
  onDismiss: (id: string) => void;
}) {
  useEffect(() => {
    if (notification.duration) {
      const timer = setTimeout(() => {
        onDismiss(notification.id);
      }, notification.duration);
      return () => clearTimeout(timer);
    }
  }, [notification, onDismiss]);

  const typeConfig = {
    success: {
      icon: Check,
      bgColor: 'rgba(16, 185, 129, 0.1)',
      borderColor: 'rgba(16, 185, 129, 0.3)',
      iconColor: '#10B981',
    },
    error: {
      icon: AlertCircle,
      bgColor: 'rgba(239, 68, 68, 0.1)',
      borderColor: 'rgba(239, 68, 68, 0.3)',
      iconColor: '#EF4444',
    },
    warning: {
      icon: AlertTriangle,
      bgColor: 'rgba(251, 146, 60, 0.1)',
      borderColor: 'rgba(251, 146, 60, 0.3)',
      iconColor: '#FB923C',
    },
    info: {
      icon: Info,
      bgColor: 'rgba(59, 130, 246, 0.1)',
      borderColor: 'rgba(59, 130, 246, 0.3)',
      iconColor: '#3B82F6',
    },
  };

  const config = typeConfig[notification.type];
  const Icon = config.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: -20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, x: 100, scale: 0.95 }}
      transition={{ duration: 0.2, ease: 'easeOut' }}
      className="p-4 rounded-xl backdrop-blur-xl"
      style={{
        background: 'var(--surface-glass)',
        border: `1px solid ${config.borderColor}`,
        boxShadow: 'var(--shadow-lg)',
      }}
    >
      <div className="flex items-start gap-3">
        <div
          className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
          style={{
            background: config.bgColor,
            border: `1px solid ${config.borderColor}`,
          }}
        >
          <Icon size={20} style={{ color: config.iconColor }} />
        </div>

        <div className="flex-1 min-w-0">
          <h4
            className="mb-1"
            style={{
              fontSize: '15px',
              fontWeight: 600,
              color: 'var(--txt-primary)',
            }}
          >
            {notification.title}
          </h4>
          {notification.message && (
            <p style={{ fontSize: '13px', color: 'var(--txt-secondary)', lineHeight: '1.4' }}>
              {notification.message}
            </p>
          )}
        </div>

        <button
          onClick={() => onDismiss(notification.id)}
          className="p-1 rounded-lg transition-all hover:bg-white/10 flex-shrink-0"
          style={{ color: 'var(--txt-tertiary)' }}
          aria-label="Dismiss notification"
        >
          <X size={16} />
        </button>
      </div>
    </motion.div>
  );
}

// Hook for managing notifications
export function useNotifications() {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const addNotification = (notification: Omit<Notification, 'id'>) => {
    const id = Math.random().toString(36).substring(7);
    setNotifications((prev) => [...prev, { ...notification, id, duration: notification.duration || 5000 }]);
  };

  const dismissNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  return {
    notifications,
    addNotification,
    dismissNotification,
  };
}
