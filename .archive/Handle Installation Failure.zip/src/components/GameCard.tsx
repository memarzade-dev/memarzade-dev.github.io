import { ShoppingCart, Download, Star } from 'lucide-react';

interface GameCardProps {
  title: string;
  subtitle: string;
  genre: string;
  price: string;
  image: string;
  badge?: string;
  rating?: number;
  owned?: boolean;
  onClick?: () => void;
}

export function GameCard({ 
  title, 
  subtitle, 
  genre, 
  price, 
  image, 
  badge,
  rating = 4.5,
  owned = false,
  onClick
}: GameCardProps) {
  return (
    <div
      role="button"
      tabIndex={0}
      onClick={onClick}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onClick?.();
        }
      }}
      aria-label={`${title} - ${genre} - ${price}`}
      className="group relative flex-shrink-0 transition-all duration-[220ms] ease-out hover:scale-[1.02] cursor-pointer"
      style={{
        width: '280px',
        borderRadius: 'var(--radius-card)',
        background: 'var(--bg-panel)',
        boxShadow: 'var(--shadow-sm)',
      }}
    >
      {/* Hover Glow Effect */}
      <div
        className="absolute -inset-0.5 rounded-[calc(var(--radius-card)+2px)] opacity-0 group-hover:opacity-100 transition-opacity duration-300"
        style={{
          background: 'linear-gradient(135deg, var(--brand-start), var(--brand-end))',
          filter: 'blur(12px)',
          zIndex: -1,
        }}
      />

      {/* Image Container */}
      <div className="relative overflow-hidden" style={{ borderRadius: 'var(--radius-card) var(--radius-card) 0 0' }}>
        <div className="relative" style={{ paddingBottom: '140%' }}>
          <img
            src={image}
            alt={title}
            className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
          {/* Gradient Overlay */}
          <div
            className="absolute inset-0"
            style={{
              background: 'linear-gradient(to bottom, transparent 0%, rgba(14, 15, 19, 0.8) 100%)',
            }}
          />
        </div>

        {/* Badge */}
        {badge && (
          <div
            className="absolute top-3 left-3 px-3 py-1.5 rounded-lg backdrop-blur-xl"
            style={{
              background: 'rgba(111, 125, 255, 0.2)',
              border: '1px solid rgba(111, 125, 255, 0.4)',
              fontSize: '12px',
              fontWeight: 600,
              color: 'white',
            }}
          >
            {badge}
          </div>
        )}

        {/* Rating */}
        <div
          className="absolute top-3 right-3 flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg backdrop-blur-xl"
          style={{
            background: 'rgba(0, 0, 0, 0.4)',
            border: '1px solid rgba(255, 255, 255, 0.1)',
          }}
        >
          <Star size={12} fill="#FFB800" color="#FFB800" />
          <span className="tabular-nums" style={{ fontSize: '12px', fontWeight: 600, color: 'white' }}>
            {rating}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-3">
        <div>
          <h3
            className="truncate mb-1"
            style={{
              fontSize: '16px',
              fontWeight: 600,
              color: 'var(--txt-primary)',
            }}
          >
            {title}
          </h3>
          <p
            className="truncate"
            style={{
              fontSize: '13px',
              color: 'var(--txt-tertiary)',
            }}
          >
            {subtitle}
          </p>
        </div>

        <div className="flex items-center justify-between">
          <span
            style={{
              fontSize: '13px',
              color: 'var(--txt-secondary)',
              fontWeight: 500,
            }}
          >
            {genre}
          </span>
          <span
            className="tabular-nums"
            style={{
              fontSize: '18px',
              fontWeight: 700,
              color: 'var(--txt-primary)',
            }}
          >
            {price}
          </span>
        </div>

        {/* Action Button */}
        <button
          aria-label={owned ? `Download ${title}` : `Purchase ${title} for ${price}`}
          className="w-full py-2.5 rounded-xl transition-all hover:scale-[1.02] active:scale-100 flex items-center justify-center gap-2"
          style={{
            background: owned 
              ? 'rgba(255, 255, 255, 0.06)'
              : 'linear-gradient(135deg, var(--brand-start), var(--brand-end))',
            boxShadow: owned ? 'none' : 'var(--shadow-glow)',
            color: 'white',
            fontWeight: 600,
            fontSize: '14px',
          }}
        >
          {owned ? (
            <>
              <Download size={16} />
              Download
            </>
          ) : (
            <>
              <ShoppingCart size={16} />
              Get
            </>
          )}
        </button>
      </div>
    </div>
  );
}