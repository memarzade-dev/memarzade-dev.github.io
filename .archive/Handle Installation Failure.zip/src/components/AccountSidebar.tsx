import { 
  Search, 
  Sparkles, 
  Gamepad2, 
  Palette, 
  Briefcase, 
  Trophy, 
  Code, 
  Grid3x3, 
  Bell 
} from 'lucide-react';

const navItems = [
  { icon: Search, label: 'Search' },
  { icon: Sparkles, label: 'Discover' },
  { icon: Gamepad2, label: 'Arcade' },
  { icon: Palette, label: 'Create' },
  { icon: Briefcase, label: 'Work' },
  { icon: Trophy, label: 'Play' },
  { icon: Code, label: 'Develop' },
  { icon: Grid3x3, label: 'Categories' },
  { icon: Bell, label: 'Updates' },
];

export function AccountSidebar() {
  return (
    <aside 
      className="flex flex-col items-center py-4 gap-2"
      style={{
        width: '64px',
        background: '#1C1C1E',
        borderRight: '1px solid rgba(255, 255, 255, 0.08)',
      }}
    >
      {/* Nav Items */}
      <div className="flex flex-col gap-1 flex-1">
        {navItems.map((item, index) => {
          const Icon = item.icon;
          return (
            <button
              key={index}
              className="w-11 h-11 flex items-center justify-center rounded-lg transition-colors hover:bg-white/5"
              style={{ color: index === 0 ? '#8E8E93' : '#8E8E93' }}
              title={item.label}
            >
              <Icon size={22} strokeWidth={1.5} />
            </button>
          );
        })}
      </div>

      {/* User Avatar */}
      <div className="mt-auto">
        <div 
          className="w-9 h-9 rounded-full overflow-hidden cursor-pointer"
          style={{
            background: 'linear-gradient(135deg, #667EEA 0%, #764BA2 100%)',
          }}
        >
          <img
            src="https://images.unsplash.com/photo-1570170609489-43197f518df0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBwb3J0cmFpdCUyMHBlcnNvbnxlbnwxfHx8fDE3NjEzOTc3OTJ8MA&ixlib=rb-4.1.0&q=80&w=1080"
            alt="Ali Memarzade"
            className="w-full h-full object-cover"
          />
        </div>
      </div>
    </aside>
  );
}
