import { ChevronRight } from 'lucide-react';
import { useRef } from 'react';

interface AppRowProps {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  onSeeAll: () => void;
}

export function AppRow({ title, subtitle, children, onSeeAll }: AppRowProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-end justify-between">
        <div>
          <h2
            className="tracking-tight"
            style={{
              fontSize: '24px',
              fontWeight: 600,
              color: '#FFFFFF',
            }}
          >
            {title}
          </h2>
          {subtitle && (
            <p style={{ fontSize: '13px', color: '#8E8E93', marginTop: '2px' }}>
              {subtitle}
            </p>
          )}
        </div>

        <button
          onClick={onSeeAll}
          className="flex items-center gap-1 transition-opacity hover:opacity-70"
          style={{
            fontSize: '14px',
            fontWeight: 500,
            color: '#007AFF',
          }}
        >
          See All
          <ChevronRight size={16} />
        </button>
      </div>

      {/* Scrollable Row */}
      <div
        ref={scrollRef}
        className="flex gap-4 overflow-x-auto hide-scrollbar pb-2"
        style={{
          scrollSnapType: 'x mandatory',
        }}
      >
        {children}
      </div>
    </div>
  );
}
