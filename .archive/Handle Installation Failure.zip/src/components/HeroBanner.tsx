import { Play, Info } from 'lucide-react';

export function HeroBanner() {
  return (
    <div
      className="relative overflow-hidden group"
      style={{
        height: '480px',
        borderRadius: 'var(--radius-panel)',
        background: 'var(--bg-panel)',
      }}
      role="article"
      aria-label="Halloween Event - Featured"
    >
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1760577388672-7e3262e8e6e2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYWxsb3dlZW4lMjBwdXJwbGUlMjBhdG1vc3BoZXJlfGVufDF8fHx8MTc2MTQyMzcwMnww&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Halloween Event with purple atmosphere"
          className="w-full h-full object-cover transition-transform duration-[600ms] ease-out group-hover:scale-105"
        />
        {/* Gradient Overlay */}
        <div
          className="absolute inset-0"
          style={{
            background: 'linear-gradient(to right, var(--bg-app-solid-95) 0%, var(--bg-app-solid-60) 50%, transparent 100%)',
          }}
          aria-hidden="true"
        />
      </div>

      {/* Content */}
      <div className="relative h-full flex flex-col justify-end p-12">
        <div className="max-w-2xl space-y-4">
          {/* Badge */}
          <div
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full backdrop-blur-xl"
            style={{
              background: 'var(--color-primary-alpha)',
              border: '1px solid var(--border-glass-light)',
            }}
          >
            <span
              className="w-2 h-2 rounded-full"
              style={{ background: 'var(--gradient-brand)' }}
              aria-hidden="true"
            />
            <span style={{ color: 'var(--txt-primary)', fontSize: 'var(--text-sm)', fontWeight: 'var(--font-weight-semibold)' }}>
              Halloween Event • Limited Time
            </span>
          </div>

          {/* Title */}
          <h2
            className="tracking-tight leading-tight"
            style={{
              fontSize: 'var(--text-5xl)',
              fontWeight: 'var(--font-weight-bold)',
              color: 'var(--txt-primary)',
            }}
          >
            Treat yourself to these
            <br />
            <span
              style={{
                background: 'var(--gradient-brand)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
              }}
            >
              terrifying titles
            </span>
          </h2>

          {/* Description */}
          <p style={{ color: 'var(--txt-secondary)', fontSize: 'var(--text-lg)', lineHeight: '1.6' }}>
            Explore spine-chilling adventures with exclusive discounts on horror classics
            and new releases. Offer ends October 31st.
          </p>

          {/* Actions */}
          <div className="flex items-center gap-4 pt-4">
            <button
              className="flex items-center gap-2 px-6 py-3 rounded-full transition-all duration-[220ms] ease-out hover:scale-[1.02] active:scale-100"
              style={{
                background: 'var(--gradient-brand)',
                boxShadow: 'var(--shadow-glow-primary), var(--shadow-md)',
                color: 'white',
                fontWeight: 'var(--font-weight-semibold)',
                fontSize: 'var(--text-base)',
              }}
              aria-label="Play Halloween event trailer"
            >
              <Play size={18} fill="white" aria-hidden="true" />
              Play Trailer
            </button>
            <button
              className="flex items-center gap-2 px-6 py-3 rounded-full transition-all duration-[220ms] ease-out hover:scale-[1.02] hover:bg-white/10"
              style={{
                background: 'var(--surface-glass)',
                border: '1px solid var(--border-glass-light)',
                backdropFilter: 'var(--blur-md)',
                color: 'var(--txt-primary)',
                fontWeight: 'var(--font-weight-semibold)',
                fontSize: 'var(--text-base)',
              }}
              aria-label="More information about Halloween event"
            >
              <Info size={18} aria-hidden="true" />
              More Info
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}