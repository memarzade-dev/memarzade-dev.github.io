import { LucideIcon } from 'lucide-react';

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  description: string;
  action?: {
    label: string;
    onClick: () => void;
  };
}

export function EmptyState({ icon: Icon, title, description, action }: EmptyStateProps) {
  return (
    <div 
      className="flex flex-col items-center justify-center py-16 px-4"
      style={{ minHeight: '400px' }}
    >
      <div
        className="w-20 h-20 rounded-full flex items-center justify-center mb-6"
        style={{
          background: 'rgba(111, 125, 255, 0.1)',
          border: '2px solid rgba(111, 125, 255, 0.2)',
        }}
      >
        <Icon size={32} style={{ color: 'var(--brand-start)' }} />
      </div>
      
      <h3
        className="mb-2"
        style={{
          fontSize: '24px',
          fontWeight: 600,
          color: 'var(--txt-primary)',
        }}
      >
        {title}
      </h3>
      
      <p
        className="mb-6 text-center max-w-md"
        style={{
          fontSize: '15px',
          color: 'var(--txt-secondary)',
          lineHeight: '1.5',
        }}
      >
        {description}
      </p>
      
      {action && (
        <button
          onClick={action.onClick}
          className="px-6 py-3 rounded-xl transition-all hover:scale-[1.02] active:scale-100"
          style={{
            background: 'linear-gradient(135deg, var(--brand-start), var(--brand-end))',
            boxShadow: 'var(--shadow-glow)',
            color: 'white',
            fontWeight: 600,
          }}
        >
          {action.label}
        </button>
      )}
    </div>
  );
}
