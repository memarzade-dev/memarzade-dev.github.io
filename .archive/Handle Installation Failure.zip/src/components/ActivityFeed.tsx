import { Clock, Download, ShoppingCart, Star, TrendingUp } from 'lucide-react';
import { formatRelativeTime } from '../utils/format';

export interface Activity {
  id: string;
  type: 'download' | 'purchase' | 'review' | 'update';
  title: string;
  description: string;
  timestamp: Date;
  icon?: string;
}

interface ActivityFeedProps {
  activities: Activity[];
  maxItems?: number;
}

export function ActivityFeed({ activities, maxItems = 10 }: ActivityFeedProps) {
  const displayedActivities = activities.slice(0, maxItems);

  const getActivityIcon = (type: Activity['type']) => {
    switch (type) {
      case 'download':
        return Download;
      case 'purchase':
        return ShoppingCart;
      case 'review':
        return Star;
      case 'update':
        return TrendingUp;
      default:
        return Clock;
    }
  };

  const getActivityColor = (type: Activity['type']) => {
    switch (type) {
      case 'download':
        return { bg: 'rgba(59, 130, 246, 0.1)', border: 'rgba(59, 130, 246, 0.2)', icon: '#3B82F6' };
      case 'purchase':
        return { bg: 'rgba(16, 185, 129, 0.1)', border: 'rgba(16, 185, 129, 0.2)', icon: '#10B981' };
      case 'review':
        return { bg: 'rgba(251, 191, 36, 0.1)', border: 'rgba(251, 191, 36, 0.2)', icon: '#FBB F24' };
      case 'update':
        return { bg: 'rgba(139, 92, 246, 0.1)', border: 'rgba(139, 92, 246, 0.2)', icon: '#8B5CF6' };
      default:
        return { bg: 'rgba(255, 255, 255, 0.06)', border: 'var(--border-glass)', icon: 'var(--txt-tertiary)' };
    }
  };

  return (
    <div
      className="p-6 rounded-2xl space-y-4"
      style={{
        background: 'var(--bg-panel)',
        border: '1px solid var(--border-glass)',
      }}
    >
      <h3 style={{ fontSize: '18px', fontWeight: 600, color: 'var(--txt-primary)' }}>
        Recent Activity
      </h3>

      <div className="space-y-3">
        {displayedActivities.map((activity, index) => {
          const Icon = getActivityIcon(activity.type);
          const colors = getActivityColor(activity.type);

          return (
            <div
              key={activity.id}
              className="flex items-start gap-3 p-3 rounded-xl transition-all hover:bg-white/5 cursor-pointer"
            >
              <div
                className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                style={{
                  background: colors.bg,
                  border: `1px solid ${colors.border}`,
                }}
              >
                <Icon size={18} style={{ color: colors.icon }} />
              </div>

              <div className="flex-1 min-w-0">
                <h4
                  className="mb-1 truncate"
                  style={{
                    fontSize: '14px',
                    fontWeight: 600,
                    color: 'var(--txt-primary)',
                  }}
                >
                  {activity.title}
                </h4>
                <p
                  className="truncate"
                  style={{
                    fontSize: '13px',
                    color: 'var(--txt-secondary)',
                  }}
                >
                  {activity.description}
                </p>
              </div>

              <span
                className="text-xs flex-shrink-0"
                style={{
                  color: 'var(--txt-tertiary)',
                  fontSize: '12px',
                }}
              >
                {formatRelativeTime(activity.timestamp)}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
