import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useRef } from 'react';

interface CarouselRailProps {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}

export function CarouselRail({ title, subtitle, children }: CarouselRailProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 600;
      const newScrollLeft = scrollRef.current.scrollLeft + (direction === 'right' ? scrollAmount : -scrollAmount);
      scrollRef.current.scrollTo({
        left: newScrollLeft,
        behavior: 'smooth',
      });
    }
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-end justify-between px-1">
        <div>
          <h2
            className="tracking-tight"
            style={{
              fontSize: 'var(--text-3xl)',
              fontWeight: 'var(--font-weight-semibold)',
              color: 'var(--txt-primary)',
            }}
          >
            {title}
          </h2>
          {subtitle && (
            <p style={{ fontSize: 'var(--text-sm)', color: 'var(--txt-tertiary)', marginTop: '4px' }}>
              {subtitle}
            </p>
          )}
        </div>

        {/* Navigation Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => scroll('left')}
            aria-label="Scroll carousel left"
            className="p-2 rounded-lg transition-all duration-[220ms] ease-out hover:bg-white/5 hover:scale-105 focus-visible:ring-2 focus-visible:ring-primary"
            style={{
              background: 'var(--surface-glass)',
              border: '1px solid var(--border-glass)',
              color: 'var(--txt-secondary)',
            }}
          >
            <ChevronLeft size={18} aria-hidden="true" />
          </button>
          <button
            onClick={() => scroll('right')}
            aria-label="Scroll carousel right"
            className="p-2 rounded-lg transition-all duration-[220ms] ease-out hover:bg-white/5 hover:scale-105 focus-visible:ring-2 focus-visible:ring-primary"
            style={{
              background: 'var(--surface-glass)',
              border: '1px solid var(--border-glass)',
              color: 'var(--txt-secondary)',
            }}
          >
            <ChevronRight size={18} aria-hidden="true" />
          </button>
        </div>
      </div>

      {/* Scrollable Container */}
      <div
        ref={scrollRef}
        className="flex gap-4 overflow-x-auto hide-scrollbar pb-2"
        style={{
          scrollSnapType: 'x mandatory',
        }}
        role="region"
        aria-label={`${title} carousel`}
      >
        {children}
      </div>
    </div>
  );
}