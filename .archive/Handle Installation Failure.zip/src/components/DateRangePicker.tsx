import { Calendar as CalendarIcon } from 'lucide-react';
import { useState } from 'react';
import { Calendar } from './ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { formatDate } from '../utils/format';

interface DateRange {
  from: Date | undefined;
  to: Date | undefined;
}

interface DateRangePickerProps {
  value: DateRange;
  onChange: (range: DateRange) => void;
}

export function DateRangePicker({ value, onChange }: DateRangePickerProps) {
  const [isOpen, setIsOpen] = useState(false);

  const handleSelect = (range: DateRange) => {
    onChange(range);
    if (range.from && range.to) {
      setIsOpen(false);
    }
  };

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <button
          className="flex items-center gap-2 px-4 py-2 rounded-xl transition-all hover:bg-white/10"
          style={{
            background: 'rgba(255, 255, 255, 0.06)',
            border: '1px solid var(--border-glass)',
            color: 'var(--txt-primary)',
          }}
        >
          <CalendarIcon size={16} />
          <span style={{ fontSize: '14px', fontWeight: 500 }}>
            {value.from ? (
              value.to ? (
                <>
                  {formatDate(value.from)} - {formatDate(value.to)}
                </>
              ) : (
                formatDate(value.from)
              )
            ) : (
              'Pick a date range'
            )}
          </span>
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="start">
        <Calendar
          mode="range"
          selected={value as any}
          onSelect={handleSelect as any}
          numberOfMonths={2}
        />
      </PopoverContent>
    </Popover>
  );
}
