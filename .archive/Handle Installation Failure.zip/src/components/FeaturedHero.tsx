import { ChevronRight } from 'lucide-react';

interface FeaturedHeroProps {
  title: string;
  appName: string;
  appSubtitle: string;
  description: string;
  category: string;
  backgroundImage: string;
  onGetClick: () => void;
}

export function FeaturedHero({ 
  title, 
  appName, 
  appSubtitle, 
  description, 
  category,
  backgroundImage, 
  onGetClick 
}: FeaturedHeroProps) {
  return (
    <div
      className="relative overflow-hidden rounded-2xl group cursor-pointer"
      style={{ height: '420px' }}
      onClick={onGetClick}
      role="article"
      aria-label={`Featured: ${appName}`}
    >
      {/* Background */}
      <div className="absolute inset-0">
        <img
          src={backgroundImage}
          alt={`${appName} featured image`}
          className="w-full h-full object-cover transition-transform duration-[600ms] ease-out group-hover:scale-105"
        />
        <div
          className="absolute inset-0"
          style={{
            background: 'linear-gradient(to right, var(--bg-app-solid-95) 0%, var(--bg-app-solid-70) 50%, var(--bg-app-solid-30) 100%)',
          }}
          aria-hidden="true"
        />
      </div>

      {/* Content */}
      <div className="relative h-full flex flex-col justify-end p-10">
        <div className="max-w-2xl space-y-4">
          {/* Label */}
          <div 
            style={{ 
              fontSize: 'var(--text-xs)', 
              fontWeight: 'var(--font-weight-semibold)', 
              color: 'var(--color-primary)', 
              textTransform: 'uppercase', 
              letterSpacing: '0.05em' 
            }}
          >
            {title}
          </div>

          {/* App Name */}
          <div>
            <h2
              className="tracking-tight mb-1"
              style={{
                fontSize: 'var(--text-4xl)',
                fontWeight: 'var(--font-weight-bold)',
                color: 'var(--txt-primary)',
              }}
            >
              {appName}
            </h2>
            <p style={{ fontSize: 'var(--text-lg)', color: 'var(--txt-secondary)' }}>
              {appSubtitle}
            </p>
          </div>

          {/* Description */}
          <p style={{ fontSize: 'var(--text-base)', color: 'var(--txt-tertiary)', lineHeight: '1.5', maxWidth: '600px' }}>
            {description}
          </p>

          {/* Category & CTA */}
          <div className="flex items-center gap-4 pt-2">
            <span
              className="px-3 py-1 rounded-full"
              style={{
                background: 'var(--surface-glass)',
                backdropFilter: 'var(--blur-sm)',
                fontSize: 'var(--text-sm)',
                color: 'var(--txt-primary)',
                fontWeight: 'var(--font-weight-medium)',
              }}
            >
              {category}
            </span>
            <button
              className="flex items-center gap-2 px-5 py-2 rounded-full transition-all duration-[220ms] ease-out hover:scale-[1.02] active:scale-[0.98]"
              style={{
                background: 'var(--gradient-brand)',
                fontSize: 'var(--text-sm)',
                fontWeight: 'var(--font-weight-semibold)',
                color: 'white',
                boxShadow: 'var(--shadow-glow-primary)',
              }}
              onClick={(e) => {
                e.stopPropagation();
                onGetClick();
              }}
              aria-label={`Get ${appName}`}
            >
              Get
              <ChevronRight size={16} aria-hidden="true" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}