import { useState, useEffect } from 'react';
import { Search, X, Clock, TrendingUp } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useFocusTrap } from '../hooks/useFocusTrap';
import { useDebounce } from '../hooks/useDebounce';

interface SearchModalProps {
  open: boolean;
  onClose: () => void;
  onSearch: (query: string) => void;
}

const recentSearches = ['Cyberpunk 2077', 'Stardew Valley', 'Hollow Knight'];
const trendingSearches = ['Horror games', 'Indie games', 'Multiplayer'];

export function SearchModal({ open, onClose, onSearch }: SearchModalProps) {
  const [query, setQuery] = useState('');
  const debouncedQuery = useDebounce(query, 300);
  const containerRef = useFocusTrap<HTMLDivElement>(open);

  useEffect(() => {
    if (debouncedQuery) {
      // Perform search
      console.log('Searching for:', debouncedQuery);
    }
  }, [debouncedQuery]);

  useEffect(() => {
    if (open) {
      setQuery('');
    }
  }, [open]);

  if (!open) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-start justify-center pt-[10vh] p-4"
      style={{ background: 'rgba(0, 0, 0, 0.8)' }}
      onClick={onClose}
    >
      <motion.div
        ref={containerRef}
        initial={{ scale: 0.95, y: -20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.95, y: -20 }}
        transition={{ duration: 0.2 }}
        className="w-full max-w-2xl rounded-2xl overflow-hidden"
        style={{
          background: 'var(--bg-panel)',
          border: '1px solid var(--border-glass)',
          boxShadow: 'var(--shadow-lg)',
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input */}
        <div className="flex items-center gap-3 p-5 border-b" style={{ borderColor: 'var(--border-glass)' }}>
          <Search size={22} style={{ color: 'var(--txt-tertiary)' }} />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search games, categories, developers..."
            className="flex-1 bg-transparent outline-none"
            style={{ color: 'var(--txt-primary)', fontSize: '18px' }}
            autoFocus
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 rounded-lg hover:bg-white/5 transition-all"
              style={{ color: 'var(--txt-tertiary)' }}
            >
              <X size={18} />
            </button>
          )}
          <kbd
            className="px-2 py-1 rounded text-xs"
            style={{
              background: 'rgba(255, 255, 255, 0.06)',
              color: 'var(--txt-tertiary)',
              border: '1px solid var(--border-glass)',
            }}
          >
            ESC
          </kbd>
        </div>

        {/* Results / Suggestions */}
        <div className="p-5 space-y-6" style={{ maxHeight: '60vh', overflow: 'auto' }}>
          {!query ? (
            <>
              {/* Recent Searches */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <Clock size={16} style={{ color: 'var(--txt-tertiary)' }} />
                  <h3 style={{ fontSize: '13px', fontWeight: 600, color: 'var(--txt-secondary)' }}>
                    Recent Searches
                  </h3>
                </div>
                <div className="space-y-1">
                  {recentSearches.map((search, index) => (
                    <button
                      key={index}
                      onClick={() => {
                        setQuery(search);
                        onSearch(search);
                      }}
                      className="w-full text-left px-3 py-2 rounded-lg transition-all hover:bg-white/5"
                      style={{ color: 'var(--txt-primary)' }}
                    >
                      {search}
                    </button>
                  ))}
                </div>
              </div>

              {/* Trending */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <TrendingUp size={16} style={{ color: 'var(--txt-tertiary)' }} />
                  <h3 style={{ fontSize: '13px', fontWeight: 600, color: 'var(--txt-secondary)' }}>
                    Trending
                  </h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  {trendingSearches.map((search, index) => (
                    <button
                      key={index}
                      onClick={() => {
                        setQuery(search);
                        onSearch(search);
                      }}
                      className="px-3 py-1.5 rounded-lg transition-all hover:bg-white/10"
                      style={{
                        background: 'rgba(255, 255, 255, 0.06)',
                        border: '1px solid var(--border-glass)',
                        color: 'var(--txt-primary)',
                        fontSize: '13px',
                      }}
                    >
                      {search}
                    </button>
                  ))}
                </div>
              </div>
            </>
          ) : (
            <div style={{ color: 'var(--txt-secondary)', textAlign: 'center', padding: '20px' }}>
              Searching for "{query}"...
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}
