import { 
  Search, 
  Sparkles, 
  Gamepad2, 
  Palette, 
  Briefcase, 
  Trophy, 
  Code, 
  Grid3x3, 
  Bell,
  User,
  LayoutDashboard,
  Package
} from 'lucide-react';
import { PageType } from '../App';

interface NavItem {
  id: PageType;
  icon: any;
  label: string;
}

const navItems: NavItem[] = [
  { id: 'dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { id: 'inventory', icon: Package, label: 'Inventory' },
  { id: 'search', icon: Search, label: 'Search' },
  { id: 'discover', icon: Sparkles, label: 'Discover' },
  { id: 'arcade', icon: Gamepad2, label: 'Arcade' },
  { id: 'create', icon: Palette, label: 'Create' },
  { id: 'work', icon: Briefcase, label: 'Work' },
  { id: 'play', icon: Trophy, label: 'Play' },
  { id: 'develop', icon: Code, label: 'Develop' },
  { id: 'categories', icon: Grid3x3, label: 'Categories' },
  { id: 'updates', icon: Bell, label: 'Updates' },
];

interface AppSidebarProps {
  currentPage: PageType;
  onPageChange: (page: PageType) => void;
}

export function AppSidebar({ currentPage, onPageChange }: AppSidebarProps) {
  return (
    <aside 
      className="flex flex-col items-center py-4 gap-2"
      style={{
        width: '64px',
        background: '#1C1C1E',
        borderRight: '1px solid rgba(255, 255, 255, 0.08)',
      }}
    >
      {/* Nav Items */}
      <div className="flex flex-col gap-1 flex-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => onPageChange(item.id)}
              className="w-11 h-11 flex items-center justify-center rounded-lg transition-all relative"
              style={{ 
                color: isActive ? '#007AFF' : '#8E8E93',
                background: isActive ? 'rgba(0, 122, 255, 0.1)' : 'transparent',
              }}
              title={item.label}
            >
              <Icon size={22} strokeWidth={isActive ? 2 : 1.5} />
              {isActive && (
                <div 
                  className="absolute left-0 w-1 h-6 rounded-r-full"
                  style={{ background: '#007AFF' }}
                />
              )}
            </button>
          );
        })}
      </div>

      {/* User Avatar */}
      <div className="mt-auto">
        <button
          onClick={() => onPageChange('account')}
          className="relative"
        >
          <div 
            className="w-9 h-9 rounded-full overflow-hidden cursor-pointer ring-2 transition-all"
            style={{
              background: 'linear-gradient(135deg, #667EEA 0%, #764BA2 100%)',
              ringColor: currentPage === 'account' ? '#007AFF' : 'transparent',
            }}
          >
            <img
              src="https://images.unsplash.com/photo-1570170609489-43197f518df0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBwb3J0cmFpdCUyMHBlcnNvbnxlbnwxfHx8fDE3NjEzOTc3OTJ8MA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Ali Memarzade"
              className="w-full h-full object-cover"
            />
          </div>
        </button>
      </div>
    </aside>
  );
}
