import { useEffect } from 'react';
import { AlertTriangleIcon } from './icons/AlertTriangleIcon';
import { FigmaLogo } from './icons/FigmaLogo';

interface FigmaInstallDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}

export function FigmaInstallDialog({ isOpen, onOpenChange }: FigmaInstallDialogProps) {
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onOpenChange(false);
      } else if (e.key === 'Enter') {
        handleDownload();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onOpenChange]);

  const handleDownload = () => {
    // Replace with actual Figma download URL
    window.open('https://www.figma.com/downloads/', '_blank');
  };

  const handleCancel = () => {
    onOpenChange(false);
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 grid place-items-center p-4 backdrop-blur-sm"
      style={{
        backgroundColor: 'rgba(10, 12, 16, 0.55)',
      }}
      role="presentation"
    >
      <div
        className="relative w-full max-w-[420px] rounded-[18px] p-[18px] pb-[14px] shadow-2xl"
        style={{
          background: 'rgba(24, 28, 36, 0.72)',
          backdropFilter: 'blur(28px) saturate(1.1)',
          border: '1px solid rgba(255, 255, 255, 0.08)',
          boxShadow: '0 22px 60px rgba(0, 0, 0, 0.55), 0 2px 10px rgba(0, 0, 0, 0.35)',
        }}
        role="alertdialog"
        aria-modal="true"
        aria-labelledby="dialog-title"
        aria-describedby="dialog-description"
      >
        {/* Top gradient cap */}
        <div
          className="absolute inset-0 rounded-[18px] pointer-events-none"
          style={{
            background: 'linear-gradient(180deg, rgba(255, 255, 255, 0.12), transparent 22%), radial-gradient(140% 60% at 50% -10%, rgba(0, 0, 0, 0.35), transparent 45%)',
          }}
        />

        {/* Figma badge in corner */}
        <div className="absolute right-3 top-2.5 w-5 h-5" style={{ filter: 'drop-shadow(0 1px 2px rgba(0, 0, 0, 0.35))' }}>
          <FigmaLogo />
        </div>

        {/* Content */}
        <div className="relative">
          {/* Header */}
          <div className="flex items-center gap-3 mb-2">
            <div className="w-[34px] h-[34px] flex items-center justify-center flex-shrink-0">
              <AlertTriangleIcon />
            </div>
            <h1
              id="dialog-title"
              className="text-[#f4f7ff] tracking-[0.2px]"
              style={{ fontWeight: 700, fontSize: '16px' }}
            >
              Figma Automatic Installation Failed
            </h1>
          </div>

          {/* Subtitle */}
          <p
            id="dialog-description"
            className="ml-[46px] mt-1.5 mb-2.5"
            style={{ color: '#c2c9d6' }}
          >
            Download Figma manually to continue.
          </p>

          {/* Note */}
          <p
            className="ml-[46px] mb-3.5"
            style={{ color: '#9aa3b3', marginTop: 0 }}
          >
            You may also contact Figma support with this error information:
          </p>

          {/* Error box */}
          <div
            className="ml-[46px] mt-2 mb-0 p-2.5 px-3 rounded-[10px]"
            style={{
              color: '#f4f7ff',
              background: 'rgba(255, 255, 255, 0.06)',
              border: '1px solid rgba(255, 255, 255, 0.08)',
            }}
          >
            The network connection was lost. <strong>(code -1005)</strong>
          </div>

          {/* Buttons */}
          <div className="mt-4 flex gap-2.5 justify-end">
            <button
              onClick={handleDownload}
              className="px-4 py-2.5 rounded-full text-white tracking-[0.2px] transition-all duration-150 outline-none hover:brightness-110 active:translate-y-0 hover:-translate-y-px focus-visible:shadow-[0_0_0_3px_rgba(47,128,255,0.35)]"
              style={{
                background: '#2f80ff',
                fontWeight: 600,
              }}
              autoFocus
            >
              Download manually
            </button>
            <button
              onClick={handleCancel}
              className="px-4 py-2.5 rounded-full text-[#f4f7ff] tracking-[0.2px] transition-all duration-150 outline-none hover:brightness-110 active:translate-y-0 hover:-translate-y-px focus-visible:shadow-[0_0_0_3px_rgba(47,128,255,0.35)]"
              style={{
                background: 'rgba(255, 255, 255, 0.08)',
                fontWeight: 600,
              }}
            >
              Cancel
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
