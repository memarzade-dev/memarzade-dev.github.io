import { Loader2 } from 'lucide-react';

interface LoadingSpinnerProps {
  size?: number;
  className?: string;
  fullScreen?: boolean;
  message?: string;
}

export function LoadingSpinner({ 
  size = 24, 
  className = '', 
  fullScreen = false,
  message 
}: LoadingSpinnerProps) {
  const spinner = (
    <div className={`flex flex-col items-center justify-center gap-3 ${className}`}>
      <Loader2 
        size={size} 
        className="animate-spin" 
        style={{ color: 'var(--brand-start)' }}
      />
      {message && (
        <p style={{ color: 'var(--txt-secondary)', fontSize: '14px' }}>
          {message}
        </p>
      )}
    </div>
  );

  if (fullScreen) {
    return (
      <div 
        className="fixed inset-0 flex items-center justify-center z-50"
        style={{ background: 'var(--bg-base)' }}
      >
        {spinner}
      </div>
    );
  }

  return spinner;
}
