import { Filter, X, SlidersHorizontal } from 'lucide-react';
import { useState } from 'react';

export interface FilterOption {
  id: string;
  label: string;
  value: string;
}

interface FilterBarProps {
  filters: {
    genre?: FilterOption[];
    platform?: FilterOption[];
    priceRange?: FilterOption[];
  };
  activeFilters: Record<string, string>;
  onFilterChange: (category: string, value: string) => void;
  onClearAll: () => void;
}

export function FilterBar({ filters, activeFilters, onFilterChange, onClearAll }: FilterBarProps) {
  const [showAdvanced, setShowAdvanced] = useState(false);
  const hasActiveFilters = Object.keys(activeFilters).length > 0;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        {/* Quick Filters */}
        <div className="flex items-center gap-3 flex-wrap">
          {filters.genre && (
            <select
              value={activeFilters.genre || ''}
              onChange={(e) => onFilterChange('genre', e.target.value)}
              aria-label="Filter by genre"
              className="px-4 py-2 rounded-xl outline-none transition-all duration-[220ms] ease-out hover:bg-white/10 cursor-pointer focus-visible:ring-2 focus-visible:ring-primary"
              style={{
                background: activeFilters.genre 
                  ? 'var(--gradient-brand)'
                  : 'var(--surface-glass)',
                border: '1px solid var(--border-glass)',
                color: activeFilters.genre ? 'white' : 'var(--txt-primary)',
                fontSize: 'var(--text-sm)',
              }}
            >
              <option value="">All Genres</option>
              {filters.genre.map((option) => (
                <option key={option.id} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          )}

          {filters.platform && (
            <select
              value={activeFilters.platform || ''}
              onChange={(e) => onFilterChange('platform', e.target.value)}
              aria-label="Filter by platform"
              className="px-4 py-2 rounded-xl outline-none transition-all duration-[220ms] ease-out hover:bg-white/10 cursor-pointer focus-visible:ring-2 focus-visible:ring-primary"
              style={{
                background: activeFilters.platform 
                  ? 'var(--gradient-brand)'
                  : 'var(--surface-glass)',
                border: '1px solid var(--border-glass)',
                color: activeFilters.platform ? 'white' : 'var(--txt-primary)',
                fontSize: 'var(--text-sm)',
              }}
            >
              <option value="">All Platforms</option>
              {filters.platform.map((option) => (
                <option key={option.id} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          )}

          {filters.priceRange && (
            <select
              value={activeFilters.priceRange || ''}
              onChange={(e) => onFilterChange('priceRange', e.target.value)}
              aria-label="Filter by price range"
              className="px-4 py-2 rounded-xl outline-none transition-all duration-[220ms] ease-out hover:bg-white/10 cursor-pointer focus-visible:ring-2 focus-visible:ring-primary"
              style={{
                background: activeFilters.priceRange 
                  ? 'var(--gradient-brand)'
                  : 'var(--surface-glass)',
                border: '1px solid var(--border-glass)',
                color: activeFilters.priceRange ? 'white' : 'var(--txt-primary)',
                fontSize: 'var(--text-sm)',
              }}
            >
              <option value="">All Prices</option>
              {filters.priceRange.map((option) => (
                <option key={option.id} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          )}

          {/* Advanced Filters Toggle */}
          <button
            onClick={() => setShowAdvanced(!showAdvanced)}
            aria-label="Toggle advanced filters"
            aria-expanded={showAdvanced}
            className="flex items-center gap-2 px-4 py-2 rounded-xl transition-all duration-[220ms] ease-out hover:bg-white/10 focus-visible:ring-2 focus-visible:ring-primary"
            style={{
              background: showAdvanced ? 'var(--color-primary-alpha)' : 'var(--surface-glass)',
              border: '1px solid var(--border-glass)',
              color: 'var(--txt-primary)',
            }}
          >
            <SlidersHorizontal size={16} aria-hidden="true" />
            <span style={{ fontSize: 'var(--text-sm)', fontWeight: 'var(--font-weight-medium)' }}>Advanced</span>
          </button>
        </div>

        {/* Clear Filters */}
        {hasActiveFilters && (
          <button
            onClick={onClearAll}
            aria-label="Clear all filters"
            className="flex items-center gap-2 px-4 py-2 rounded-xl transition-all duration-[220ms] ease-out hover:bg-red-500/20 focus-visible:ring-2 focus-visible:ring-error"
            style={{
              background: 'var(--color-error-alpha)',
              border: '1px solid var(--color-error)',
              color: 'var(--color-error)',
            }}
          >
            <X size={16} aria-hidden="true" />
            <span style={{ fontSize: 'var(--text-sm)', fontWeight: 'var(--font-weight-medium)' }}>Clear All</span>
          </button>
        )}
      </div>

      {/* Advanced Filters Panel */}
      {showAdvanced && (
        <div
          className="p-4 rounded-xl space-y-4"
          style={{
            background: 'var(--surface-glass)',
            border: '1px solid var(--border-glass)',
          }}
          role="region"
          aria-label="Advanced filters"
        >
          <h4 style={{ fontSize: 'var(--text-sm)', fontWeight: 'var(--font-weight-semibold)', color: 'var(--txt-primary)' }}>
            Advanced Filters
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* Add more advanced filter options here */}
            <div>
              <label 
                htmlFor="rating-filter"
                style={{ fontSize: 'var(--text-xs)', color: 'var(--txt-secondary)', display: 'block', marginBottom: '8px' }}
              >
                Rating
              </label>
              <input
                id="rating-filter"
                type="range"
                min="0"
                max="5"
                step="0.5"
                aria-label="Filter by rating"
                className="w-full"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}