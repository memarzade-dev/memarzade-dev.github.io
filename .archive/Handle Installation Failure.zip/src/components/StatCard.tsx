import { LucideIcon, TrendingUp, TrendingDown } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  change?: {
    value: number;
    type: 'increase' | 'decrease';
  };
  subtitle?: string;
}

export function StatCard({ title, value, icon: Icon, change, subtitle }: StatCardProps) {
  return (
    <div
      className="p-6 rounded-2xl transition-all duration-[220ms] ease-out hover:scale-[1.01] cursor-default"
      style={{
        background: 'var(--bg-panel)',
        border: '1px solid var(--border-glass)',
        boxShadow: 'var(--shadow-sm)',
      }}
    >
      <div className="flex items-start justify-between mb-4">
        <div
          className="w-12 h-12 rounded-xl flex items-center justify-center"
          style={{
            background: 'rgba(111, 125, 255, 0.1)',
            border: '1px solid rgba(111, 125, 255, 0.2)',
          }}
        >
          <Icon size={24} style={{ color: 'var(--brand-start)' }} />
        </div>

        {change && (
          <div
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg"
            style={{
              background: change.type === 'increase' 
                ? 'rgba(16, 185, 129, 0.1)' 
                : 'rgba(239, 68, 68, 0.1)',
              color: change.type === 'increase' ? '#10B981' : '#EF4444',
            }}
          >
            {change.type === 'increase' ? (
              <TrendingUp size={14} />
            ) : (
              <TrendingDown size={14} />
            )}
            <span className="tabular-nums" style={{ fontSize: '12px', fontWeight: 600 }}>
              {Math.abs(change.value)}%
            </span>
          </div>
        )}
      </div>

      <div>
        <h3
          className="tabular-nums mb-1"
          style={{
            fontSize: '32px',
            fontWeight: 700,
            color: 'var(--txt-primary)',
          }}
        >
          {value}
        </h3>
        <p style={{ fontSize: '14px', color: 'var(--txt-secondary)', marginBottom: '4px' }}>
          {title}
        </p>
        {subtitle && (
          <p style={{ fontSize: '12px', color: 'var(--txt-tertiary)' }}>
            {subtitle}
          </p>
        )}
      </div>
    </div>
  );
}