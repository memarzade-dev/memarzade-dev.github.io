import { TrendingUp, DollarSign, ShoppingBag, Users } from 'lucide-react';
import { StatCard } from './StatCard';

interface QuickStatsProps {
  totalRevenue: string;
  totalSales: number;
  activeUsers: number;
  growthRate: number;
}

export function QuickStats({ totalRevenue, totalSales, activeUsers, growthRate }: QuickStatsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <StatCard
        title="Total Revenue"
        value={totalRevenue}
        icon={DollarSign}
        change={{ value: 12.5, type: 'increase' }}
        subtitle="vs last month"
      />
      <StatCard
        title="Total Sales"
        value={totalSales.toLocaleString()}
        icon={ShoppingBag}
        change={{ value: 8.2, type: 'increase' }}
        subtitle="games sold"
      />
      <StatCard
        title="Active Users"
        value={activeUsers.toLocaleString()}
        icon={Users}
        change={{ value: 3.1, type: 'decrease' }}
        subtitle="daily active"
      />
      <StatCard
        title="Growth Rate"
        value={`${growthRate}%`}
        icon={TrendingUp}
        change={{ value: 5.4, type: 'increase' }}
        subtitle="month over month"
      />
    </div>
  );
}
