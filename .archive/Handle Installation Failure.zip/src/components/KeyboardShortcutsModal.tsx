import { X, Command } from 'lucide-react';
import { useFocusTrap } from '../hooks/useFocusTrap';
import { useEffect } from 'react';

interface KeyboardShortcutsModalProps {
  open: boolean;
  onClose: () => void;
}

const shortcuts = [
  { category: 'General', items: [
    { keys: ['⌘', 'K'], description: 'Open search' },
    { keys: ['⌘', '/'], description: 'Show keyboard shortcuts' },
    { keys: ['Esc'], description: 'Close modal/dialog' },
  ]},
  { category: 'Navigation', items: [
    { keys: ['⌘', '1'], description: 'Go to Dashboard' },
    { keys: ['⌘', '2'], description: 'Go to Inventory' },
    { keys: ['⌘', '3'], description: 'Go to Discover' },
    { keys: ['←', '→'], description: 'Navigate carousel' },
  ]},
  { category: 'Actions', items: [
    { keys: ['⌘', 'N'], description: 'New item' },
    { keys: ['⌘', 'S'], description: 'Save' },
    { keys: ['⌘', 'E'], description: 'Export' },
    { keys: ['Delete'], description: 'Delete selected' },
  ]},
];

export function KeyboardShortcutsModal({ open, onClose }: KeyboardShortcutsModalProps) {
  const containerRef = useFocusTrap<HTMLDivElement>(open);

  useEffect(() => {
    if (open) {
      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'Escape') {
          onClose();
        }
      };
      window.addEventListener('keydown', handleKeyDown);
      return () => window.removeEventListener('keydown', handleKeyDown);
    }
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0, 0, 0, 0.8)' }}
      onClick={onClose}
    >
      <div
        ref={containerRef}
        className="max-w-2xl w-full p-6 rounded-2xl space-y-6"
        style={{
          background: 'var(--bg-panel)',
          border: '1px solid var(--border-glass)',
          boxShadow: 'var(--shadow-lg)',
          maxHeight: '80vh',
          overflow: 'auto',
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{
                background: 'rgba(111, 125, 255, 0.1)',
                border: '1px solid rgba(111, 125, 255, 0.2)',
              }}
            >
              <Command size={20} style={{ color: 'var(--brand-start)' }} />
            </div>
            <h2
              style={{
                fontSize: '24px',
                fontWeight: 600,
                color: 'var(--txt-primary)',
              }}
            >
              Keyboard Shortcuts
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg transition-all hover:bg-white/5"
            style={{ color: 'var(--txt-tertiary)' }}
          >
            <X size={20} />
          </button>
        </div>

        {/* Shortcuts List */}
        <div className="space-y-6">
          {shortcuts.map((section) => (
            <div key={section.category}>
              <h3
                className="mb-3 pb-2 border-b"
                style={{
                  fontSize: '14px',
                  fontWeight: 600,
                  color: 'var(--txt-secondary)',
                  borderColor: 'var(--border-glass)',
                }}
              >
                {section.category}
              </h3>
              <div className="space-y-2">
                {section.items.map((item, index) => (
                  <div key={index} className="flex items-center justify-between py-2">
                    <span style={{ fontSize: '14px', color: 'var(--txt-primary)' }}>
                      {item.description}
                    </span>
                    <div className="flex items-center gap-1">
                      {item.keys.map((key, keyIndex) => (
                        <kbd
                          key={keyIndex}
                          className="px-2.5 py-1 rounded-lg"
                          style={{
                            background: 'rgba(255, 255, 255, 0.06)',
                            border: '1px solid var(--border-glass)',
                            color: 'var(--txt-primary)',
                            fontSize: '13px',
                            fontWeight: 500,
                            minWidth: '32px',
                            textAlign: 'center',
                          }}
                        >
                          {key}
                        </kbd>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
