import { Download, FileText, FileSpreadsheet, FileJson } from 'lucide-react';
import { useState, useRef } from 'react';
import { useClickOutside } from '../hooks/useClickOutside';
import { motion, AnimatePresence } from 'motion/react';

export type ExportFormat = 'csv' | 'json' | 'pdf';

interface ExportButtonProps {
  onExport: (format: ExportFormat) => void;
  loading?: boolean;
}

export function ExportButton({ onExport, loading = false }: ExportButtonProps) {
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useClickOutside(menuRef, () => setIsOpen(false));

  const exportOptions = [
    { format: 'csv' as ExportFormat, label: 'Export as CSV', icon: FileSpreadsheet },
    { format: 'json' as ExportFormat, label: 'Export as JSON', icon: FileJson },
    { format: 'pdf' as ExportFormat, label: 'Export as PDF', icon: FileText },
  ];

  return (
    <div className="relative" ref={menuRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        disabled={loading}
        className="flex items-center gap-2 px-4 py-2 rounded-xl transition-all hover:scale-[1.02] disabled:opacity-50"
        style={{
          background: 'linear-gradient(135deg, var(--brand-start), var(--brand-end))',
          boxShadow: 'var(--shadow-glow)',
          color: 'white',
          fontWeight: 600,
        }}
      >
        <Download size={16} />
        <span style={{ fontSize: '14px' }}>Export</span>
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className="absolute top-full right-0 mt-2 py-2 rounded-xl backdrop-blur-xl min-w-[200px] z-50"
            style={{
              background: 'var(--surface-glass)',
              border: '1px solid var(--border-glass)',
              boxShadow: 'var(--shadow-lg)',
            }}
          >
            {exportOptions.map((option) => {
              const Icon = option.icon;
              return (
                <button
                  key={option.format}
                  onClick={() => {
                    onExport(option.format);
                    setIsOpen(false);
                  }}
                  className="w-full flex items-center gap-3 px-4 py-2.5 transition-all hover:bg-white/10"
                  style={{ color: 'var(--txt-primary)' }}
                >
                  <Icon size={18} />
                  <span style={{ fontSize: '14px', fontWeight: 500 }}>{option.label}</span>
                </button>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
