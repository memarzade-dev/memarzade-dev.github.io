import { Star, Gamepad2 } from 'lucide-react';

interface ArcadeCardProps {
  id: string;
  name: string;
  subtitle: string;
  category: string;
  icon: string;
  iconBg: string;
  rating: number;
  onClick: () => void;
}

export function ArcadeCard({ 
  name, 
  subtitle, 
  category, 
  icon, 
  iconBg, 
  rating,
  onClick 
}: ArcadeCardProps) {
  return (
    <div
      role="button"
      tabIndex={0}
      aria-label={`${name} - ${category} - ${rating} stars`}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onClick();
        }
      }}
      className="flex-shrink-0 cursor-pointer group transition-all duration-[220ms] ease-out"
      style={{ width: '280px' }}
      onClick={onClick}
    >
      <div className="flex gap-4 items-start">
        {/* Icon */}
        <div
          className="flex-shrink-0 rounded-2xl overflow-hidden transition-transform group-hover:scale-105"
          style={{
            width: '64px',
            height: '64px',
            background: iconBg,
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.25)',
          }}
        >
          <div className="w-full h-full flex items-center justify-center" style={{ fontSize: '32px' }}>
            {icon}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="mb-2">
            <h3
              className="truncate group-hover:text-[#007AFF] transition-colors duration-[220ms] ease-out"
              style={{
                fontSize: '15px',
                fontWeight: 500,
                color: 'var(--txt-primary)',
                marginBottom: '2px',
              }}
            >
              {name}
            </h3>
            <p
              className="truncate"
              style={{
                fontSize: '13px',
                color: 'var(--txt-tertiary)',
              }}
            >
              {subtitle}
            </p>
          </div>

          {/* Category & Rating */}
          <div className="flex items-center gap-2 mb-3">
            <div className="flex items-center gap-1" aria-label={`Rating: ${rating} out of 5 stars`}>
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  size={10}
                  fill={i < Math.floor(rating) ? '#FFB800' : 'none'}
                  color={i < Math.floor(rating) ? '#FFB800' : '#8E8E93'}
                  strokeWidth={1.5}
                />
              ))}
            </div>
            <span
              className="tabular-nums"
              style={{
                fontSize: '12px',
                color: 'var(--txt-tertiary)',
              }}
            >
              {rating}
            </span>
            <span style={{ color: 'var(--txt-tertiary)', fontSize: '12px' }}>•</span>
            <span
              className="truncate"
              style={{
                fontSize: '12px',
                color: 'var(--txt-tertiary)',
              }}
            >
              {category}
            </span>
          </div>

          {/* Play Button */}
          <button
            aria-label={`Play ${name}`}
            className="flex items-center gap-2 px-4 py-1.5 rounded-full transition-all duration-[220ms] ease-out hover:bg-opacity-80"
            style={{
              background: 'rgba(255, 255, 255, 0.1)',
              fontSize: '13px',
              fontWeight: 600,
              color: '#007AFF',
              border: 'none',
            }}
            onClick={(e) => {
              e.stopPropagation();
              onClick();
            }}
          >
            <Gamepad2 size={14} />
            PLAY
          </button>
        </div>
      </div>
    </div>
  );
}