import { AlertTriangle, X } from 'lucide-react';
import { useFocusTrap } from '../hooks/useFocusTrap';

interface ConfirmDialogProps {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  description: string;
  confirmLabel?: string;
  cancelLabel?: string;
  variant?: 'danger' | 'warning' | 'info';
}

export function ConfirmDialog({
  open,
  onClose,
  onConfirm,
  title,
  description,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  variant = 'danger',
}: ConfirmDialogProps) {
  const containerRef = useFocusTrap<HTMLDivElement>(open);

  if (!open) return null;

  const variantStyles = {
    danger: {
      iconBg: 'rgba(239, 68, 68, 0.1)',
      iconBorder: 'rgba(239, 68, 68, 0.2)',
      iconColor: '#EF4444',
      buttonBg: 'linear-gradient(135deg, #EF4444, #DC2626)',
    },
    warning: {
      iconBg: 'rgba(251, 146, 60, 0.1)',
      iconBorder: 'rgba(251, 146, 60, 0.2)',
      iconColor: '#FB923C',
      buttonBg: 'linear-gradient(135deg, #FB923C, #F97316)',
    },
    info: {
      iconBg: 'rgba(59, 130, 246, 0.1)',
      iconBorder: 'rgba(59, 130, 246, 0.2)',
      iconColor: '#3B82F6',
      buttonBg: 'linear-gradient(135deg, #3B82F6, #2563EB)',
    },
  };

  const styles = variantStyles[variant];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0, 0, 0, 0.7)' }}
      onClick={onClose}
    >
      <div
        ref={containerRef}
        className="max-w-md w-full p-6 rounded-2xl space-y-6"
        style={{
          background: 'var(--bg-panel)',
          border: '1px solid var(--border-glass)',
          boxShadow: 'var(--shadow-lg)',
        }}
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
        aria-labelledby="dialog-title"
      >
        <div className="flex items-start gap-4">
          <div
            className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0"
            style={{
              background: styles.iconBg,
              border: `2px solid ${styles.iconBorder}`,
            }}
          >
            <AlertTriangle size={24} style={{ color: styles.iconColor }} />
          </div>

          <div className="flex-1">
            <h3
              id="dialog-title"
              className="mb-2"
              style={{
                fontSize: '18px',
                fontWeight: 600,
                color: 'var(--txt-primary)',
              }}
            >
              {title}
            </h3>
            <p style={{ fontSize: '14px', color: 'var(--txt-secondary)', lineHeight: '1.5' }}>
              {description}
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-lg transition-all hover:bg-white/5"
            style={{ color: 'var(--txt-tertiary)' }}
            aria-label="Close dialog"
          >
            <X size={20} />
          </button>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-2.5 rounded-xl transition-all hover:bg-white/10"
            style={{
              background: 'rgba(255, 255, 255, 0.06)',
              border: '1px solid var(--border-glass)',
              color: 'var(--txt-primary)',
              fontWeight: 600,
            }}
          >
            {cancelLabel}
          </button>
          <button
            onClick={() => {
              onConfirm();
              onClose();
            }}
            className="flex-1 px-4 py-2.5 rounded-xl transition-all hover:scale-[1.02]"
            style={{
              background: styles.buttonBg,
              boxShadow: 'var(--shadow-md)',
              color: 'white',
              fontWeight: 600,
            }}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
