import { Settings, CreditCard } from 'lucide-react';

interface AccountHeaderProps {
  onOpenSettings: () => void;
  activeTab: 'mac' | 'ios';
  onTabChange: (tab: 'mac' | 'ios') => void;
}

export function AccountHeader({ onOpenSettings, activeTab, onTabChange }: AccountHeaderProps) {
  return (
    <header className="flex flex-col px-8 pt-6 pb-4" style={{ background: '#1C1C1E' }}>
      {/* Title Row */}
      <div className="flex items-center justify-between mb-6">
        <h1 
          className="tracking-tight"
          style={{
            fontSize: '36px',
            fontWeight: 600,
            color: '#FFFFFF',
            fontFamily: '-apple-system, BlinkMacSystemFont, "SF Pro Display", sans-serif',
          }}
        >
          Account
        </h1>

        <div className="flex items-center gap-3">
          <button
            onClick={onOpenSettings}
            className="flex items-center gap-2 px-4 py-2 rounded-lg transition-colors hover:bg-white/5"
            style={{
              color: '#007AFF',
              fontSize: '14px',
              fontWeight: 500,
            }}
          >
            <Settings size={16} />
            Account Settings
          </button>
          <button
            className="flex items-center gap-2 px-4 py-2 rounded-lg transition-colors hover:bg-white/5"
            style={{
              color: '#007AFF',
              fontSize: '14px',
              fontWeight: 500,
            }}
          >
            <CreditCard size={16} />
            Redeem Gift Card
          </button>
        </div>
      </div>

      {/* Tabs Row */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-6">
          <button
            onClick={() => onTabChange('mac')}
            className="pb-2 transition-colors relative"
            style={{
              fontSize: '14px',
              fontWeight: 500,
              color: activeTab === 'mac' ? '#FFFFFF' : '#8E8E93',
            }}
          >
            Mac Apps
            {activeTab === 'mac' && (
              <div 
                className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full"
                style={{ background: '#007AFF' }}
              />
            )}
          </button>
          <button
            onClick={() => onTabChange('ios')}
            className="pb-2 transition-colors relative"
            style={{
              fontSize: '14px',
              fontWeight: 500,
              color: activeTab === 'ios' ? '#FFFFFF' : '#8E8E93',
            }}
          >
            iPhone & iPad Apps
            {activeTab === 'ios' && (
              <div 
                className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full"
                style={{ background: '#007AFF' }}
              />
            )}
          </button>
        </div>

        <div style={{ fontSize: '14px', fontWeight: 500, color: '#8E8E93' }}>
          Purchased
        </div>
      </div>

      {/* Separator */}
      <div className="mt-2" style={{ height: '1px', background: 'rgba(255, 255, 255, 0.08)' }} />
    </header>
  );
}
