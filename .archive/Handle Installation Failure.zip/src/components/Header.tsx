import { Search, Bell, Settings, User } from 'lucide-react';

interface HeaderProps {
  title: string;
  sidebarCollapsed: boolean;
}

export function Header({ title, sidebarCollapsed }: HeaderProps) {
  return (
    <header
      className="sticky top-0 z-30 transition-all duration-300"
      style={{
        height: '72px',
        marginLeft: sidebarCollapsed ? '80px' : '240px',
        background: 'var(--surface-glass)',
        backdropFilter: 'var(--surface-blur) saturate(1.1)',
        borderBottom: '1px solid var(--border-glass)',
      }}
    >
      <div className="h-full px-6 flex items-center justify-between">
        {/* Left: Title */}
        <h1 
          className="tracking-tight"
          style={{ 
            color: 'var(--txt-primary)',
            fontWeight: 600,
            fontSize: '28px',
          }}
        >
          {title}
        </h1>

        {/* Center: Search */}
        <div className="flex-1 max-w-xl mx-8">
          <label htmlFor="header-search" className="sr-only">
            Search games, developers, and genres
          </label>
          <div
            className="relative flex items-center gap-3 px-4 py-2.5 rounded-full transition-all"
            style={{
              background: 'rgba(255, 255, 255, 0.04)',
              border: '1px solid var(--border-glass)',
              backdropFilter: 'blur(12px)',
            }}
          >
            <Search size={18} style={{ color: 'var(--txt-tertiary)' }} />
            <input
              id="header-search"
              type="text"
              placeholder="Search games, developers, genres..."
              className="flex-1 bg-transparent outline-none placeholder:text-[var(--txt-tertiary)]"
              style={{ color: 'var(--txt-primary)' }}
            />
            <kbd
              className="px-2 py-0.5 rounded text-xs tabular-nums"
              style={{
                background: 'rgba(255, 255, 255, 0.06)',
                color: 'var(--txt-tertiary)',
                border: '1px solid var(--border-glass)',
              }}
            >
              ⌘K
            </kbd>
          </div>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-3">
          <button
            aria-label="View notifications (1 new)"
            className="p-2.5 rounded-xl transition-all hover:bg-white/5 relative"
            style={{ color: 'var(--txt-secondary)' }}
          >
            <Bell size={20} />
            <span
              aria-hidden="true"
              className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full"
              style={{ background: 'linear-gradient(135deg, #FF6B6B, #FF4757)' }}
            />
          </button>
          <button
            aria-label="Open settings"
            className="p-2.5 rounded-xl transition-all hover:bg-white/5"
            style={{ color: 'var(--txt-secondary)' }}
          >
            <Settings size={20} />
          </button>
          <button
            aria-label="View user profile"
            className="p-2.5 rounded-xl transition-all hover:bg-white/5"
            style={{ color: 'var(--txt-secondary)' }}
          >
            <User size={20} />
          </button>
        </div>
      </div>
    </header>
  );
}