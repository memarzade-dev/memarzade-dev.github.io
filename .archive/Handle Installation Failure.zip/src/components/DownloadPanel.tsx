import { Download, X, Pause, Play } from 'lucide-react';
import { useState } from 'react';

interface DownloadItem {
  id: string;
  name: string;
  size: string;
  progress: number;
  speed: string;
  paused: boolean;
}

export function DownloadPanel() {
  const [isExpanded, setIsExpanded] = useState(true);
  const [downloads, setDownloads] = useState<DownloadItem[]>([
    {
      id: '1',
      name: 'Dead Island 2',
      size: '45.2 GB',
      progress: 67,
      speed: '12.4 MB/s',
      paused: false,
    },
    {
      id: '2',
      name: 'Cyberpunk 2077',
      size: '70.8 GB',
      progress: 23,
      speed: '8.7 MB/s',
      paused: false,
    },
  ]);

  const togglePause = (id: string) => {
    setDownloads(downloads.map(d => 
      d.id === id ? { ...d, paused: !d.paused } : d
    ));
  };

  const removeDownload = (id: string) => {
    setDownloads(downloads.filter(d => d.id !== id));
  };

  if (downloads.length === 0) return null;

  return (
    <div
      className="fixed bottom-6 right-6 z-50 transition-all duration-300"
      style={{
        width: isExpanded ? '380px' : '64px',
      }}
    >
      <div
        className="rounded-2xl overflow-hidden"
        style={{
          background: 'var(--surface-glass)',
          backdropFilter: 'var(--surface-blur) saturate(1.1)',
          border: '1px solid var(--border-glass)',
          boxShadow: 'var(--shadow-lg)',
        }}
      >
        {/* Header */}
        <div
          className="flex items-center justify-between p-4 cursor-pointer"
          onClick={() => setIsExpanded(!isExpanded)}
          style={{
            borderBottom: isExpanded ? '1px solid var(--border-glass)' : 'none',
          }}
        >
          <div className="flex items-center gap-3">
            <div
              className="p-2 rounded-lg"
              style={{
                background: 'linear-gradient(135deg, var(--brand-start), var(--brand-end))',
              }}
            >
              <Download size={18} color="white" />
            </div>
            {isExpanded && (
              <div>
                <div style={{ fontSize: '14px', fontWeight: 600, color: 'var(--txt-primary)' }}>
                  Downloads
                </div>
                <div style={{ fontSize: '12px', color: 'var(--txt-tertiary)' }}>
                  {downloads.length} active
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Downloads List */}
        {isExpanded && (
          <div className="p-4 space-y-3 max-h-[400px] overflow-y-auto">
            {downloads.map((download) => (
              <div
                key={download.id}
                className="space-y-2 p-3 rounded-xl transition-all hover:bg-white/5"
                style={{
                  background: 'rgba(255, 255, 255, 0.02)',
                }}
              >
                {/* Title & Actions */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div
                      className="truncate"
                      style={{
                        fontSize: '13px',
                        fontWeight: 600,
                        color: 'var(--txt-primary)',
                      }}
                    >
                      {download.name}
                    </div>
                    <div
                      className="tabular-nums"
                      style={{
                        fontSize: '11px',
                        color: 'var(--txt-tertiary)',
                      }}
                    >
                      {download.size} • {download.paused ? 'Paused' : download.speed}
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        togglePause(download.id);
                      }}
                      className="p-1.5 rounded-lg hover:bg-white/10 transition-all"
                      style={{ color: 'var(--txt-secondary)' }}
                    >
                      {download.paused ? <Play size={14} /> : <Pause size={14} />}
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        removeDownload(download.id);
                      }}
                      className="p-1.5 rounded-lg hover:bg-white/10 transition-all"
                      style={{ color: 'var(--txt-secondary)' }}
                    >
                      <X size={14} />
                    </button>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="relative h-1.5 rounded-full overflow-hidden" style={{ background: 'rgba(255, 255, 255, 0.08)' }}>
                  <div
                    className="absolute inset-y-0 left-0 rounded-full transition-all duration-300"
                    style={{
                      width: `${download.progress}%`,
                      background: download.paused
                        ? 'var(--txt-tertiary)'
                        : 'linear-gradient(90deg, var(--brand-start), var(--brand-end))',
                    }}
                  />
                </div>

                {/* Progress Text */}
                <div
                  className="tabular-nums"
                  style={{
                    fontSize: '11px',
                    color: 'var(--txt-tertiary)',
                  }}
                >
                  {download.progress}% complete
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
