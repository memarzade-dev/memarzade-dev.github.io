import { Edit, Copy, Trash2, MoreVertical } from 'lucide-react';

interface Game {
  id: string;
  title: string;
  genre: string;
  price: string;
  stock: number;
  image: string;
  platform: string;
}

interface GameGridProps {
  games: Game[];
}

export function GameGrid({ games }: GameGridProps) {
  return (
    <div className="space-y-6">
      {/* Filters Bar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <select
            aria-label="Filter by genre"
            className="px-4 py-2 rounded-xl outline-none transition-all duration-[220ms] ease-out hover:bg-white/10 cursor-pointer focus-visible:ring-2 focus-visible:ring-primary"
            style={{
              background: 'var(--surface-glass)',
              border: '1px solid var(--border-glass)',
              color: 'var(--txt-primary)',
              fontSize: 'var(--text-sm)',
            }}
          >
            <option>All Genres</option>
            <option>Action</option>
            <option>Horror</option>
            <option>Sci-Fi</option>
            <option>Racing</option>
          </select>
          <select
            aria-label="Filter by platform"
            className="px-4 py-2 rounded-xl outline-none transition-all duration-[220ms] ease-out hover:bg-white/10 cursor-pointer focus-visible:ring-2 focus-visible:ring-primary"
            style={{
              background: 'var(--surface-glass)',
              border: '1px solid var(--border-glass)',
              color: 'var(--txt-primary)',
              fontSize: 'var(--text-sm)',
            }}
          >
            <option>All Platforms</option>
            <option>Mac</option>
            <option>iOS</option>
            <option>Cross-platform</option>
          </select>
        </div>
        <select
          aria-label="Sort games"
          className="px-4 py-2 rounded-xl outline-none transition-all duration-[220ms] ease-out hover:bg-white/10 cursor-pointer focus-visible:ring-2 focus-visible:ring-primary"
          style={{
            background: 'var(--surface-glass)',
            border: '1px solid var(--border-glass)',
            color: 'var(--txt-primary)',
            fontSize: 'var(--text-sm)',
          }}
        >
          <option>Newest First</option>
          <option>Most Popular</option>
          <option>Price: Low to High</option>
          <option>Price: High to Low</option>
        </select>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-6">
        {games.map((game) => (
          <div
            key={game.id}
            className="group relative rounded-2xl overflow-hidden transition-all duration-[220ms] ease-out hover:scale-[1.02]"
            style={{
              background: 'var(--bg-panel)',
              border: '1px solid var(--border-glass)',
              boxShadow: 'var(--shadow-sm)',
            }}
          >
            {/* Image */}
            <div className="relative overflow-hidden" style={{ paddingBottom: '133%' }}>
              <img
                src={game.image}
                alt={`${game.title} game cover`}
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-[600ms] ease-out group-hover:scale-110"
              />
              <div
                className="absolute inset-0"
                style={{
                  background: 'linear-gradient(to bottom, transparent 0%, var(--bg-app-solid-90) 100%)',
                }}
                aria-hidden="true"
              />

              {/* Platform Badge */}
              <div
                className="absolute top-3 left-3 px-2.5 py-1 rounded-lg backdrop-blur-xl"
                style={{
                  background: 'rgba(0, 0, 0, 0.5)',
                  border: '1px solid var(--border-glass)',
                  fontSize: 'var(--text-xs)',
                  fontWeight: 'var(--font-weight-semibold)',
                  color: 'white',
                }}
              >
                {game.platform}
              </div>

              {/* Quick Actions */}
              <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-[220ms] ease-out">
                <button
                  aria-label={`More options for ${game.title}`}
                  className="p-2 rounded-lg backdrop-blur-xl transition-all duration-[220ms] ease-out hover:scale-105"
                  style={{
                    background: 'rgba(0, 0, 0, 0.5)',
                    border: '1px solid var(--border-glass)',
                    color: 'white',
                  }}
                >
                  <MoreVertical size={16} aria-hidden="true" />
                </button>
              </div>
            </div>

            {/* Content */}
            <div className="p-4 space-y-3">
              <div>
                <h3
                  className="truncate"
                  style={{
                    fontSize: 'var(--text-base)',
                    fontWeight: 'var(--font-weight-semibold)',
                    color: 'var(--txt-primary)',
                  }}
                >
                  {game.title}
                </h3>
                <p
                  className="truncate"
                  style={{
                    fontSize: 'var(--text-xs)',
                    color: 'var(--txt-tertiary)',
                  }}
                >
                  {game.genre}
                </p>
              </div>

              {/* Stats */}
              <div className="flex items-center justify-between">
                <div>
                  <div
                    className="tabular-nums"
                    style={{
                      fontSize: 'var(--text-lg)',
                      fontWeight: 'var(--font-weight-bold)',
                      color: 'var(--txt-primary)',
                    }}
                  >
                    {game.price}
                  </div>
                  <div
                    className="tabular-nums"
                    style={{
                      fontSize: 'var(--text-xs)',
                      color: 'var(--txt-tertiary)',
                    }}
                  >
                    Stock: {game.stock}
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 pt-2">
                <button
                  aria-label={`Edit ${game.title}`}
                  className="flex-1 p-2 rounded-lg transition-all duration-[220ms] ease-out hover:bg-white/10 focus-visible:ring-2 focus-visible:ring-primary"
                  style={{
                    background: 'var(--surface-glass)',
                    border: '1px solid var(--border-glass)',
                    color: 'var(--txt-secondary)',
                  }}
                >
                  <Edit size={14} className="mx-auto" aria-hidden="true" />
                </button>
                <button
                  aria-label={`Duplicate ${game.title}`}
                  className="flex-1 p-2 rounded-lg transition-all duration-[220ms] ease-out hover:bg-white/10 focus-visible:ring-2 focus-visible:ring-primary"
                  style={{
                    background: 'var(--surface-glass)',
                    border: '1px solid var(--border-glass)',
                    color: 'var(--txt-secondary)',
                  }}
                >
                  <Copy size={14} className="mx-auto" aria-hidden="true" />
                </button>
                <button
                  aria-label={`Remove ${game.title}`}
                  className="flex-1 p-2 rounded-lg transition-all duration-[220ms] ease-out hover:bg-red-500/20 focus-visible:ring-2 focus-visible:ring-error"
                  style={{
                    background: 'var(--surface-glass)',
                    border: '1px solid var(--border-glass)',
                    color: 'var(--color-error)',
                  }}
                >
                  <Trash2 size={14} className="mx-auto" aria-hidden="true" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}