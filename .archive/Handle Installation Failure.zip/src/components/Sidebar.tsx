import { useState } from 'react';
import { 
  Sparkles, 
  Gamepad2, 
  Palette, 
  Briefcase, 
  Trophy, 
  Code, 
  Grid3x3, 
  Bell,
  Settings,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
}

const navItems = [
  { id: 'discover', label: 'Discover', icon: Sparkles },
  { id: 'arcade', label: 'Arcade', icon: Gamepad2 },
  { id: 'create', label: 'Create', icon: Palette },
  { id: 'work', label: 'Work', icon: Briefcase },
  { id: 'play', label: 'Play', icon: Trophy },
  { id: 'develop', label: 'Develop', icon: Code },
  { id: 'categories', label: 'Categories', icon: Grid3x3 },
  { id: 'updates', label: 'Updates', icon: Bell },
];

export function Sidebar({ collapsed, onToggle }: SidebarProps) {
  const [activeItem, setActiveItem] = useState('arcade');

  return (
    <aside
      className="fixed left-0 top-0 h-screen transition-all duration-300 ease-out z-40"
      style={{
        width: collapsed ? '80px' : '240px',
        background: 'var(--surface-glass)',
        backdropFilter: 'var(--surface-blur-heavy) saturate(1.1)',
        borderRight: '1px solid var(--border-glass)',
      }}
    >
      <div className="flex flex-col h-full p-4">
        {/* Logo Section */}
        <div className="flex items-center justify-between mb-8 h-12">
          {!collapsed && (
            <div className="flex items-center gap-2">
              <div 
                className="w-8 h-8 rounded-xl flex items-center justify-center"
                style={{
                  background: 'linear-gradient(135deg, var(--brand-start), var(--brand-end))',
                  boxShadow: 'var(--shadow-glow)',
                }}
              >
                <Gamepad2 size={18} color="white" />
              </div>
              <span className="font-semibold tracking-tight" style={{ color: 'var(--txt-primary)' }}>
                Game Store
              </span>
            </div>
          )}
          <button
            onClick={onToggle}
            className="p-2 rounded-lg transition-all hover:bg-white/5"
            style={{ color: 'var(--txt-secondary)' }}
          >
            {collapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
          </button>
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeItem === item.id;

            return (
              <button
                key={item.id}
                onClick={() => setActiveItem(item.id)}
                className="w-full group relative transition-all duration-200"
              >
                <div
                  className={`
                    flex items-center gap-3 px-3 py-2.5 rounded-xl
                    transition-all duration-200
                    ${isActive ? 'scale-[1.02]' : 'hover:scale-[1.01]'}
                  `}
                  style={{
                    background: isActive 
                      ? 'linear-gradient(135deg, var(--brand-start), var(--brand-end))'
                      : 'transparent',
                    boxShadow: isActive ? 'var(--shadow-glow)' : 'none',
                    color: isActive ? 'white' : 'var(--txt-secondary)',
                  }}
                >
                  <Icon size={20} />
                  {!collapsed && (
                    <span className="font-medium tracking-wide transition-opacity duration-200">
                      {item.label}
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </nav>

        {/* User Capsule */}
        <div className="mt-auto pt-4 border-t" style={{ borderColor: 'var(--border-glass)' }}>
          <div
            className="flex items-center gap-3 p-3 rounded-xl transition-all hover:bg-white/5 cursor-pointer"
            style={{ color: 'var(--txt-primary)' }}
          >
            <div className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0 bg-gradient-to-br from-purple-500 to-blue-500">
              <img
                src="https://images.unsplash.com/photo-1570170609489-43197f518df0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBwb3J0cmFpdCUyMHBlcnNvbnxlbnwxfHx8fDE3NjEzOTc3OTJ8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Ali Memarzade"
                className="w-full h-full object-cover"
              />
            </div>
            {!collapsed && (
              <div className="flex-1 min-w-0">
                <div className="font-semibold truncate">Ali Memarzade</div>
                <div className="tabular-nums" style={{ color: 'var(--txt-tertiary)', fontSize: '13px' }}>
                  $10.00
                </div>
              </div>
            )}
            {!collapsed && <Settings size={16} style={{ color: 'var(--txt-tertiary)' }} />}
          </div>
        </div>
      </div>
    </aside>
  );
}
