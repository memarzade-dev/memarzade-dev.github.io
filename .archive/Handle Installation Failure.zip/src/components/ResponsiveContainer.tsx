import { useIsMobile, useIsTablet, useIsDesktop } from '../hooks/useMediaQuery';

interface ResponsiveContainerProps {
  children: React.ReactNode;
  mobile?: React.ReactNode;
  tablet?: React.ReactNode;
  desktop?: React.ReactNode;
}

export function ResponsiveContainer({ children, mobile, tablet, desktop }: ResponsiveContainerProps) {
  const isMobile = useIsMobile();
  const isTablet = useIsTablet();
  const isDesktop = useIsDesktop();

  if (isMobile && mobile) {
    return <>{mobile}</>;
  }

  if (isTablet && tablet) {
    return <>{tablet}</>;
  }

  if (isDesktop && desktop) {
    return <>{desktop}</>;
  }

  return <>{children}</>;
}
