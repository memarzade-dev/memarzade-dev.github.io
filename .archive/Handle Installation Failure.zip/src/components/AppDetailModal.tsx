import { X, Star, Download, Share2, Heart } from 'lucide-react';
import { useState } from 'react';

interface AppDetailModalProps {
  appId: string;
  onClose: () => void;
}

// Mock app details
const appDetails = {
  name: 'Notability',
  subtitle: 'Take Notes, Markup PDFs',
  developer: 'Ginger Labs',
  category: 'Productivity',
  icon: '📝',
  iconBg: 'linear-gradient(135deg, #F59E0B 0%, #D97706 100%)',
  rating: 4.7,
  ratingCount: 125432,
  price: '$14.99',
  screenshots: [
    'https://images.unsplash.com/photo-1618761714954-0b8cd0026356?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcHAlMjBpbnRlcmZhY2UlMjBkZXNpZ258ZW58MXx8fHwxNzYxMzg2MDkwfDA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1545296664-39db56ad95bd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9kdWN0aXZpdHklMjBzb2Z0d2FyZXxlbnwxfHx8fDE3NjEzNDMxMjB8MA&ixlib=rb-4.1.0&q=80&w=1080',
  ],
  description: 'Notability is a powerful note-taker to annotate documents, sketch ideas, record lectures, take notes and more. It combines, typing, handwriting, photos, and audio into a single note to bring your projects to life.',
  whatsNew: 'This update includes improved handwriting recognition, new notebook templates, and performance improvements.',
  version: '14.2',
  size: '285 MB',
  compatibility: 'macOS 12.0 or later',
  languages: 'English, Spanish, French, German, Japanese, and 15 more',
  age: '4+',
};

export function AppDetailModal({ appId, onClose }: AppDetailModalProps) {
  const [activeTab, setActiveTab] = useState<'details' | 'reviews'>('details');

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-8"
      style={{
        background: 'rgba(0, 0, 0, 0.75)',
        backdropFilter: 'blur(20px)',
      }}
      onClick={onClose}
    >
      <div
        className="relative rounded-3xl overflow-hidden w-full max-w-5xl max-h-full"
        style={{
          background: '#1C1C1E',
          boxShadow: '0 20px 60px rgba(0, 0, 0, 0.5)',
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-6 right-6 z-10 p-2 rounded-full transition-all hover:bg-white/10"
          style={{ color: '#8E8E93' }}
        >
          <X size={24} />
        </button>

        {/* Scrollable Content */}
        <div className="overflow-y-auto max-h-[85vh]">
          {/* Header */}
          <div className="p-8 pb-6">
            <div className="flex gap-6">
              {/* Icon */}
              <div
                className="flex-shrink-0 rounded-3xl overflow-hidden"
                style={{
                  width: '120px',
                  height: '120px',
                  background: appDetails.iconBg,
                  boxShadow: '0 8px 24px rgba(0, 0, 0, 0.3)',
                }}
              >
                <div className="w-full h-full flex items-center justify-center" style={{ fontSize: '64px' }}>
                  {appDetails.icon}
                </div>
              </div>

              {/* Info */}
              <div className="flex-1">
                <h1
                  className="mb-1"
                  style={{
                    fontSize: '32px',
                    fontWeight: 700,
                    color: '#FFFFFF',
                  }}
                >
                  {appDetails.name}
                </h1>
                <p style={{ fontSize: '16px', color: '#8E8E93', marginBottom: '8px' }}>
                  {appDetails.subtitle}
                </p>
                <p style={{ fontSize: '14px', color: '#007AFF', marginBottom: '16px' }}>
                  {appDetails.developer}
                </p>

                {/* Rating */}
                <div className="flex items-center gap-4 mb-6">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span style={{ fontSize: '20px', fontWeight: 700, color: '#FFFFFF' }}>
                        {appDetails.rating}
                      </span>
                      <div className="flex gap-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            size={14}
                            fill={i < Math.floor(appDetails.rating) ? '#FFB800' : 'none'}
                            color={i < Math.floor(appDetails.rating) ? '#FFB800' : '#8E8E93'}
                          />
                        ))}
                      </div>
                    </div>
                    <p className="tabular-nums" style={{ fontSize: '12px', color: '#8E8E93' }}>
                      {appDetails.ratingCount.toLocaleString()} Ratings
                    </p>
                  </div>

                  <div style={{ width: '1px', height: '40px', background: 'rgba(255, 255, 255, 0.1)' }} />

                  <div>
                    <p style={{ fontSize: '20px', fontWeight: 700, color: '#FFFFFF' }}>4+</p>
                    <p style={{ fontSize: '12px', color: '#8E8E93' }}>Age</p>
                  </div>

                  <div style={{ width: '1px', height: '40px', background: 'rgba(255, 255, 255, 0.1)' }} />

                  <div>
                    <p style={{ fontSize: '14px', fontWeight: 600, color: '#FFFFFF' }}>
                      {appDetails.category}
                    </p>
                    <p style={{ fontSize: '12px', color: '#8E8E93' }}>Category</p>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center gap-3">
                  <button
                    className="px-8 py-3 rounded-xl transition-all hover:opacity-90"
                    style={{
                      background: '#007AFF',
                      fontSize: '16px',
                      fontWeight: 600,
                      color: '#FFFFFF',
                    }}
                  >
                    {appDetails.price === 'Free' ? 'GET' : appDetails.price}
                  </button>
                  <button
                    className="p-3 rounded-xl transition-all hover:bg-white/10"
                    style={{
                      background: 'rgba(255, 255, 255, 0.1)',
                      color: '#FFFFFF',
                    }}
                  >
                    <Heart size={20} />
                  </button>
                  <button
                    className="p-3 rounded-xl transition-all hover:bg-white/10"
                    style={{
                      background: 'rgba(255, 255, 255, 0.1)',
                      color: '#FFFFFF',
                    }}
                  >
                    <Share2 size={20} />
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Screenshots */}
          <div className="px-8 pb-6">
            <div className="flex gap-4 overflow-x-auto hide-scrollbar">
              {appDetails.screenshots.map((screenshot, index) => (
                <div
                  key={index}
                  className="flex-shrink-0 rounded-2xl overflow-hidden"
                  style={{
                    width: '400px',
                    height: '250px',
                  }}
                >
                  <img
                    src={screenshot}
                    alt={`Screenshot ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Tabs */}
          <div className="px-8">
            <div className="flex gap-6 border-b" style={{ borderColor: 'rgba(255, 255, 255, 0.08)' }}>
              <button
                className="pb-3 relative transition-colors"
                style={{
                  fontSize: '15px',
                  fontWeight: 500,
                  color: activeTab === 'details' ? '#FFFFFF' : '#8E8E93',
                }}
                onClick={() => setActiveTab('details')}
              >
                Details
                {activeTab === 'details' && (
                  <div 
                    className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full"
                    style={{ background: '#007AFF' }}
                  />
                )}
              </button>
              <button
                className="pb-3 relative transition-colors"
                style={{
                  fontSize: '15px',
                  fontWeight: 500,
                  color: activeTab === 'reviews' ? '#FFFFFF' : '#8E8E93',
                }}
                onClick={() => setActiveTab('reviews')}
              >
                Reviews
                {activeTab === 'reviews' && (
                  <div 
                    className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full"
                    style={{ background: '#007AFF' }}
                  />
                )}
              </button>
            </div>
          </div>

          {/* Tab Content */}
          <div className="p-8">
            {activeTab === 'details' ? (
              <div className="space-y-6">
                {/* Description */}
                <div>
                  <h3 style={{ fontSize: '18px', fontWeight: 600, color: '#FFFFFF', marginBottom: '12px' }}>
                    About
                  </h3>
                  <p style={{ fontSize: '14px', color: '#AEAEB2', lineHeight: '1.6' }}>
                    {appDetails.description}
                  </p>
                </div>

                {/* What's New */}
                <div>
                  <h3 style={{ fontSize: '18px', fontWeight: 600, color: '#FFFFFF', marginBottom: '12px' }}>
                    What's New
                  </h3>
                  <p style={{ fontSize: '13px', color: '#8E8E93', marginBottom: '8px' }}>
                    Version {appDetails.version}
                  </p>
                  <p style={{ fontSize: '14px', color: '#AEAEB2', lineHeight: '1.6' }}>
                    {appDetails.whatsNew}
                  </p>
                </div>

                {/* Information */}
                <div>
                  <h3 style={{ fontSize: '18px', fontWeight: 600, color: '#FFFFFF', marginBottom: '12px' }}>
                    Information
                  </h3>
                  <div className="space-y-3">
                    <InfoRow label="Size" value={appDetails.size} />
                    <InfoRow label="Compatibility" value={appDetails.compatibility} />
                    <InfoRow label="Languages" value={appDetails.languages} />
                    <InfoRow label="Age Rating" value={appDetails.age} />
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-12">
                <p style={{ fontSize: '15px', color: '#8E8E93' }}>
                  Reviews coming soon
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between py-2">
      <span style={{ fontSize: '14px', color: '#8E8E93' }}>{label}</span>
      <span style={{ fontSize: '14px', color: '#FFFFFF', textAlign: 'right', maxWidth: '60%' }}>{value}</span>
    </div>
  );
}
