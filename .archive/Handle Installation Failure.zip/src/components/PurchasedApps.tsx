import { Cloud, Download } from 'lucide-react';

interface App {
  name: string;
  date: string;
  icon: string;
  iconBg: string;
  status: 'cloud' | 'open';
}

const apps: App[] = [
  { name: 'Screen Mirror to TV & ...', date: '27 Aug 2025', icon: '📺', iconBg: 'linear-gradient(135deg, #667EEA 0%, #764BA2 100%)', status: 'open' },
  { name: 'Mirror Screen to Any Smart ...', date: '27 Aug 2025', icon: '📱', iconBg: 'linear-gradient(135deg, #4A5568 0%, #2D3748 100%)', status: 'open' },
  { name: 'OmniKey', date: '27 Aug 2025', icon: '🔧', iconBg: 'linear-gradient(135deg, #3182CE 0%, #2C5282 100%)', status: 'cloud' },
  { name: 'VMHub', date: '27 Aug 2025', icon: 'vm', iconBg: 'linear-gradient(135deg, #1A202C 0%, #2D3748 100%)', status: 'open' },
  { name: 'SSH Client - Secure ...', date: '27 Aug 2025', icon: '🖥️', iconBg: 'linear-gradient(135deg, #2C5282 0%, #2A4365 100%)', status: 'cloud' },
  
  { name: 'ServerBox', date: '27 Aug 2025', icon: '📦', iconBg: 'linear-gradient(135deg, #4A5568 0%, #2D3748 100%)', status: 'cloud' },
  { name: 'AnyMP4 Screen ...', date: '27 Aug 2025', icon: '🎬', iconBg: 'linear-gradient(135deg, #319795 0%, #2C7A7B 100%)', status: 'cloud' },
  { name: 'Coin Wallet: Buy & Sell ...', date: '27 Aug 2025', icon: '💰', iconBg: 'linear-gradient(135deg, #48BB78 0%, #38A169 100%)', status: 'open' },
  { name: 'Termius — Modern SSH ...', date: '27 Aug 2025', icon: '⚡', iconBg: 'linear-gradient(135deg, #4299E1 0%, #3182CE 100%)', status: 'cloud' },
  
  { name: 'Xcode', date: '27 Aug 2025', icon: '🔨', iconBg: 'linear-gradient(135deg, #3182CE 0%, #2C5282 100%)', status: 'cloud' },
  { name: 'Notchmeister', date: '27 Aug 2025', icon: '📱', iconBg: 'linear-gradient(135deg, #D69E2E 0%, #B7791F 100%)', status: 'cloud' },
  { name: 'Notepad Markdown Quick ...', date: '27 Aug 2025', icon: 'qd', iconBg: 'linear-gradient(135deg, #718096 0%, #4A5568 100%)', status: 'open' },
  { name: 'FocalBoard', date: '27 Aug 2025', icon: '🎯', iconBg: 'linear-gradient(135deg, #667EEA 0%, #764BA2 100%)', status: 'cloud' },
  
  { name: 'Writer - Notes, Lists, Editor', date: '27 Aug 2025', icon: '📝', iconBg: 'linear-gradient(135deg, #A0AEC0 0%, #718096 100%)', status: 'open' },
  { name: 'Migrate', date: '27 Aug 2025', icon: '🦅', iconBg: 'linear-gradient(135deg, #D69E2E 0%, #B7791F 100%)', status: 'cloud' },
  { name: 'Obsidian Web Clipper', date: '27 Aug 2025', icon: '💎', iconBg: 'linear-gradient(135deg, #805AD5 0%, #6B46C1 100%)', status: 'cloud' },
  { name: 'OrderGen—Orbit Goals', date: '27 Aug 2025', icon: '⚪', iconBg: 'linear-gradient(135deg, #E2E8F0 0%, #CBD5E0 100%)', status: 'cloud' },
  
  { name: 'Vio - ODB Ghouls ...', date: '27 Aug 2025', icon: 'V', iconBg: 'linear-gradient(135deg, #667EEA 0%, #764BA2 100%)', status: 'open' },
  { name: 'Cala - Dail Quotes', date: '27 Aug 2025', icon: '🌊', iconBg: 'linear-gradient(135deg, #4299E1 0%, #3182CE 100%)', status: 'cloud' },
  { name: 'My iPlist Country & IP ...', date: '27 Aug 2025', icon: '🌍', iconBg: 'linear-gradient(135deg, #718096 0%, #4A5568 100%)', status: 'open' },
  { name: 'To Do List - Reminders & ...', date: '27 Aug 2025', icon: '✓', iconBg: 'linear-gradient(135deg, #48BB78 0%, #38A169 100%)', status: 'cloud' },
  
  { name: 'Notion Web Clipper', date: '27 Aug 2025', icon: 'N', iconBg: 'linear-gradient(135deg, #2D3748 0%, #1A202C 100%)', status: 'open' },
  { name: 'Flow: Focus & Pomodoro ...', date: '27 Aug 2025', icon: '🌿', iconBg: 'linear-gradient(135deg, #48BB78 0%, #38A169 100%)', status: 'cloud' },
  { name: 'Chatbot: Ask AI Chat Bot', date: '27 Aug 2025', icon: '∞', iconBg: 'linear-gradient(135deg, #2D3748 0%, #1A202C 100%)', status: 'cloud' },
  { name: '9 App Launcher', date: '27 Aug 2025', icon: '⚪', iconBg: 'linear-gradient(135deg, #E53E3E 0%, #C53030 100%)', status: 'cloud' },
  
  { name: 'AI Bot: AI ChatBot & ...', date: '27 Aug 2025', icon: '🤖', iconBg: 'linear-gradient(135deg, #667EEA 0%, #764BA2 100%)', status: 'cloud' },
  { name: 'Form for Google Forms', date: '27 Aug 2025', icon: '📋', iconBg: 'linear-gradient(135deg, #667EEA 0%, #764BA2 100%)', status: 'cloud' },
  { name: 'Mailbox Web Browser', date: '27 Aug 2025', icon: 'M', iconBg: 'linear-gradient(135deg, #4299E1 0%, #3182CE 100%)', status: 'open' },
  { name: 'Note Taking - Email Me', date: '27 Aug 2025', icon: '📧', iconBg: 'linear-gradient(135deg, #D69E2E 0%, #B7791F 100%)', status: 'cloud' },
  { name: 'Mailbutler', date: '27 Aug 2025', icon: '✉️', iconBg: 'linear-gradient(135deg, #718096 0%, #4A5568 100%)', status: 'cloud' },
  
  { name: 'Docs for Google Docs and ...', date: '27 Aug 2025', icon: '📄', iconBg: 'linear-gradient(135deg, #3182CE 0%, #2C5282 100%)', status: 'cloud' },
];

export function PurchasedApps() {
  return (
    <div className="px-8 py-6">
      <div className="grid grid-cols-5 gap-x-4 gap-y-6">
        {apps.map((app, index) => (
          <div key={index} className="flex flex-col">
            {/* App Icon */}
            <div 
              className="w-16 h-16 rounded-2xl flex items-center justify-center mb-2.5"
              style={{
                background: app.iconBg,
                boxShadow: '0 2px 8px rgba(0, 0, 0, 0.15)',
              }}
            >
              <span style={{ fontSize: '32px' }}>{app.icon}</span>
            </div>

            {/* App Info */}
            <div className="mb-2">
              <h3 
                className="truncate mb-0.5"
                style={{
                  fontSize: '13px',
                  fontWeight: 400,
                  color: '#FFFFFF',
                  lineHeight: '1.3',
                }}
              >
                {app.name}
              </h3>
              <p 
                style={{
                  fontSize: '11px',
                  color: '#8E8E93',
                  lineHeight: '1.3',
                }}
              >
                {app.date}
              </p>
            </div>

            {/* Action Button/Icon */}
            <div className="flex items-center gap-2">
              {app.status === 'open' ? (
                <button
                  className="px-4 py-1 rounded-full transition-colors hover:bg-white/10"
                  style={{
                    background: 'rgba(255, 255, 255, 0.08)',
                    fontSize: '12px',
                    fontWeight: 500,
                    color: '#FFFFFF',
                    border: 'none',
                  }}
                >
                  Open
                </button>
              ) : (
                <button
                  className="transition-opacity hover:opacity-70"
                  style={{ color: '#8E8E93' }}
                >
                  <Cloud size={18} strokeWidth={1.5} />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
