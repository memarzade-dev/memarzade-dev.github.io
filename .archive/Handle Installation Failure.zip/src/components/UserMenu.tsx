import { useState, useRef } from 'react';
import { User, Settings, LogOut, HelpCircle, Moon, Sun } from 'lucide-react';
import { useClickOutside } from '../hooks/useClickOutside';
import { motion, AnimatePresence } from 'motion/react';

interface UserMenuProps {
  user: {
    name: string;
    email: string;
    avatar: string;
    balance: string;
  };
  onLogout: () => void;
  onSettings: () => void;
}

export function UserMenu({ user, onLogout, onSettings }: UserMenuProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(true);
  const menuRef = useRef<HTMLDivElement>(null);

  useClickOutside(menuRef, () => setIsOpen(false));

  const menuItems = [
    {
      icon: Settings,
      label: 'Settings',
      onClick: () => {
        onSettings();
        setIsOpen(false);
      },
    },
    {
      icon: HelpCircle,
      label: 'Help & Support',
      onClick: () => {
        console.log('Help');
        setIsOpen(false);
      },
    },
    {
      icon: darkMode ? Sun : Moon,
      label: darkMode ? 'Light Mode' : 'Dark Mode',
      onClick: () => {
        setDarkMode(!darkMode);
      },
    },
    {
      divider: true,
    },
    {
      icon: LogOut,
      label: 'Log Out',
      onClick: () => {
        onLogout();
        setIsOpen(false);
      },
      danger: true,
    },
  ];

  return (
    <div className="relative" ref={menuRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-3 p-2 rounded-xl transition-all hover:bg-white/5 w-full"
      >
        <div 
          className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0"
          style={{
            background: 'linear-gradient(135deg, #667EEA 0%, #764BA2 100%)',
          }}
        >
          <img
            src={user.avatar}
            alt={user.name}
            className="w-full h-full object-cover"
          />
        </div>
        <div className="flex-1 text-left min-w-0">
          <div
            className="truncate"
            style={{
              fontSize: '14px',
              fontWeight: 600,
              color: 'var(--txt-primary)',
            }}
          >
            {user.name}
          </div>
          <div
            className="truncate tabular-nums"
            style={{
              fontSize: '12px',
              color: 'var(--txt-tertiary)',
            }}
          >
            {user.balance}
          </div>
        </div>
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className="absolute bottom-full left-0 mb-2 w-64 py-2 rounded-xl backdrop-blur-xl"
            style={{
              background: 'var(--surface-glass)',
              border: '1px solid var(--border-glass)',
              boxShadow: 'var(--shadow-lg)',
            }}
          >
            {/* User Info */}
            <div className="px-4 py-3 border-b" style={{ borderColor: 'var(--border-glass)' }}>
              <div
                className="mb-1"
                style={{
                  fontSize: '15px',
                  fontWeight: 600,
                  color: 'var(--txt-primary)',
                }}
              >
                {user.name}
              </div>
              <div style={{ fontSize: '13px', color: 'var(--txt-secondary)' }}>
                {user.email}
              </div>
            </div>

            {/* Menu Items */}
            <div className="py-1">
              {menuItems.map((item, index) => {
                if (item.divider) {
                  return (
                    <div
                      key={index}
                      className="my-1 h-px"
                      style={{ background: 'var(--border-glass)' }}
                    />
                  );
                }

                const Icon = item.icon!;

                return (
                  <button
                    key={index}
                    onClick={item.onClick}
                    className="w-full flex items-center gap-3 px-4 py-2.5 transition-all hover:bg-white/10"
                    style={{
                      color: item.danger ? '#EF4444' : 'var(--txt-primary)',
                    }}
                  >
                    <Icon size={18} />
                    <span style={{ fontSize: '14px', fontWeight: 500 }}>{item.label}</span>
                  </button>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
