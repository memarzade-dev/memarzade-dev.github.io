export function AlertTriangleIcon() {
  return (
    <svg viewBox="0 0 64 64" width="34" height="34">
      <defs>
        <linearGradient id="warning-gradient" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffd24d" />
          <stop offset="1" stopColor="#f7a400" />
        </linearGradient>
      </defs>
      <path
        d="M29.7 6.7c1.4-2.4 4.9-2.4 6.3 0l25 44.2c1.4 2.4-.3 5.4-3.1 5.4H7.8c-2.8 0-4.5-3-3.1-5.4l25-44.2z"
        fill="url(#warning-gradient)"
        stroke="#d18c00"
        strokeWidth="1.2"
      />
      <rect x="30" y="21" width="4" height="20" rx="2" fill="#3a2a00" />
      <rect x="30" y="45" width="4" height="4" rx="2" fill="#3a2a00" />
    </svg>
  );
}
