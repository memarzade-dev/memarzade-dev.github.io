export function FigmaLogo() {
  return (
    <svg viewBox="0 0 256 256" className="w-full h-full">
      <defs>
        <clipPath id="figma-clip">
          <rect rx="56" ry="56" width="256" height="256" />
        </clipPath>
      </defs>
      <g clipPath="url(#figma-clip)">
        <rect width="256" height="256" fill="transparent" />
        <circle cx="96" cy="64" r="48" fill="#EA4C1D" />
        <circle cx="160" cy="64" r="48" fill="#FF7262" />
        <circle cx="96" cy="128" r="48" fill="#A259FF" />
        <circle cx="96" cy="192" r="48" fill="#1ABCFE" />
        <path d="M160 112a48 48 0 1 0 0-96v96z" fill="#0ACF83" />
      </g>
    </svg>
  );
}
