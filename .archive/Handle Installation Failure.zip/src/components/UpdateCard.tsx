import { ChevronDown, ChevronUp } from 'lucide-react';
import { useState } from 'react';

interface UpdateCardProps {
  id: string;
  name: string;
  subtitle: string;
  category: string;
  icon: string;
  iconBg: string;
  version: string;
  size: string;
  date: string;
  releaseNotes: string;
  isUpdating: boolean;
  onUpdate: () => void;
  onClick: () => void;
}

export function UpdateCard({
  name,
  subtitle,
  category,
  icon,
  iconBg,
  version,
  size,
  date,
  releaseNotes,
  isUpdating,
  onUpdate,
  onClick,
}: UpdateCardProps) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div
      className="rounded-2xl overflow-hidden"
      style={{
        background: 'rgba(255, 255, 255, 0.05)',
        border: '1px solid rgba(255, 255, 255, 0.08)',
      }}
    >
      {/* Main Content */}
      <div className="p-4">
        <div className="flex gap-4">
          {/* Icon */}
          <div
            className="flex-shrink-0 rounded-2xl overflow-hidden cursor-pointer"
            style={{
              width: '64px',
              height: '64px',
              background: iconBg,
              boxShadow: '0 4px 12px rgba(0, 0, 0, 0.25)',
            }}
            onClick={onClick}
          >
            <div className="w-full h-full flex items-center justify-center" style={{ fontSize: '32px' }}>
              {icon}
            </div>
          </div>

          {/* Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1 min-w-0">
                <h3
                  className="truncate cursor-pointer hover:text-[#007AFF] transition-colors"
                  style={{
                    fontSize: '15px',
                    fontWeight: 500,
                    color: '#FFFFFF',
                    marginBottom: '2px',
                  }}
                  onClick={onClick}
                >
                  {name}
                </h3>
                <p
                  className="truncate mb-2"
                  style={{
                    fontSize: '13px',
                    color: '#8E8E93',
                  }}
                >
                  {subtitle}
                </p>

                {/* Meta Info */}
                <div className="flex items-center gap-2 flex-wrap mb-2">
                  <span style={{ fontSize: '12px', color: '#8E8E93' }}>Version {version}</span>
                  <span style={{ color: '#8E8E93', fontSize: '12px' }}>•</span>
                  <span className="tabular-nums" style={{ fontSize: '12px', color: '#8E8E93' }}>{size}</span>
                  <span style={{ color: '#8E8E93', fontSize: '12px' }}>•</span>
                  <span style={{ fontSize: '12px', color: '#8E8E93' }}>{date}</span>
                </div>
              </div>

              {/* Update Button */}
              <button
                className="px-5 py-1.5 rounded-full transition-all flex-shrink-0"
                style={{
                  background: isUpdating ? 'rgba(255, 255, 255, 0.1)' : '#007AFF',
                  fontSize: '13px',
                  fontWeight: 600,
                  color: '#FFFFFF',
                }}
                onClick={onUpdate}
                disabled={isUpdating}
              >
                {isUpdating ? 'Updating...' : 'Update'}
              </button>
            </div>

            {/* Release Notes Toggle */}
            <button
              className="flex items-center gap-1 mt-2 transition-opacity hover:opacity-70"
              style={{
                fontSize: '13px',
                fontWeight: 500,
                color: '#007AFF',
              }}
              onClick={() => setExpanded(!expanded)}
            >
              {expanded ? (
                <>
                  Hide Release Notes
                  <ChevronUp size={14} />
                </>
              ) : (
                <>
                  Show Release Notes
                  <ChevronDown size={14} />
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Release Notes */}
      {expanded && (
        <div
          className="px-4 pb-4 pt-2"
          style={{
            borderTop: '1px solid rgba(255, 255, 255, 0.08)',
          }}
        >
          <p
            style={{
              fontSize: '13px',
              color: '#AEAEB2',
              lineHeight: '1.5',
            }}
          >
            {releaseNotes}
          </p>
        </div>
      )}
    </div>
  );
}
