import { Search } from 'lucide-react';

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  showSearch?: boolean;
  rightContent?: React.ReactNode;
}

export function PageHeader({ title, subtitle, showSearch = false, rightContent }: PageHeaderProps) {
  return (
    <header className="px-8 pt-6 pb-4" style={{ background: 'var(--bg-app)' }}>
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 
            className="tracking-tight"
            style={{
              fontSize: 'var(--text-4xl)',
              fontWeight: 'var(--font-weight-semibold)',
              color: 'var(--txt-primary)',
            }}
          >
            {title}
          </h1>
          {subtitle && (
            <p
              className="mt-1"
              style={{
                fontSize: 'var(--text-base)',
                color: 'var(--txt-secondary)',
              }}
            >
              {subtitle}
            </p>
          )}
        </div>

        {rightContent}
      </div>

      {showSearch && (
        <div className="relative">
          <div
            className="flex items-center gap-3 px-4 py-2.5 rounded-lg transition-all duration-[220ms] ease-out"
            style={{
              background: 'var(--surface-glass)',
              border: '1px solid var(--border-glass)',
              backdropFilter: 'var(--blur-sm)',
            }}
          >
            <Search size={18} style={{ color: 'var(--txt-tertiary)' }} strokeWidth={1.5} aria-hidden="true" />
            <input
              type="text"
              placeholder="Search for apps, games, and more..."
              aria-label="Search for apps, games, and more"
              className="flex-1 bg-transparent outline-none placeholder:opacity-60"
              style={{ 
                color: 'var(--txt-primary)',
                fontSize: 'var(--text-sm)',
              }}
            />
            <kbd
              className="px-2 py-0.5 rounded"
              style={{
                fontSize: 'var(--text-xs)',
                background: 'var(--surface-glass)',
                color: 'var(--txt-tertiary)',
                border: '1px solid var(--border-glass)',
                fontFamily: 'var(--font-mono)',
              }}
            >
              ⌘F
            </kbd>
          </div>
        </div>
      )}

      <div className="mt-4" style={{ height: '1px', background: 'var(--border-subtle)' }} />
    </header>
  );
}