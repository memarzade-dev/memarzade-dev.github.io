import { InputHTMLAttributes, ReactNode, forwardRef } from 'react';
import { motion } from 'motion/react';

interface GlassInputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  hint?: string;
  icon?: ReactNode;
  iconPosition?: 'left' | 'right';
  fullWidth?: boolean;
}

export const GlassInput = forwardRef<HTMLInputElement, GlassInputProps>(
  (
    {
      label,
      error,
      hint,
      icon,
      iconPosition = 'left',
      fullWidth = true,
      className = '',
      ...props
    },
    ref
  ) => {
    const hasError = !!error;

    return (
      <div className={`glass-input-group ${fullWidth ? 'w-full' : ''}`}>
        {label && (
          <label
            htmlFor={props.id}
            className="block mb-2"
            style={{
              fontSize: 'var(--text-sm)',
              fontWeight: 'var(--font-weight-medium)',
              color: 'var(--txt-primary)',
            }}
          >
            {label}
            {props.required && (
              <span style={{ color: 'var(--color-error)', marginLeft: '4px' }}>*</span>
            )}
          </label>
        )}

        <div className="relative">
          {icon && iconPosition === 'left' && (
            <div
              className="absolute left-0 top-1/2 -translate-y-1/2 flex items-center justify-center"
              style={{
                width: '40px',
                color: hasError ? 'var(--color-error)' : 'var(--txt-tertiary)',
              }}
            >
              {icon}
            </div>
          )}

          <motion.input
            ref={ref}
            whileFocus={{ scale: 1.01 }}
            transition={{ duration: 0.22, ease: [0.34, 1.56, 0.64, 1] }}
            className={`glass-input ${className}`}
            style={{
              width: '100%',
              height: '48px',
              padding: icon
                ? iconPosition === 'left'
                  ? '12px 16px 12px 48px'
                  : '12px 48px 12px 16px'
                : '12px 16px',
              background: 'var(--surface-glass)',
              border: hasError
                ? '1px solid var(--color-error)'
                : '1px solid var(--border-glass)',
              borderRadius: 'var(--radius-md)',
              fontSize: 'var(--text-base)',
              color: 'var(--txt-primary)',
              outline: 'none',
              transition: 'all 220ms ease-out',
              backdropFilter: 'var(--blur-sm)',
            }}
            onFocus={(e) => {
              e.currentTarget.style.borderColor = hasError
                ? 'var(--color-error)'
                : 'var(--color-primary)';
              e.currentTarget.style.boxShadow = hasError
                ? '0 0 0 3px rgba(255, 107, 107, 0.1)'
                : '0 0 0 3px var(--color-primary-alpha)';
              if (props.onFocus) props.onFocus(e);
            }}
            onBlur={(e) => {
              e.currentTarget.style.borderColor = hasError
                ? 'var(--color-error)'
                : 'var(--border-glass)';
              e.currentTarget.style.boxShadow = 'none';
              if (props.onBlur) props.onBlur(e);
            }}
            {...props}
          />

          {icon && iconPosition === 'right' && (
            <div
              className="absolute right-0 top-1/2 -translate-y-1/2 flex items-center justify-center"
              style={{
                width: '40px',
                color: hasError ? 'var(--color-error)' : 'var(--txt-tertiary)',
              }}
            >
              {icon}
            </div>
          )}
        </div>

        {(error || hint) && (
          <div
            className="mt-1"
            style={{
              fontSize: 'var(--text-xs)',
              color: error ? 'var(--color-error)' : 'var(--txt-tertiary)',
            }}
          >
            {error || hint}
          </div>
        )}
      </div>
    );
  }
);

GlassInput.displayName = 'GlassInput';