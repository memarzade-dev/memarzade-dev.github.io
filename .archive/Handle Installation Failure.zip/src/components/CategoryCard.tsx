interface CategoryCardProps {
  name: string;
  icon: string;
  iconBg: string;
  count: number;
  onClick: () => void;
}

export function CategoryCard({ name, icon, iconBg, count, onClick }: CategoryCardProps) {
  return (
    <button
      aria-label={`${name} category - ${count.toLocaleString()} apps`}
      className="group p-6 rounded-2xl transition-all duration-[220ms] ease-out hover:scale-[1.02]"
      style={{
        background: 'var(--surface-glass-light)',
        border: '1px solid var(--border-glass)',
      }}
      onClick={onClick}
    >
      <div className="flex flex-col items-start gap-4">
        {/* Icon */}
        <div
          className="w-16 h-16 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-110"
          style={{
            background: iconBg,
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.25)',
          }}
        >
          <span style={{ fontSize: '32px' }}>{icon}</span>
        </div>

        {/* Content */}
        <div className="w-full text-left">
          <h3
            className="mb-1 group-hover:text-[#007AFF] transition-colors duration-[220ms] ease-out"
            style={{
              fontSize: '17px',
              fontWeight: 600,
              color: 'var(--txt-primary)',
            }}
          >
            {name}
          </h3>
          <p
            className="tabular-nums"
            style={{
              fontSize: '13px',
              color: 'var(--txt-tertiary)',
            }}
          >
            {count.toLocaleString()} apps
          </p>
        </div>
      </div>
    </button>
  );
}