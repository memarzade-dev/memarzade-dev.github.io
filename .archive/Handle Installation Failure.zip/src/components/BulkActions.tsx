import { Trash2, Download, Archive, Copy, CheckSquare, Square } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface BulkActionsProps {
  selectedCount: number;
  onSelectAll: () => void;
  onDeselectAll: () => void;
  onDelete: () => void;
  onDownload?: () => void;
  onArchive?: () => void;
  onDuplicate?: () => void;
}

export function BulkActions({
  selectedCount,
  onSelectAll,
  onDeselectAll,
  onDelete,
  onDownload,
  onArchive,
  onDuplicate,
}: BulkActionsProps) {
  return (
    <AnimatePresence>
      {selectedCount > 0 && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          transition={{ duration: 0.2, ease: 'easeOut' }}
          className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40"
        >
          <div
            className="flex items-center gap-3 px-6 py-4 rounded-2xl backdrop-blur-xl"
            style={{
              background: 'var(--surface-glass)',
              border: '1px solid var(--border-glass-light)',
              boxShadow: 'var(--shadow-lg)',
            }}
          >
            {/* Selection Info */}
            <div className="flex items-center gap-3 pr-3 border-r" style={{ borderColor: 'var(--border-glass)' }}>
              <button
                onClick={onDeselectAll}
                className="p-2 rounded-lg transition-all hover:bg-white/10"
                style={{ color: 'var(--txt-secondary)' }}
                title="Deselect all"
              >
                <CheckSquare size={20} />
              </button>
              <span style={{ fontSize: '14px', fontWeight: 600, color: 'var(--txt-primary)' }}>
                {selectedCount} selected
              </span>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2">
              {onDownload && (
                <button
                  onClick={onDownload}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl transition-all hover:bg-white/10"
                  style={{
                    background: 'rgba(255, 255, 255, 0.06)',
                    border: '1px solid var(--border-glass)',
                    color: 'var(--txt-primary)',
                  }}
                  title="Download"
                >
                  <Download size={16} />
                  <span style={{ fontSize: '14px', fontWeight: 500 }}>Download</span>
                </button>
              )}

              {onDuplicate && (
                <button
                  onClick={onDuplicate}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl transition-all hover:bg-white/10"
                  style={{
                    background: 'rgba(255, 255, 255, 0.06)',
                    border: '1px solid var(--border-glass)',
                    color: 'var(--txt-primary)',
                  }}
                  title="Duplicate"
                >
                  <Copy size={16} />
                  <span style={{ fontSize: '14px', fontWeight: 500 }}>Duplicate</span>
                </button>
              )}

              {onArchive && (
                <button
                  onClick={onArchive}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl transition-all hover:bg-white/10"
                  style={{
                    background: 'rgba(255, 255, 255, 0.06)',
                    border: '1px solid var(--border-glass)',
                    color: 'var(--txt-primary)',
                  }}
                  title="Archive"
                >
                  <Archive size={16} />
                  <span style={{ fontSize: '14px', fontWeight: 500 }}>Archive</span>
                </button>
              )}

              <button
                onClick={onDelete}
                className="flex items-center gap-2 px-4 py-2 rounded-xl transition-all hover:bg-red-500/20"
                style={{
                  background: 'rgba(239, 68, 68, 0.1)',
                  border: '1px solid rgba(239, 68, 68, 0.3)',
                  color: '#EF4444',
                }}
                title="Delete"
              >
                <Trash2 size={16} />
                <span style={{ fontSize: '14px', fontWeight: 500 }}>Delete</span>
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
