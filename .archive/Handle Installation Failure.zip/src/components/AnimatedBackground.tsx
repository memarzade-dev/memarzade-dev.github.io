import { useEffect, useRef, useState } from 'react';

interface AnimatedBackgroundProps {
  variant?: 'net' | 'waves' | 'particles';
  color?: string;
  backgroundColor?: string;
}

export function AnimatedBackground({
  variant = 'net',
  color = '0x6F7DFF',
  backgroundColor = '0x0E0F13',
}: AnimatedBackgroundProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [vantaEffect, setVantaEffect] = useState<any>(null);

  useEffect(() => {
    // Check if running in browser and Vanta is available
    if (typeof window === 'undefined' || !containerRef.current) return;

    // Load Vanta.js dynamically
    const loadVanta = async () => {
      // Load THREE.js first
      if (!(window as any).THREE) {
        const threeScript = document.createElement('script');
        threeScript.src = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js';
        document.body.appendChild(threeScript);
        
        await new Promise((resolve) => {
          threeScript.onload = resolve;
        });
      }

      // Load Vanta NET effect
      if (!(window as any).VANTA) {
        const vantaScript = document.createElement('script');
        vantaScript.src = 'https://cdn.jsdelivr.net/npm/vanta@latest/dist/vanta.net.min.js';
        document.body.appendChild(vantaScript);
        
        await new Promise((resolve) => {
          vantaScript.onload = resolve;
        });
      }

      // Initialize Vanta effect
      if ((window as any).VANTA && containerRef.current) {
        const effect = (window as any).VANTA.NET({
          el: containerRef.current,
          color: parseInt(color.replace('0x', ''), 16),
          backgroundColor: parseInt(backgroundColor.replace('0x', ''), 16),
          points: 12,
          maxDistance: 30,
          spacing: 60,
          showDots: true,
        });
        
        setVantaEffect(effect);
      }
    };

    loadVanta();

    return () => {
      if (vantaEffect) {
        vantaEffect.destroy();
      }
    };
  }, [color, backgroundColor]);

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 -z-10"
      style={{
        background: `var(--color-background)`,
      }}
    />
  );
}

// Alternative: Pure CSS animated background (no external dependencies)
export function CSSAnimatedBackground() {
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden">
      <div
        className="absolute inset-0"
        style={{
          background: 'var(--color-background)',
        }}
      />
      
      {/* Animated gradient orbs */}
      <div
        className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full opacity-20 blur-3xl animate-float"
        style={{
          background: 'radial-gradient(circle, var(--color-primary) 0%, transparent 70%)',
          animationDuration: '8s',
          animationDelay: '0s',
        }}
      />
      
      <div
        className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full opacity-20 blur-3xl animate-float"
        style={{
          background: 'radial-gradient(circle, var(--color-secondary) 0%, transparent 70%)',
          animationDuration: '10s',
          animationDelay: '2s',
        }}
      />
      
      <div
        className="absolute top-1/2 left-1/2 w-96 h-96 rounded-full opacity-15 blur-3xl animate-float"
        style={{
          background: 'radial-gradient(circle, var(--color-accent) 0%, transparent 70%)',
          animationDuration: '12s',
          animationDelay: '4s',
        }}
      />
      
      {/* Noise texture overlay */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 400 400' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' /%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)' /%3E%3C/svg%3E")`,
        }}
      />
    </div>
  );
}
