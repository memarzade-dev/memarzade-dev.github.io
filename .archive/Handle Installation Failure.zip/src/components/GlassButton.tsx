import { ButtonHTMLAttributes, ReactNode } from 'react';
import { motion, HTMLMotionProps } from 'motion/react';

interface GlassButtonProps extends Omit<HTMLMotionProps<'button'>, 'children'> {
  children: ReactNode;
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  fullWidth?: boolean;
  icon?: ReactNode;
  iconPosition?: 'left' | 'right';
  loading?: boolean;
  disabled?: boolean;
}

export function GlassButton({
  children,
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  icon,
  iconPosition = 'right',
  loading = false,
  disabled = false,
  ...props
}: GlassButtonProps) {
  const sizeStyles = {
    sm: {
      padding: '8px 16px',
      fontSize: 'var(--text-sm)',
      height: '36px',
    },
    md: {
      padding: '12px 24px',
      fontSize: 'var(--text-base)',
      height: '44px',
    },
    lg: {
      padding: '16px 32px',
      fontSize: 'var(--text-lg)',
      height: '52px',
    },
  };

  const variantStyles = {
    primary: {
      background: 'var(--gradient-brand)',
      color: 'white',
      border: 'none',
      boxShadow: 'var(--shadow-glow-primary)',
    },
    secondary: {
      background: 'var(--surface-glass)',
      color: 'var(--txt-primary)',
      border: '1px solid var(--border-glass-light)',
      boxShadow: 'none',
      backdropFilter: 'var(--blur-sm)',
    },
    ghost: {
      background: 'transparent',
      color: 'var(--txt-primary)',
      border: '1px solid var(--border-subtle)',
      boxShadow: 'none',
    },
    danger: {
      background: 'var(--gradient-error)',
      color: 'white',
      border: 'none',
      boxShadow: 'var(--shadow-glow-error)',
    },
  };

  const isDisabled = disabled || loading;

  return (
    <motion.button
      whileHover={!isDisabled ? { scale: 1.02, y: -2 } : {}}
      whileTap={!isDisabled ? { scale: 0.98 } : {}}
      transition={{ duration: 0.22, ease: [0.34, 1.56, 0.64, 1] }}
      disabled={isDisabled}
      aria-disabled={isDisabled}
      className={`glass-button ${fullWidth ? 'w-full' : ''}`}
      style={{
        ...sizeStyles[size],
        ...variantStyles[variant],
        borderRadius: 'var(--radius-full)',
        fontWeight: 'var(--font-weight-semibold)',
        cursor: isDisabled ? 'not-allowed' : 'pointer',
        opacity: isDisabled ? 0.6 : 1,
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '8px',
        transition: 'all 220ms ease-out',
        position: 'relative',
        overflow: 'hidden',
      }}
      {...props}
    >
      {loading ? (
        <div className="flex items-center gap-2">
          <div
            className="animate-spin rounded-full border-2 border-current border-t-transparent"
            style={{ width: '16px', height: '16px' }}
            aria-hidden="true"
          />
          <span>Loading...</span>
        </div>
      ) : (
        <>
          {icon && iconPosition === 'left' && <span aria-hidden="true">{icon}</span>}
          <span>{children}</span>
          {icon && iconPosition === 'right' && <span aria-hidden="true">{icon}</span>}
        </>
      )}

      {/* Hover shine effect */}
      {!isDisabled && variant === 'primary' && (
        <motion.div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: 'linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent)',
            transform: 'translateX(-100%)',
          }}
          whileHover={{
            transform: 'translateX(100%)',
            transition: { duration: 0.6 },
          }}
          aria-hidden="true"
        />
      )}
    </motion.button>
  );
}