// Core types for the application

export interface Game {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  genre: string;
  category: string;
  price: string | number;
  rating: number;
  downloads: number;
  releaseDate: Date;
  developer: string;
  publisher: string;
  platform: Platform[];
  images: {
    thumbnail: string;
    cover: string;
    screenshots: string[];
  };
  features: string[];
  systemRequirements?: SystemRequirements;
  tags: string[];
  stock?: number;
  owned?: boolean;
}

export type Platform = 'Mac' | 'iOS' | 'iPadOS' | 'tvOS' | 'Cross-platform';

export interface SystemRequirements {
  os: string;
  processor: string;
  memory: string;
  graphics: string;
  storage: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  balance: number;
  role: 'admin' | 'user' | 'developer';
  joinedDate: Date;
  purchases: string[];
  wishlist: string[];
}

export interface Review {
  id: string;
  gameId: string;
  userId: string;
  userName: string;
  userAvatar: string;
  rating: number;
  title: string;
  content: string;
  helpful: number;
  date: Date;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  icon: string;
  gamesCount: number;
}

export interface Developer {
  id: string;
  name: string;
  logo: string;
  description: string;
  website: string;
  gamesCount: number;
  totalDownloads: number;
}

export interface Transaction {
  id: string;
  userId: string;
  gameId: string;
  amount: number;
  date: Date;
  status: 'completed' | 'pending' | 'refunded' | 'failed';
  paymentMethod: string;
}

export interface Stats {
  totalRevenue: number;
  totalSales: number;
  activeUsers: number;
  totalGames: number;
  avgRating: number;
  growthRate: number;
}
