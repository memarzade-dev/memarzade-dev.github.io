# Technical Architecture

**Project:** Game Store Admin Panel  
**System:** PixelPulse × macOS Sequoia  
**Version:** 1.0.0  
**Purpose:** Complete technical architecture, folder structure, and data flow

---

## 🏗️ Project Structure

```
/
├── App.tsx                      # Root component, routing logic
├── styles/
│   └── globals.css              # Design tokens, base styles, Tailwind config
├── components/
│   ├── [Custom Components].tsx  # 40+ custom feature components
│   ├── ui/                      # shadcn/ui primitives (40+ components)
│   ├── icons/                   # Custom icon components
│   └── figma/
│       └── ImageWithFallback.tsx  # Protected image component
├── pages/
│   ├── DashboardPage.tsx        # Analytics dashboard
│   ├── DiscoverPage.tsx         # Game catalog browsing
│   ├── ArcadePage.tsx           # Apple Arcade games
│   ├── CategoriesPage.tsx       # Category browser
│   ├── InventoryPage.tsx        # Stock management
│   ├── UpdatesPage.tsx          # App updates feed
│   ├── AccountPage.tsx          # User account settings
│   └── SearchPage.tsx           # Search results
├── context/
│   └── AppContext.tsx           # Global state (user, cart, wishlist, UI)
├── hooks/
│   ├── useLocalStorage.ts       # Persistent state
│   ├── useDebounce.ts           # Debounced values
│   ├── useMediaQuery.ts         # Responsive breakpoints
│   ├── useKeyboardNavigation.ts # Keyboard shortcuts
│   ├── useClickOutside.ts       # Outside click detection
│   └── useFocusTrap.ts          # Modal focus management
├── utils/
│   ├── mockData.ts              # Test data generators
│   ├── format.ts                # Data formatting (price, date)
│   ├── validators.ts            # Input validation
│   ├── helpers.ts               # General utilities
│   ├── constants.ts             # App constants
│   ├── api.ts                   # API utilities (future)
│   └── analytics.ts             # Analytics tracking
├── types/
│   └── index.ts                 # TypeScript type definitions
├── guidelines/
│   ├── Guidelines.md            # Master guidelines
│   ├── overview-system-design.md
│   ├── overview-components.md
│   └── design-tokens/
│       ├── colors.md
│       ├── typography.md
│       ├── spacing.md
│       ├── shadows.md
│       ├── blur.md
│       └── radius.md
├── docs/
│   ├── architecture.md          # This file
│   └── system-design.md
└── [Documentation Files]
    ├── DESIGN_SYSTEM.md         # Visual design spec
    ├── FEATURES.md              # Feature list
    ├── PRODUCTION_GUIDE.md      # Production notes
    └── Attributions.md          # Asset credits
```

---

## 🔧 Technology Stack

### Core Technologies

| Technology | Version | Purpose |
|------------|---------|---------|
| **React** | 18+ | UI framework |
| **TypeScript** | 5+ | Type safety |
| **Tailwind CSS** | 4.0 | Utility-first styling |
| **Vite** | Latest | Build tool, dev server |

### UI Libraries

| Library | Purpose |
|---------|---------|
| **shadcn/ui** | Accessible UI primitives |
| **Radix UI** | Headless components (via shadcn) |
| **Lucide React** | Icon library |
| **Recharts** | Data visualization |
| **Sonner** | Toast notifications |
| **react-slick** | Carousels (if used) |
| **motion/react** | Animations (Framer Motion) |

### Development Tools

- **ESLint**: Code linting
- **Prettier**: Code formatting
- **TypeScript**: Static typing

---

## 📊 Data Architecture

### Data Flow: Mock-First Approach

```
┌─────────────────────────────────────┐
│      /utils/mockData.ts             │
│  ┌───────────────────────────────┐  │
│  │ generateMockGames()           │  │
│  │ generateMockUser()            │  │
│  │ generateMockCategories()      │  │
│  │ generateMockTransactions()    │  │
│  │ ... etc                       │  │
│  └───────────────────────────────┘  │
└─────────────────┬───────────────────┘
                  │ Import & call
                  ▼
┌─────────────────────────────────────┐
│      Page Component                 │
│                                     │
│  const games = generateMockGames(); │
│  const user = generateMockUser();   │
└─────────────────┬───────────────────┘
                  │ Pass as props
                  ▼
┌─────────────────────────────────────┐
│    Feature Component                │
│                                     │
│  <GameGrid games={games} />         │
│  <GameCard {...game} />             │
└─────────────────────────────────────┘
```

### Data Types (`/types/index.ts`)

```typescript
// Core entities
- Game: Game/app data model
- User: User account data
- Review: User reviews
- Category: Game categories
- Developer: Developer/studio info
- Transaction: Purchase records
- Stats: Analytics metrics
```

### Mock Data Generators

**Available Functions:**
```typescript
generateMockGames(count?: number): Game[]
generateMockUser(): User
generateMockReviews(gameId: string, count?: number): Review[]
generateMockCategories(): Category[]
generateMockDevelopers(): Developer[]
generateMockTransactions(count?: number): Transaction[]
generateMockStats(): Stats
```

**Usage Pattern:**
```tsx
// In page component
const games = useMemo(() => generateMockGames(50), []);
```

---

## 🔄 State Management

### Global State: Context API

**Location**: `/context/AppContext.tsx`

```typescript
interface AppContextType {
  // User data
  user: User | null;
  setUser: (user: User | null) => void;

  // Shopping cart
  cart: Game[];
  addToCart: (game: Game) => void;
  removeFromCart: (gameId: string) => void;
  clearCart: () => void;

  // Wishlist
  wishlist: string[];
  addToWishlist: (gameId: string) => void;
  removeFromWishlist: (gameId: string) => void;

  // UI state
  sidebarCollapsed: boolean;
  toggleSidebar: () => void;
}
```

**Usage**:
```tsx
import { useApp } from '../context/AppContext';

function Component() {
  const { cart, addToCart } = useApp();
  // ...
}
```

**Note**: Context not currently wrapped in App.tsx — needs implementation

---

### Local State: Component State

**Pattern**:
```tsx
function Component() {
  const [localState, setLocalState] = useState(initialValue);
  const [isOpen, setIsOpen] = useState(false);
  // ...
}
```

**When to Use**:
- Form inputs
- Modal open/close
- Component-specific UI state
- Temporary data

---

### Persistent State: LocalStorage Hook

```tsx
import { useLocalStorage } from '../hooks/useLocalStorage';

function Component() {
  const [theme, setTheme] = useLocalStorage('theme', 'dark');
  // Auto-persists to localStorage
}
```

**Current Usage**: Available but not widely used  
**Future**: Persist cart, preferences, view settings

---

## 🗺️ Routing Architecture

### Current: State-Based Routing

**No URL routing library** — pages switched via state:

```tsx
// App.tsx
type PageType = 'dashboard' | 'discover' | 'arcade' | ...;
const [currentPage, setCurrentPage] = useState<PageType>('dashboard');

const renderPage = () => {
  switch (currentPage) {
    case 'dashboard': return <DashboardPage />;
    case 'discover': return <DiscoverPage />;
    // ...
  }
};
```

**Pros**:
- Simple implementation
- No dependencies
- Fast transitions

**Cons**:
- No URL syncing
- No browser history
- No deep linking
- Not shareable

---

### Future: React Router Integration

**Migration Path**:

1. Install React Router v6
2. Create route configuration:
```tsx
const routes = [
  { path: '/', element: <DashboardPage /> },
  { path: '/discover', element: <DiscoverPage /> },
  { path: '/arcade', element: <ArcadePage /> },
  // ...
];
```

3. Replace switch with `<Routes>`
4. Update navigation to use `<Link>` and `useNavigate()`

**Keep**: Same component structure, just wrap in routes

---

## 🎨 Styling Architecture

### Tailwind CSS v4

**Configuration**: Inline in `/styles/globals.css` (no config file)

**Custom Variants**:
```css
@custom-variant dark (&:is(.dark *));
```

---

### CSS Custom Properties (Design Tokens)

**Two Systems**:

1. **PixelPulse Tokens** (Primary)
   ```css
   --bg-panel, --txt-primary, --color-primary, etc.
   ```

2. **shadcn Tokens** (Secondary)
   ```css
   --background, --foreground, --primary, etc.
   ```

**Strategy**: Use PixelPulse for custom components, shadcn for shadcn/ui components

---

### Styling Method Priority

1. **Existing components** (highest priority)
2. **Tailwind utility classes**
3. **Inline styles with CSS variables**
4. **CSS modules** (rarely used)

**No**: Hardcoded values, Tailwind typography classes

---

## 🧩 Component Architecture

### Component Hierarchy

```
App.tsx (Root)
  ├── ErrorBoundary
  ├── AppSidebar (Navigation)
  ├── Page Components
  │     ├── PageHeader (Layout)
  │     ├── Feature Components
  │     │     ├── Display Components (Cards)
  │     │     ├── Composite Components (Carousels, Grids)
  │     │     └── Interactive Components (Modals, Forms)
  │     └── Feedback Components (Loading, Empty, Error)
  └── Global Overlays
        ├── SearchModal
        ├── AppDetailModal
        ├── NotificationCenter
        └── Toaster
```

---

### Component Patterns

**1. Presentational Components** (Most common)
```tsx
interface Props {
  data: DataType;
  onAction: () => void;
}

export function Component({ data, onAction }: Props) {
  return <div onClick={onAction}>{data.field}</div>;
}
```

**2. Container Components** (Pages)
```tsx
export function PageComponent() {
  const data = generateMockData();
  const [state, setState] = useState();

  return (
    <>
      <PageHeader title="..." />
      <main>
        <FeatureComponent data={data} />
      </main>
    </>
  );
}
```

**3. Compound Components** (Modals, Dialogs)
```tsx
<Dialog open={open} onOpenChange={setOpen}>
  <DialogContent>
    <DialogHeader>...</DialogHeader>
    <DialogBody>...</DialogBody>
  </DialogContent>
</Dialog>
```

---

## 🪝 Custom Hooks

### Available Hooks

| Hook | Purpose | Returns |
|------|---------|---------|
| `useLocalStorage` | Persist state | `[value, setValue]` |
| `useDebounce` | Delay rapid changes | `debouncedValue` |
| `useMediaQuery` | Breakpoint detection | `boolean` |
| `useKeyboardNavigation` | Keyboard shortcuts | Setup function |
| `useClickOutside` | Outside click | Setup ref |
| `useFocusTrap` | Modal focus trap | Setup ref |

**Pattern**:
```tsx
// Usage
const isDesktop = useMediaQuery('(min-width: 1024px)');
const debouncedSearch = useDebounce(searchQuery, 300);
```

---

## 🛠️ Utilities

### Format Utilities (`/utils/format.ts`)

```typescript
formatPrice(price: number | string): string
formatDate(date: Date, format?: string): string
formatNumber(num: number): string
```

---

### Validation Utilities (`/utils/validators.ts`)

```typescript
validateEmail(email: string): boolean
validatePrice(price: string): boolean
validateURL(url: string): boolean
```

---

### Analytics (`/utils/analytics.ts`)

```typescript
// Event tracking
trackEvent.gameViewed(id, title)
trackEvent.categoryViewed(category)
trackEvent.searchPerformed(query, results)

// Page tracking
analytics.page(pageName)
```

---

## 🔐 Error Handling

### Error Boundary

```tsx
<ErrorBoundary>
  <App />
</ErrorBoundary>
```

**Catches**: React component errors  
**Fallback**: Error UI (defined in ErrorBoundary component)

---

### Error States in Components

**Pattern**:
```tsx
if (loading) return <LoadingSpinner />;
if (error) return <ErrorState message={error.message} />;
if (!data) return <EmptyState />;
return <Content data={data} />;
```

---

## 📦 Build & Deployment

### Build Process

```bash
npm run build
```

**Output**: `/dist` folder with optimized bundle

---

### Environment Variables (Future)

```bash
# .env
VITE_API_URL=https://api.example.com
VITE_ANALYTICS_ID=UA-XXXXX-X
```

**Usage**:
```tsx
const apiUrl = import.meta.env.VITE_API_URL;
```

---

## 🚀 Performance Strategies

### Current Optimizations

- ✅ React 18 concurrent features
- ✅ Vite fast refresh
- ❌ No code splitting (all pages bundled)
- ❌ No lazy loading
- ❌ No memoization
- ❌ No virtualization

---

### Future Optimizations

**1. Code Splitting**:
```tsx
const DashboardPage = lazy(() => import('./pages/DashboardPage'));

<Suspense fallback={<LoadingSpinner />}>
  <DashboardPage />
</Suspense>
```

**2. Component Memoization**:
```tsx
export const GameCard = React.memo(function GameCard(props) {
  // ...
});
```

**3. Virtual Scrolling** (for large lists):
```tsx
import { FixedSizeGrid } from 'react-window';
```

**4. Image Optimization**:
```tsx
<img loading="lazy" src={...} />
```

---

## 🧪 Testing Strategy (Future)

### Recommended Stack

- **Vitest**: Unit test runner
- **React Testing Library**: Component tests
- **Playwright**: E2E tests

**Structure**:
```
/src
  /components
    GameCard.tsx
    GameCard.test.tsx
```

---

## 📚 Documentation Strategy

### Current Documentation

- ✅ `/guidelines/` - AI guidelines (comprehensive)
- ✅ `/docs/` - Architecture docs
- ✅ `/DESIGN_SYSTEM.md` - Visual design spec
- ✅ `/PRODUCTION_GUIDE.md` - Production notes

---

## 🔮 Migration Paths

### API Integration

**Current**: Mock data  
**Future**: Real API

**Steps**:
1. Create API client in `/utils/api.ts`
2. Add loading/error states to pages
3. Replace `generateMockGames()` with `fetchGames()`
4. Keep mock data as fallback

---

### State Management Upgrade

**Current**: Context API  
**If needed**: Zustand or Redux Toolkit

**When**:
- Context becomes too complex
- Performance issues with re-renders
- Need middleware (logging, persistence)

---

## 📖 Related Documentation

- **System Design**: `guidelines/overview-system-design.md`
- **Component Catalog**: `guidelines/overview-components.md`
- **Master Guidelines**: `guidelines/Guidelines.md`
- **Design Tokens**: `guidelines/design-tokens/*.md`

---

**This architecture document is the technical source of truth. Refer here for implementation patterns, folder structure, and system design decisions.**
