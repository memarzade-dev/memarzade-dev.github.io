// API client for backend communication

export class APIError extends Error {
  constructor(
    message: string,
    public status: number,
    public data?: any
  ) {
    super(message);
    this.name = 'APIError';
  }
}

interface RequestOptions extends RequestInit {
  params?: Record<string, string>;
}

class APIClient {
  private baseURL: string;
  private defaultHeaders: HeadersInit;

  constructor(baseURL: string = '') {
    this.baseURL = baseURL || process.env.REACT_APP_API_URL || '';
    this.defaultHeaders = {
      'Content-Type': 'application/json',
    };
  }

  private getAuthToken(): string | null {
    // Get token from localStorage or context
    return localStorage.getItem('auth_token');
  }

  private async request<T>(
    endpoint: string,
    options: RequestOptions = {}
  ): Promise<T> {
    const { params, ...fetchOptions } = options;

    // Build URL with query params
    const url = new URL(endpoint, this.baseURL);
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        url.searchParams.append(key, value);
      });
    }

    // Add auth token if available
    const token = this.getAuthToken();
    const headers = {
      ...this.defaultHeaders,
      ...fetchOptions.headers,
      ...(token && { Authorization: `Bearer ${token}` }),
    };

    try {
      const response = await fetch(url.toString(), {
        ...fetchOptions,
        headers,
      });

      // Handle non-2xx responses
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new APIError(
          errorData.message || `HTTP ${response.status}: ${response.statusText}`,
          response.status,
          errorData
        );
      }

      // Handle empty responses
      const contentType = response.headers.get('content-type');
      if (contentType?.includes('application/json')) {
        return await response.json();
      }

      return {} as T;
    } catch (error) {
      if (error instanceof APIError) {
        throw error;
      }
      throw new APIError(
        error instanceof Error ? error.message : 'Network error',
        0
      );
    }
  }

  // HTTP Methods
  get<T>(endpoint: string, options?: RequestOptions): Promise<T> {
    return this.request<T>(endpoint, { ...options, method: 'GET' });
  }

  post<T>(endpoint: string, data?: any, options?: RequestOptions): Promise<T> {
    return this.request<T>(endpoint, {
      ...options,
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  put<T>(endpoint: string, data?: any, options?: RequestOptions): Promise<T> {
    return this.request<T>(endpoint, {
      ...options,
      method: 'PUT',
      body: JSON.stringify(data),
    });
  }

  patch<T>(endpoint: string, data?: any, options?: RequestOptions): Promise<T> {
    return this.request<T>(endpoint, {
      ...options,
      method: 'PATCH',
      body: JSON.stringify(data),
    });
  }

  delete<T>(endpoint: string, options?: RequestOptions): Promise<T> {
    return this.request<T>(endpoint, { ...options, method: 'DELETE' });
  }
}

// Create singleton instance
export const api = new APIClient();

// API endpoints organized by resource
export const endpoints = {
  // Games
  games: {
    list: (params?: Record<string, string>) => api.get('/games', { params }),
    get: (id: string) => api.get(`/games/${id}`),
    create: (data: any) => api.post('/games', data),
    update: (id: string, data: any) => api.put(`/games/${id}`, data),
    delete: (id: string) => api.delete(`/games/${id}`),
  },

  // Users
  users: {
    me: () => api.get('/users/me'),
    update: (data: any) => api.patch('/users/me', data),
    purchases: () => api.get('/users/me/purchases'),
    wishlist: () => api.get('/users/me/wishlist'),
  },

  // Auth
  auth: {
    login: (email: string, password: string) =>
      api.post('/auth/login', { email, password }),
    logout: () => api.post('/auth/logout'),
    register: (data: any) => api.post('/auth/register', data),
    refresh: () => api.post('/auth/refresh'),
  },

  // Categories
  categories: {
    list: () => api.get('/categories'),
    get: (id: string) => api.get(`/categories/${id}`),
  },

  // Reviews
  reviews: {
    list: (gameId: string) => api.get(`/games/${gameId}/reviews`),
    create: (gameId: string, data: any) =>
      api.post(`/games/${gameId}/reviews`, data),
  },

  // Analytics
  analytics: {
    stats: () => api.get('/analytics/stats'),
    revenue: (params?: Record<string, string>) =>
      api.get('/analytics/revenue', { params }),
    topGames: (params?: Record<string, string>) =>
      api.get('/analytics/top-games', { params }),
  },

  // Search
  search: {
    games: (query: string) => api.get('/search/games', { params: { q: query } }),
    all: (query: string) => api.get('/search', { params: { q: query } }),
  },
};

// React hooks for API calls
export function useAPI() {
  const handleError = (error: unknown) => {
    if (error instanceof APIError) {
      console.error(`API Error ${error.status}:`, error.message);
      return error;
    }
    console.error('Unknown error:', error);
    return new APIError('An unexpected error occurred', 0);
  };

  return {
    api,
    endpoints,
    handleError,
  };
}

// Example usage:
/*
  import { endpoints } from './utils/api';

  // Fetch games
  const games = await endpoints.games.list({ genre: 'action' });

  // Create game
  const newGame = await endpoints.games.create({ title: 'New Game', ... });

  // Error handling
  try {
    await endpoints.auth.login(email, password);
  } catch (error) {
    if (error instanceof APIError) {
      if (error.status === 401) {
        // Handle unauthorized
      }
    }
  }
*/
