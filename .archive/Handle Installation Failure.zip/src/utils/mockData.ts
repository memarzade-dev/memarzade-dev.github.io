// Mock data generators for testing and development

import { Game, User, Review, Category, Developer, Transaction, Stats } from '../types';

export const generateMockGames = (count: number = 50): Game[] => {
  const genres = ['Action', 'RPG', 'Horror', 'Puzzle', 'Racing', 'Strategy', 'Adventure', 'Simulation'];
  const platforms: Array<Game['platform'][0]> = ['Mac', 'iOS', 'iPadOS', 'Cross-platform'];
  
  return Array.from({ length: count }, (_, i) => ({
    id: `game-${i + 1}`,
    title: `Amazing Game ${i + 1}`,
    subtitle: 'Epic gaming experience',
    description: 'An incredible gaming experience that will keep you entertained for hours. Features stunning graphics, engaging gameplay, and an immersive story.',
    genre: genres[i % genres.length],
    category: genres[i % genres.length],
    price: i % 3 === 0 ? 'Free' : `$${(Math.random() * 50 + 10).toFixed(2)}`,
    rating: parseFloat((Math.random() * 2 + 3).toFixed(1)),
    downloads: Math.floor(Math.random() * 100000),
    releaseDate: new Date(Date.now() - Math.random() * 365 * 24 * 60 * 60 * 1000),
    developer: `Studio ${Math.floor(i / 5) + 1}`,
    publisher: `Publisher ${Math.floor(i / 10) + 1}`,
    platform: [platforms[i % platforms.length]],
    images: {
      thumbnail: `https://images.unsplash.com/photo-${1492515114049 + i}-778a9051fecb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400`,
      cover: `https://images.unsplash.com/photo-${1492515114049 + i}-778a9051fecb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1200`,
      screenshots: [
        `https://images.unsplash.com/photo-${1492515114049 + i}-778a9051fecb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=800`,
      ],
    },
    features: ['Single Player', 'Achievements', 'Cloud Save', 'Controller Support'],
    tags: ['Popular', 'New Release', 'Trending'],
    stock: Math.floor(Math.random() * 100),
    owned: i % 5 === 0,
  }));
};

export const generateMockUser = (): User => ({
  id: 'user-1',
  name: 'Ali Memarzade',
  email: 'ali@example.com',
  avatar: 'https://images.unsplash.com/photo-1570170609489-43197f518df0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400',
  balance: 10.00,
  role: 'admin',
  joinedDate: new Date('2023-01-15'),
  purchases: [],
  wishlist: [],
});

export const generateMockReviews = (gameId: string, count: number = 10): Review[] => {
  return Array.from({ length: count }, (_, i) => ({
    id: `review-${i + 1}`,
    gameId,
    userId: `user-${i + 1}`,
    userName: `User ${i + 1}`,
    userAvatar: `https://images.unsplash.com/photo-${1570170609489 + i}-43197f518df0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=200`,
    rating: Math.floor(Math.random() * 2 + 3.5),
    title: 'Great game!',
    content: 'I really enjoyed playing this game. The graphics are stunning and the gameplay is very engaging.',
    helpful: Math.floor(Math.random() * 50),
    date: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000),
  }));
};

export const generateMockCategories = (): Category[] => {
  const categories = [
    { name: 'Action', icon: '⚔️', description: 'Fast-paced action games' },
    { name: 'RPG', icon: '🎮', description: 'Role-playing adventures' },
    { name: 'Horror', icon: '👻', description: 'Spine-chilling experiences' },
    { name: 'Puzzle', icon: '🧩', description: 'Brain-teasing challenges' },
    { name: 'Racing', icon: '🏎️', description: 'High-speed racing' },
    { name: 'Strategy', icon: '♟️', description: 'Strategic gameplay' },
  ];

  return categories.map((cat, i) => ({
    id: `cat-${i + 1}`,
    name: cat.name,
    slug: cat.name.toLowerCase(),
    description: cat.description,
    icon: cat.icon,
    gamesCount: Math.floor(Math.random() * 100 + 50),
  }));
};

export const generateMockStats = (): Stats => ({
  totalRevenue: 62450,
  totalSales: 5800,
  activeUsers: 12450,
  totalGames: 250,
  avgRating: 4.6,
  growthRate: 18.2,
});

export const mockData = {
  games: generateMockGames(50),
  user: generateMockUser(),
  categories: generateMockCategories(),
  stats: generateMockStats(),
};
