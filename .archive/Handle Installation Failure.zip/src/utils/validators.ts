// Validation utilities
export const validators = {
  email: (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  },

  price: (price: string): boolean => {
    const priceRegex = /^\$?\d+(\.\d{2})?$/;
    return priceRegex.test(price) || price.toLowerCase() === 'free';
  },

  url: (url: string): boolean => {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  },

  required: (value: any): boolean => {
    if (typeof value === 'string') return value.trim().length > 0;
    if (typeof value === 'number') return !isNaN(value);
    return value != null;
  },

  minLength: (value: string, min: number): boolean => {
    return value.length >= min;
  },

  maxLength: (value: string, max: number): boolean => {
    return value.length <= max;
  },

  numberRange: (value: number, min: number, max: number): boolean => {
    return value >= min && value <= max;
  },
};

export type ValidationResult = {
  valid: boolean;
  errors: string[];
};

export const validateForm = (
  data: Record<string, any>,
  rules: Record<string, Array<(value: any) => string | null>>
): ValidationResult => {
  const errors: string[] = [];

  for (const [field, fieldRules] of Object.entries(rules)) {
    const value = data[field];
    for (const rule of fieldRules) {
      const error = rule(value);
      if (error) {
        errors.push(error);
      }
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
};
