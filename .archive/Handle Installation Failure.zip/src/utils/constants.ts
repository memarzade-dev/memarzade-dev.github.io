// Application constants

export const APP_NAME = 'Game Store Admin Panel';
export const APP_VERSION = '1.0.0';
export const APP_DESCRIPTION = 'Professional game store management platform';

// Breakpoints
export const BREAKPOINTS = {
  mobile: 768,
  tablet: 1024,
  desktop: 1440,
  wide: 1920,
} as const;

// Animation durations (ms)
export const ANIMATION_DURATION = {
  fast: 150,
  normal: 220,
  slow: 300,
  verySlow: 500,
} as const;

// Transitions
export const TRANSITIONS = {
  spring: 'cubic-bezier(0.34, 1.56, 0.64, 1)',
  ease: 'cubic-bezier(0.4, 0, 0.2, 1)',
  easeIn: 'cubic-bezier(0.4, 0, 1, 1)',
  easeOut: 'cubic-bezier(0, 0, 0.2, 1)',
  easeInOut: 'cubic-bezier(0.4, 0, 0.2, 1)',
} as const;

// Z-index layers
export const Z_INDEX = {
  dropdown: 1000,
  modal: 1100,
  popover: 1200,
  tooltip: 1300,
  notification: 1400,
} as const;

// Pagination
export const DEFAULT_PAGE_SIZE = 25;
export const PAGE_SIZE_OPTIONS = [10, 25, 50, 100] as const;

// Date formats
export const DATE_FORMATS = {
  short: 'MMM d, yyyy',
  long: 'MMMM d, yyyy',
  full: 'EEEE, MMMM d, yyyy',
  time: 'h:mm a',
  datetime: 'MMM d, yyyy h:mm a',
} as const;

// File size limits (bytes)
export const FILE_SIZE_LIMITS = {
  image: 5 * 1024 * 1024, // 5MB
  video: 50 * 1024 * 1024, // 50MB
  document: 10 * 1024 * 1024, // 10MB
} as const;

// Accepted file types
export const ACCEPTED_FILE_TYPES = {
  images: ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
  videos: ['video/mp4', 'video/webm', 'video/ogg'],
  documents: ['application/pdf', 'application/msword'],
} as const;

// Game genres
export const GAME_GENRES = [
  'Action',
  'Adventure',
  'RPG',
  'Strategy',
  'Simulation',
  'Sports',
  'Racing',
  'Puzzle',
  'Horror',
  'Indie',
  'MMO',
  'Fighting',
  'Platformer',
] as const;

// Platforms
export const PLATFORMS = [
  'Mac',
  'iOS',
  'iPadOS',
  'tvOS',
  'Cross-platform',
] as const;

// Price ranges
export const PRICE_RANGES = [
  { id: 'free', label: 'Free', min: 0, max: 0 },
  { id: 'under10', label: 'Under $10', min: 0.01, max: 9.99 },
  { id: '10to20', label: '$10 - $20', min: 10, max: 20 },
  { id: '20to40', label: '$20 - $40', min: 20, max: 40 },
  { id: 'over40', label: 'Over $40', min: 40, max: Infinity },
] as const;

// Rating levels
export const RATING_LEVELS = {
  excellent: { min: 4.5, label: 'Excellent', color: '#10B981' },
  veryGood: { min: 4.0, label: 'Very Good', color: '#3B82F6' },
  good: { min: 3.5, label: 'Good', color: '#F59E0B' },
  average: { min: 3.0, label: 'Average', color: '#FB923C' },
  poor: { min: 0, label: 'Poor', color: '#EF4444' },
} as const;

// Status types
export const STATUS_TYPES = {
  active: { label: 'Active', color: '#10B981' },
  pending: { label: 'Pending', color: '#F59E0B' },
  inactive: { label: 'Inactive', color: '#6B7280' },
  error: { label: 'Error', color: '#EF4444' },
} as const;

// Sort options
export const SORT_OPTIONS = [
  { value: 'newest', label: 'Newest First' },
  { value: 'oldest', label: 'Oldest First' },
  { value: 'popular', label: 'Most Popular' },
  { value: 'rating', label: 'Highest Rated' },
  { value: 'price-low', label: 'Price: Low to High' },
  { value: 'price-high', label: 'Price: High to Low' },
  { value: 'name-asc', label: 'Name: A to Z' },
  { value: 'name-desc', label: 'Name: Z to A' },
] as const;

// API timeouts (ms)
export const API_TIMEOUT = {
  default: 30000,
  upload: 60000,
  download: 120000,
} as const;

// Cache durations (ms)
export const CACHE_DURATION = {
  short: 5 * 60 * 1000, // 5 minutes
  medium: 30 * 60 * 1000, // 30 minutes
  long: 24 * 60 * 60 * 1000, // 24 hours
} as const;

// Keyboard shortcuts
export const KEYBOARD_SHORTCUTS = {
  search: { key: 'k', meta: true, description: 'Open search' },
  help: { key: '/', meta: true, description: 'Show shortcuts' },
  dashboard: { key: '1', meta: true, description: 'Go to Dashboard' },
  inventory: { key: '2', meta: true, description: 'Go to Inventory' },
  discover: { key: '3', meta: true, description: 'Go to Discover' },
  newItem: { key: 'n', meta: true, description: 'New item' },
  save: { key: 's', meta: true, description: 'Save' },
  export: { key: 'e', meta: true, description: 'Export' },
} as const;

// Toast default durations (ms)
export const TOAST_DURATION = {
  success: 3000,
  error: 5000,
  info: 4000,
  warning: 4000,
} as const;

// Local storage keys
export const STORAGE_KEYS = {
  authToken: 'auth_token',
  refreshToken: 'refresh_token',
  user: 'user_data',
  preferences: 'user_preferences',
  cart: 'shopping_cart',
  wishlist: 'wishlist',
  recentSearches: 'recent_searches',
  sidebarCollapsed: 'sidebar_collapsed',
} as const;

// API endpoints base
export const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001/api';

// Feature flags
export const FEATURES = {
  analytics: true,
  darkMode: true,
  multiLanguage: false,
  notifications: true,
  chat: false,
  videoCalls: false,
} as const;

// Regex patterns
export const PATTERNS = {
  email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  phone: /^\+?[\d\s\-()]+$/,
  url: /^https?:\/\/.+/,
  slug: /^[a-z0-9]+(?:-[a-z0-9]+)*$/,
  username: /^[a-zA-Z0-9_]{3,20}$/,
  password: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/,
} as const;

// Error messages
export const ERROR_MESSAGES = {
  required: 'This field is required',
  invalidEmail: 'Please enter a valid email address',
  invalidPhone: 'Please enter a valid phone number',
  invalidURL: 'Please enter a valid URL',
  passwordTooShort: 'Password must be at least 8 characters',
  passwordWeak: 'Password must contain uppercase, lowercase, and numbers',
  networkError: 'Network error. Please check your connection.',
  serverError: 'Server error. Please try again later.',
  unauthorized: 'You are not authorized to perform this action.',
  notFound: 'The requested resource was not found.',
  validationError: 'Please check your input and try again.',
} as const;

// Success messages
export const SUCCESS_MESSAGES = {
  saved: 'Successfully saved',
  created: 'Successfully created',
  updated: 'Successfully updated',
  deleted: 'Successfully deleted',
  uploaded: 'Successfully uploaded',
  exported: 'Successfully exported',
  copied: 'Copied to clipboard',
} as const;
