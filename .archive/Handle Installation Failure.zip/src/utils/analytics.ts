// Analytics tracking utilities
export const analytics = {
  track: (event: string, properties?: Record<string, any>) => {
    if (process.env.NODE_ENV === 'development') {
      console.log('[Analytics]', event, properties);
    }
    // In production, send to your analytics service:
    // window.analytics?.track(event, properties);
  },

  page: (name: string, properties?: Record<string, any>) => {
    if (process.env.NODE_ENV === 'development') {
      console.log('[Analytics Page]', name, properties);
    }
    // window.analytics?.page(name, properties);
  },

  identify: (userId: string, traits?: Record<string, any>) => {
    if (process.env.NODE_ENV === 'development') {
      console.log('[Analytics Identify]', userId, traits);
    }
    // window.analytics?.identify(userId, traits);
  },
};

// Track specific events
export const trackEvent = {
  gameViewed: (gameId: string, gameName: string) => {
    analytics.track('Game Viewed', { gameId, gameName });
  },

  gamePurchased: (gameId: string, gameName: string, price: string) => {
    analytics.track('Game Purchased', { gameId, gameName, price });
  },

  searchPerformed: (query: string, resultsCount: number) => {
    analytics.track('Search Performed', { query, resultsCount });
  },

  categoryViewed: (category: string) => {
    analytics.track('Category Viewed', { category });
  },

  filterApplied: (filterType: string, filterValue: string) => {
    analytics.track('Filter Applied', { filterType, filterValue });
  },

  sidebarToggled: (collapsed: boolean) => {
    analytics.track('Sidebar Toggled', { collapsed });
  },
};
