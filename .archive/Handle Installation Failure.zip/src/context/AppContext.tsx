import { createContext, useContext, useState, ReactNode } from 'react';
import { User, Game } from '../types';

interface AppContextType {
  user: User | null;
  setUser: (user: User | null) => void;
  cart: Game[];
  addToCart: (game: Game) => void;
  removeFromCart: (gameId: string) => void;
  clearCart: () => void;
  wishlist: string[];
  addToWishlist: (gameId: string) => void;
  removeFromWishlist: (gameId: string) => void;
  sidebarCollapsed: boolean;
  toggleSidebar: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [cart, setCart] = useState<Game[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const addToCart = (game: Game) => {
    setCart((prev) => {
      if (prev.find((g) => g.id === game.id)) {
        return prev;
      }
      return [...prev, game];
    });
  };

  const removeFromCart = (gameId: string) => {
    setCart((prev) => prev.filter((g) => g.id !== gameId));
  };

  const clearCart = () => {
    setCart([]);
  };

  const addToWishlist = (gameId: string) => {
    setWishlist((prev) => {
      if (prev.includes(gameId)) {
        return prev;
      }
      return [...prev, gameId];
    });
  };

  const removeFromWishlist = (gameId: string) => {
    setWishlist((prev) => prev.filter((id) => id !== gameId));
  };

  const toggleSidebar = () => {
    setSidebarCollapsed((prev) => !prev);
  };

  return (
    <AppContext.Provider
      value={{
        user,
        setUser,
        cart,
        addToCart,
        removeFromCart,
        clearCart,
        wishlist,
        addToWishlist,
        removeFromWishlist,
        sidebarCollapsed,
        toggleSidebar,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
