import { useState } from 'react';
import { AppSidebar } from './components/AppSidebar';
import { DiscoverPage } from './pages/DiscoverPage';
import { ArcadePage } from './pages/ArcadePage';
import { CategoriesPage } from './pages/CategoriesPage';
import { SearchPage } from './pages/SearchPage';
import { UpdatesPage } from './pages/UpdatesPage';
import { AccountPage } from './pages/AccountPage';
import { DashboardPage } from './pages/DashboardPage';
import { InventoryPage } from './pages/InventoryPage';
import { AppDetailModal } from './components/AppDetailModal';
import { SearchModal } from './components/SearchModal';
import { NotificationCenter, useNotifications } from './components/NotificationCenter';
import { ErrorBoundary } from './components/ErrorBoundary';
import { useCommandK } from './hooks/useKeyboardNavigation';
import { Toaster } from './components/ui/sonner';
import { trackEvent, analytics } from './utils/analytics';

export type PageType = 'discover' | 'arcade' | 'create' | 'work' | 'play' | 'develop' | 'categories' | 'updates' | 'account' | 'search' | 'dashboard' | 'inventory';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageType>('dashboard');
  const [selectedApp, setSelectedApp] = useState<string | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const { notifications, addNotification, dismissNotification } = useNotifications();

  // Command+K shortcut for search
  useCommandK(() => setSearchOpen(true));

  const handlePageChange = (page: PageType) => {
    setCurrentPage(page);
    analytics.page(page);
    trackEvent.categoryViewed(page);
  };

  const handleAppClick = (appId: string) => {
    setSelectedApp(appId);
    trackEvent.gameViewed(appId, `App ${appId}`);
  };

  const handleSearch = (query: string) => {
    console.log('Searching for:', query);
    trackEvent.searchPerformed(query, 0);
    setSearchOpen(false);
    // Implement search logic here
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <DashboardPage />;
      case 'discover':
        return <DiscoverPage onAppClick={handleAppClick} />;
      case 'arcade':
        return <ArcadePage onAppClick={handleAppClick} />;
      case 'categories':
        return <CategoriesPage onCategoryClick={() => {}} />;
      case 'search':
        return <SearchPage onAppClick={handleAppClick} />;
      case 'updates':
        return <UpdatesPage onAppClick={handleAppClick} />;
      case 'account':
        return <AccountPage />;
      case 'inventory':
        return <InventoryPage />;
      default:
        return <DashboardPage />;
    }
  };

  return (
    <ErrorBoundary>
      <div className="h-screen flex" style={{ background: 'var(--bg-base)' }}>
        <AppSidebar currentPage={currentPage} onPageChange={handlePageChange} />
        
        <div className="flex-1 flex flex-col overflow-hidden">
          {renderPage()}
        </div>

        {/* Modals & Overlays */}
        {selectedApp && (
          <AppDetailModal appId={selectedApp} onClose={() => setSelectedApp(null)} />
        )}

        <SearchModal 
          open={searchOpen} 
          onClose={() => setSearchOpen(false)}
          onSearch={handleSearch}
        />

        {/* Notifications */}
        <NotificationCenter 
          notifications={notifications}
          onDismiss={dismissNotification}
        />

        {/* Toast Notifications */}
        <Toaster 
          position="bottom-right"
          toastOptions={{
            style: {
              background: 'var(--bg-panel)',
              border: '1px solid var(--border-glass)',
              color: 'var(--txt-primary)',
            },
          }}
        />
      </div>
    </ErrorBoundary>
  );
}