import { PageHeader } from '../components/PageHeader';
import { FeaturedHero } from '../components/FeaturedHero';
import { AppRow } from '../components/AppRow';
import { AppCard } from '../components/AppCard';

interface DiscoverPageProps {
  onAppClick: (appId: string) => void;
}

const featuredApps = [
  { id: '1', name: 'Notability', subtitle: 'Take Notes, Markup PDFs', category: 'Productivity', icon: '📝', iconBg: 'linear-gradient(135deg, #F59E0B 0%, #D97706 100%)', rating: 4.7, price: '$14.99' },
  { id: '2', name: 'Procreate', subtitle: 'Creative Art Studio', category: 'Graphics & Design', icon: '🎨', iconBg: 'linear-gradient(135deg, #EC4899 0%, #DB2777 100%)', rating: 4.9, price: '$12.99' },
  { id: '3', name: 'Things 3', subtitle: 'Personal Task Manager', category: 'Productivity', icon: '✓', iconBg: 'linear-gradient(135deg, #3B82F6 0%, #2563EB 100%)', rating: 4.8, price: '$9.99' },
  { id: '4', name: 'Pixelmator Pro', subtitle: 'Professional Image Editor', category: 'Graphics & Design', icon: '🖼️', iconBg: 'linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%)', rating: 4.6, price: '$39.99' },
  { id: '5', name: 'Bear', subtitle: 'Beautiful Writing App', category: 'Productivity', icon: '🐻', iconBg: 'linear-gradient(135deg, #EF4444 0%, #DC2626 100%)', rating: 4.5, price: 'Free' },
];

const newApps = [
  { id: '6', name: 'Raycast', subtitle: 'Supercharged Productivity', category: 'Utilities', icon: '⚡', iconBg: 'linear-gradient(135deg, #F97316 0%, #EA580C 100%)', rating: 4.9, price: 'Free' },
  { id: '7', name: 'CleanMyMac X', subtitle: 'Keep Your Mac Clean', category: 'Utilities', icon: '🧹', iconBg: 'linear-gradient(135deg, #10B981 0%, #059669 100%)', rating: 4.7, price: '$34.95' },
  { id: '8', name: 'Final Cut Pro', subtitle: 'Professional Video Editing', category: 'Photo & Video', icon: '🎬', iconBg: 'linear-gradient(135deg, #6366F1 0%, #4F46E5 100%)', rating: 4.8, price: '$299.99' },
  { id: '9', name: 'Sketch', subtitle: 'Design Tool for Teams', category: 'Graphics & Design', icon: '💎', iconBg: 'linear-gradient(135deg, #F59E0B 0%, #D97706 100%)', rating: 4.6, price: '$99/year' },
  { id: '10', name: 'Alfred', subtitle: 'Award-Winning App Launcher', category: 'Productivity', icon: '🎩', iconBg: 'linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%)', rating: 4.8, price: 'Free' },
];

const topPaidApps = [
  { id: '11', name: 'Logic Pro', subtitle: 'Professional Music Production', category: 'Music', icon: '🎵', iconBg: 'linear-gradient(135deg, #6366F1 0%, #4F46E5 100%)', rating: 4.9, price: '$199.99', rank: 1 },
  { id: '12', name: 'Affinity Designer', subtitle: 'Vector Graphics Editor', category: 'Graphics & Design', icon: '🎨', iconBg: 'linear-gradient(135deg, #3B82F6 0%, #2563EB 100%)', rating: 4.7, price: '$69.99', rank: 2 },
  { id: '13', name: 'Fantastical', subtitle: 'Calendar & Tasks', category: 'Productivity', icon: '📅', iconBg: 'linear-gradient(135deg, #EF4444 0%, #DC2626 100%)', rating: 4.8, price: '$52.99', rank: 3 },
  { id: '14', name: 'Darkroom', subtitle: 'Photo & Video Editor', category: 'Photo & Video', icon: '📷', iconBg: 'linear-gradient(135deg, #1F2937 0%, #111827 100%)', rating: 4.6, price: '$49.99', rank: 4 },
  { id: '15', name: 'PDF Expert', subtitle: 'Read, Edit, Sign PDFs', category: 'Productivity', icon: '📄', iconBg: 'linear-gradient(135deg, #EF4444 0%, #DC2626 100%)', rating: 4.7, price: '$79.99', rank: 5 },
];

export function DiscoverPage({ onAppClick }: DiscoverPageProps) {
  return (
    <>
      <PageHeader title="Discover" showSearch />
      
      <main className="flex-1 overflow-y-auto">
        <div className="px-8 py-6 space-y-10">
          {/* Featured Hero */}
          <FeaturedHero 
            title="App of the Day"
            appName="Notability"
            appSubtitle="Take Notes, Markup PDFs"
            description="The powerful note-taking app trusted by millions. Sketch ideas, annotate documents, and stay organized across all your devices."
            category="Productivity"
            backgroundImage="https://images.unsplash.com/photo-1545296664-39db56ad95bd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9kdWN0aXZpdHklMjBzb2Z0d2FyZXxlbnwxfHx8fDE3NjEzNDMxMjB8MA&ixlib=rb-4.1.0&q=80&w=1080"
            onGetClick={() => onAppClick('1')}
          />

          {/* We Think You'll Like These */}
          <AppRow title="We Think You'll Like These" onSeeAll={() => {}}>
            {featuredApps.map(app => (
              <AppCard key={app.id} {...app} onClick={() => onAppClick(app.id)} />
            ))}
          </AppRow>

          {/* New Apps We Love */}
          <AppRow title="New Apps We Love" subtitle="Discover the latest apps handpicked by our editors" onSeeAll={() => {}}>
            {newApps.map(app => (
              <AppCard key={app.id} {...app} onClick={() => onAppClick(app.id)} />
            ))}
          </AppRow>

          {/* Top Paid Apps */}
          <AppRow title="Top Paid Apps" onSeeAll={() => {}}>
            {topPaidApps.map(app => (
              <AppCard key={app.id} {...app} onClick={() => onAppClick(app.id)} showRank />
            ))}
          </AppRow>
        </div>
      </main>
    </>
  );
}
