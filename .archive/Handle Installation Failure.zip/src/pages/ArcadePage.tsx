import { PageHeader } from '../components/PageHeader';
import { FeaturedHero } from '../components/FeaturedHero';
import { AppRow } from '../components/AppRow';
import { ArcadeCard } from '../components/ArcadeCard';

interface ArcadePageProps {
  onAppClick: (appId: string) => void;
}

const exclusiveGames = [
  { id: 'a1', name: 'Stardew Valley+', subtitle: 'Farm & Friends', category: 'Arcade Exclusive', icon: '🌾', iconBg: 'linear-gradient(135deg, #10B981 0%, #059669 100%)', rating: 4.9 },
  { id: 'a2', name: 'Monument Valley+', subtitle: 'Illusory Adventure', category: 'Arcade Exclusive', icon: '🏛️', iconBg: 'linear-gradient(135deg, #F59E0B 0%, #D97706 100%)', rating: 4.8 },
  { id: 'a3', name: 'Oceanhorn 2', subtitle: 'Knights of the Lost Realm', category: 'Arcade Exclusive', icon: '⚔️', iconBg: 'linear-gradient(135deg, #3B82F6 0%, #2563EB 100%)', rating: 4.7 },
  { id: 'a4', name: 'Crossy Road Castle', subtitle: 'Endless Arcade Action', category: 'Arcade Exclusive', icon: '🏰', iconBg: 'linear-gradient(135deg, #EC4899 0%, #DB2777 100%)', rating: 4.6 },
  { id: 'a5', name: 'Grindstone', subtitle: 'Puzzle Adventure', category: 'Arcade Exclusive', icon: '💎', iconBg: 'linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%)', rating: 4.8 },
];

const newGames = [
  { id: 'a6', name: 'Fantasian', subtitle: 'JRPG Adventure', category: 'Role-Playing', icon: '🎮', iconBg: 'linear-gradient(135deg, #EF4444 0%, #DC2626 100%)', rating: 4.9 },
  { id: 'a7', name: 'NBA 2K24 Arcade', subtitle: 'Basketball', category: 'Sports', icon: '🏀', iconBg: 'linear-gradient(135deg, #F97316 0%, #EA580C 100%)', rating: 4.5 },
  { id: 'a8', name: 'What the Golf?', subtitle: 'The Golf Game for People Who Hate Golf', category: 'Sports', icon: '⛳', iconBg: 'linear-gradient(135deg, #10B981 0%, #059669 100%)', rating: 4.7 },
  { id: 'a9', name: 'SP!NG', subtitle: 'Multiplayer Action', category: 'Action', icon: '🎯', iconBg: 'linear-gradient(135deg, #6366F1 0%, #4F46E5 100%)', rating: 4.4 },
];

const familyGames = [
  { id: 'a10', name: 'Sonic Dream Team', subtitle: 'High-Speed Adventure', category: 'Platformer', icon: '💨', iconBg: 'linear-gradient(135deg, #3B82F6 0%, #2563EB 100%)', rating: 4.8 },
  { id: 'a11', name: 'Disney Dreamlight Valley', subtitle: 'Life-Sim Adventure', category: 'Simulation', icon: '✨', iconBg: 'linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%)', rating: 4.6 },
  { id: 'a12', name: 'Solitaire Stories', subtitle: 'Card Game', category: 'Card', icon: '🃏', iconBg: 'linear-gradient(135deg, #EF4444 0%, #DC2626 100%)', rating: 4.5 },
  { id: 'a13', name: 'Cut the Rope Remastered', subtitle: 'Physics Puzzle', category: 'Puzzle', icon: '🍬', iconBg: 'linear-gradient(135deg, #10B981 0%, #059669 100%)', rating: 4.7 },
];

export function ArcadePage({ onAppClick }: ArcadePageProps) {
  return (
    <>
      <PageHeader 
        title="Arcade" 
        rightContent={
          <button
            className="px-5 py-2 rounded-lg transition-all"
            style={{
              background: 'linear-gradient(135deg, #007AFF 0%, #0051D5 100%)',
              fontSize: '15px',
              fontWeight: 600,
              color: '#FFFFFF',
              boxShadow: '0 2px 8px rgba(0, 122, 255, 0.3)',
            }}
          >
            Try It Free
          </button>
        }
      />
      
      <main className="flex-1 overflow-y-auto">
        <div className="px-8 py-6 space-y-10">
          {/* Featured */}
          <FeaturedHero 
            title="Game of the Week"
            appName="Stardew Valley+"
            appSubtitle="Farm & Friends"
            description="Escape to the countryside with this beloved farming RPG. Build your dream farm, befriend villagers, and discover the secrets of Stardew Valley."
            category="Arcade Exclusive"
            backgroundImage="https://images.unsplash.com/photo-1611138290962-2c550ffd4002?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1pbmclMjBjb250cm9sbGVyfGVufDF8fHx8MTc2MTM0MzEyMXww&ixlib=rb-4.1.0&q=80&w=1080"
            onGetClick={() => onAppClick('a1')}
          />

          {/* Arcade Exclusives */}
          <AppRow title="Arcade Exclusives" subtitle="Award-winning games you can only play here" onSeeAll={() => {}}>
            {exclusiveGames.map(game => (
              <ArcadeCard key={game.id} {...game} onClick={() => onAppClick(game.id)} />
            ))}
          </AppRow>

          {/* New to Arcade */}
          <AppRow title="New to Arcade" onSeeAll={() => {}}>
            {newGames.map(game => (
              <ArcadeCard key={game.id} {...game} onClick={() => onAppClick(game.id)} />
            ))}
          </AppRow>

          {/* Great for Families */}
          <AppRow title="Great for Families" onSeeAll={() => {}}>
            {familyGames.map(game => (
              <ArcadeCard key={game.id} {...game} onClick={() => onAppClick(game.id)} />
            ))}
          </AppRow>
        </div>
      </main>
    </>
  );
}
