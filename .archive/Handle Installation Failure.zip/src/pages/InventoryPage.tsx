import { useState } from 'react';
import { PageHeader } from '../components/PageHeader';
import { FilterBar, FilterOption } from '../components/FilterBar';
import { GameGrid } from '../components/GameGrid';
import { BulkActions } from '../components/BulkActions';
import { Pagination } from '../components/Pagination';
import { Plus } from 'lucide-react';
import { ExportButton } from '../components/ExportButton';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { toast } from 'sonner@2.0.3';

// Mock data
const mockGames = Array.from({ length: 50 }, (_, i) => ({
  id: `game-${i + 1}`,
  title: `Game ${i + 1}`,
  genre: ['Action', 'RPG', 'Horror', 'Puzzle', 'Racing'][i % 5],
  price: `$${(Math.random() * 50 + 10).toFixed(2)}`,
  stock: Math.floor(Math.random() * 100),
  image: `https://images.unsplash.com/photo-${1492515114049 + i}-778a9051fecb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400`,
  platform: ['Mac', 'iOS', 'Cross-platform'][i % 3],
}));

const genreOptions: FilterOption[] = [
  { id: 'action', label: 'Action', value: 'action' },
  { id: 'rpg', label: 'RPG', value: 'rpg' },
  { id: 'horror', label: 'Horror', value: 'horror' },
  { id: 'puzzle', label: 'Puzzle', value: 'puzzle' },
  { id: 'racing', label: 'Racing', value: 'racing' },
];

const platformOptions: FilterOption[] = [
  { id: 'mac', label: 'Mac', value: 'mac' },
  { id: 'ios', label: 'iOS', value: 'ios' },
  { id: 'cross', label: 'Cross-platform', value: 'cross-platform' },
];

const priceRangeOptions: FilterOption[] = [
  { id: 'under20', label: 'Under $20', value: 'under20' },
  { id: '20to40', label: '$20 - $40', value: '20to40' },
  { id: 'over40', label: 'Over $40', value: 'over40' },
];

export function InventoryPage() {
  const [activeFilters, setActiveFilters] = useState<Record<string, string>>({});
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(25);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  const handleFilterChange = (category: string, value: string) => {
    setActiveFilters((prev) => {
      if (value === '') {
        const { [category]: _, ...rest } = prev;
        return rest;
      }
      return { ...prev, [category]: value };
    });
    setCurrentPage(1); // Reset to first page when filters change
  };

  const handleClearFilters = () => {
    setActiveFilters({});
    setCurrentPage(1);
  };

  const handleExport = (format: string) => {
    toast.success(`Exporting data as ${format.toUpperCase()}...`, {
      description: 'Your download will start shortly',
    });
  };

  const handleBulkDelete = () => {
    setShowDeleteDialog(true);
  };

  const confirmDelete = () => {
    toast.success(`Deleted ${selectedItems.length} items`, {
      description: 'The selected items have been removed',
    });
    setSelectedItems([]);
  };

  // Apply filters
  let filteredGames = mockGames;
  if (activeFilters.genre) {
    filteredGames = filteredGames.filter((g) => 
      g.genre.toLowerCase() === activeFilters.genre.toLowerCase()
    );
  }
  if (activeFilters.platform) {
    filteredGames = filteredGames.filter((g) => 
      g.platform.toLowerCase() === activeFilters.platform.toLowerCase()
    );
  }

  // Pagination
  const totalPages = Math.ceil(filteredGames.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedGames = filteredGames.slice(startIndex, startIndex + itemsPerPage);

  return (
    <>
      <PageHeader 
        title="Inventory Management"
        rightContent={
          <div className="flex items-center gap-3">
            <ExportButton onExport={handleExport} />
            <button
              className="flex items-center gap-2 px-4 py-2 rounded-xl transition-all hover:scale-[1.02]"
              style={{
                background: 'linear-gradient(135deg, var(--brand-start), var(--brand-end))',
                boxShadow: 'var(--shadow-glow)',
                color: 'white',
                fontWeight: 600,
              }}
            >
              <Plus size={18} />
              Add Game
            </button>
          </div>
        }
      />

      <main className="flex-1 overflow-y-auto">
        <div className="px-8 py-6 space-y-6">
          {/* Filters */}
          <FilterBar
            filters={{
              genre: genreOptions,
              platform: platformOptions,
              priceRange: priceRangeOptions,
            }}
            activeFilters={activeFilters}
            onFilterChange={handleFilterChange}
            onClearAll={handleClearFilters}
          />

          {/* Games Grid */}
          <GameGrid games={paginatedGames} />

          {/* Pagination */}
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
            itemsPerPage={itemsPerPage}
            totalItems={filteredGames.length}
            onItemsPerPageChange={setItemsPerPage}
          />
        </div>
      </main>

      {/* Bulk Actions */}
      <BulkActions
        selectedCount={selectedItems.length}
        onSelectAll={() => setSelectedItems(paginatedGames.map((g) => g.id))}
        onDeselectAll={() => setSelectedItems([])}
        onDelete={handleBulkDelete}
        onDownload={() => toast.success('Downloading selected items...')}
        onDuplicate={() => toast.success('Duplicating selected items...')}
      />

      {/* Delete Confirmation */}
      <ConfirmDialog
        open={showDeleteDialog}
        onClose={() => setShowDeleteDialog(false)}
        onConfirm={confirmDelete}
        title="Delete Selected Items"
        description={`Are you sure you want to delete ${selectedItems.length} items? This action cannot be undone.`}
        confirmLabel="Delete"
        variant="danger"
      />
    </>
  );
}
