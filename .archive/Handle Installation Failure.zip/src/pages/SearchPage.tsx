import { useState } from 'react';
import { Search, TrendingUp, Clock } from 'lucide-react';
import { AppCard } from '../components/AppCard';

interface SearchPageProps {
  onAppClick: (appId: string) => void;
}

const trendingSearches = [
  'Notion',
  'Photoshop',
  'Final Cut Pro',
  'Xcode',
  'Slack',
  'Zoom',
];

const recentSearches = [
  'video editor',
  'note taking',
  'design tools',
];

const popularApps = [
  { id: 's1', name: 'Notion', subtitle: 'Notes, Docs, Tasks', category: 'Productivity', icon: 'N', iconBg: 'linear-gradient(135deg, #2D3748 0%, #1A202C 100%)', rating: 4.8, price: 'Free' },
  { id: 's2', name: 'Slack', subtitle: 'Team Communication', category: 'Business', icon: '💬', iconBg: 'linear-gradient(135deg, #4A154B 0%, #36113C 100%)', rating: 4.7, price: 'Free' },
  { id: 's3', name: 'Zoom', subtitle: 'Video Meetings', category: 'Business', icon: '📹', iconBg: 'linear-gradient(135deg, #2D8CFF 0%, #2563EB 100%)', rating: 4.5, price: 'Free' },
  { id: 's4', name: 'Adobe Photoshop', subtitle: 'Image Editor', category: 'Graphics & Design', icon: 'Ps', iconBg: 'linear-gradient(135deg, #31A8FF 0%, #0078D4 100%)', rating: 4.9, price: '$20.99/mo' },
];

export function SearchPage({ onAppClick }: SearchPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);

  return (
    <>
      {/* Header */}
      <header className="px-8 pt-6 pb-4" style={{ background: '#1C1C1E' }}>
        <h1 
          className="tracking-tight mb-4"
          style={{
            fontSize: '36px',
            fontWeight: 600,
            color: '#FFFFFF',
            fontFamily: '-apple-system, BlinkMacSystemFont, "SF Pro Display", sans-serif',
          }}
        >
          Search
        </h1>

        {/* Search Input */}
        <div className="relative group">
          <div
            className="flex items-center gap-3 px-5 py-3.5 rounded-2xl transition-all duration-200"
            style={{
              background: searchQuery ? '#007AFF' : 'rgba(255, 255, 255, 0.05)',
              border: searchQuery 
                ? '1px solid rgba(255, 255, 255, 0.2)' 
                : '1px solid rgba(255, 255, 255, 0.08)',
              boxShadow: searchQuery 
                ? '0 8px 24px rgba(0, 122, 255, 0.3)' 
                : '0 2px 8px rgba(0, 0, 0, 0.2)',
            }}
          >
            <Search 
              size={20} 
              style={{ 
                color: searchQuery ? 'rgba(255, 255, 255, 0.9)' : '#007AFF',
                transition: 'color 0.2s ease',
                flexShrink: 0,
              }} 
              strokeWidth={2}
            />
            <input
              type="text"
              placeholder="Apps, games, stories, and more"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setIsSearching(e.target.value.length > 0);
              }}
              className="flex-1 bg-transparent outline-none transition-all duration-200"
              style={{ 
                color: searchQuery ? '#FFFFFF' : '#FFFFFF',
                fontSize: '17px',
                fontFamily: '-apple-system, BlinkMacSystemFont, "SF Pro Display", sans-serif',
              }}
              autoFocus
            />
            <div
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg transition-all duration-200"
              style={{
                background: 'rgba(255, 255, 255, 0.08)',
                border: '1px solid rgba(255, 255, 255, 0.1)',
                opacity: searchQuery ? 0 : 1,
                pointerEvents: searchQuery ? 'none' : 'auto',
              }}
            >
              <kbd
                className="tabular-nums"
                style={{
                  fontSize: '13px',
                  color: '#8E8E93',
                  fontFamily: 'SF Mono, Monaco, monospace',
                }}
              >
                ⌘
              </kbd>
              <kbd
                className="tabular-nums"
                style={{
                  fontSize: '13px',
                  color: '#8E8E93',
                  fontFamily: 'SF Mono, Monaco, monospace',
                }}
              >
                K
              </kbd>
            </div>
          </div>
        </div>

        <div className="mt-4" style={{ height: '1px', background: 'rgba(255, 255, 255, 0.08)' }} />
      </header>
      
      <main className="flex-1 overflow-y-auto px-8 py-6">
        {!isSearching ? (
          <div className="space-y-8">
            {/* Trending Searches */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <TrendingUp size={18} style={{ color: '#007AFF' }} />
                <h2
                  style={{
                    fontSize: '20px',
                    fontWeight: 600,
                    color: '#FFFFFF',
                  }}
                >
                  Trending Searches
                </h2>
              </div>
              <div className="flex flex-wrap gap-2">
                {trendingSearches.map((search, index) => (
                  <button
                    key={index}
                    className="px-4 py-2 rounded-full transition-all hover:bg-white/10"
                    style={{
                      background: 'rgba(255, 255, 255, 0.05)',
                      border: '1px solid rgba(255, 255, 255, 0.1)',
                      fontSize: '14px',
                      color: '#FFFFFF',
                    }}
                    onClick={() => setSearchQuery(search)}
                  >
                    {search}
                  </button>
                ))}
              </div>
            </div>

            {/* Recent Searches */}
            {recentSearches.length > 0 && (
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <Clock size={18} style={{ color: '#8E8E93' }} />
                  <h2
                    style={{
                      fontSize: '20px',
                      fontWeight: 600,
                      color: '#FFFFFF',
                    }}
                  >
                    Recent Searches
                  </h2>
                </div>
                <div className="space-y-2">
                  {recentSearches.map((search, index) => (
                    <button
                      key={index}
                      className="w-full text-left px-4 py-3 rounded-xl transition-all hover:bg-white/5"
                      style={{
                        fontSize: '15px',
                        color: '#FFFFFF',
                      }}
                      onClick={() => setSearchQuery(search)}
                    >
                      {search}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Popular Apps */}
            <div>
              <h2
                className="mb-4"
                style={{
                  fontSize: '20px',
                  fontWeight: 600,
                  color: '#FFFFFF',
                }}
              >
                Popular Apps
              </h2>
              <div className="space-y-4">
                {popularApps.map(app => (
                  <AppCard key={app.id} {...app} onClick={() => onAppClick(app.id)} />
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <p style={{ fontSize: '15px', color: '#8E8E93' }}>
              Searching for "{searchQuery}"...
            </p>
            {/* Search results would go here */}
            <div className="space-y-4">
              {popularApps
                .filter(app => app.name.toLowerCase().includes(searchQuery.toLowerCase()))
                .map(app => (
                  <AppCard key={app.id} {...app} onClick={() => onAppClick(app.id)} />
                ))}
            </div>
          </div>
        )}
      </main>
    </>
  );
}
