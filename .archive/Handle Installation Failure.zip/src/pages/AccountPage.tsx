import { useState } from 'react';
import { AccountHeader } from '../components/AccountHeader';
import { PurchasedApps } from '../components/PurchasedApps';
import { AccountSettingsModal } from '../components/AccountSettingsModal';

export function AccountPage() {
  const [showSettings, setShowSettings] = useState(false);
  const [activeTab, setActiveTab] = useState<'mac' | 'ios'>('mac');

  return (
    <>
      <AccountHeader 
        onOpenSettings={() => setShowSettings(true)}
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />
      
      <main className="flex-1 overflow-y-auto">
        <PurchasedApps />
      </main>

      {showSettings && (
        <AccountSettingsModal onClose={() => setShowSettings(false)} />
      )}
    </>
  );
}
