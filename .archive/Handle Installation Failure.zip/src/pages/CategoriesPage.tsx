import { PageHeader } from '../components/PageHeader';
import { CategoryCard } from '../components/CategoryCard';

interface CategoriesPageProps {
  onCategoryClick: (category: string) => void;
}

const categories = [
  { id: 'productivity', name: 'Productivity', icon: '⚡', iconBg: 'linear-gradient(135deg, #F59E0B 0%, #D97706 100%)', count: 1247 },
  { id: 'graphics', name: 'Graphics & Design', icon: '🎨', iconBg: 'linear-gradient(135deg, #EC4899 0%, #DB2777 100%)', count: 856 },
  { id: 'development', name: 'Developer Tools', icon: '💻', iconBg: 'linear-gradient(135deg, #3B82F6 0%, #2563EB 100%)', count: 642 },
  { id: 'video', name: 'Photo & Video', icon: '📸', iconBg: 'linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%)', count: 923 },
  { id: 'music', name: 'Music', icon: '🎵', iconBg: 'linear-gradient(135deg, #10B981 0%, #059669 100%)', count: 534 },
  { id: 'games', name: 'Games', icon: '🎮', iconBg: 'linear-gradient(135deg, #EF4444 0%, #DC2626 100%)', count: 2134 },
  { id: 'business', name: 'Business', icon: '💼', iconBg: 'linear-gradient(135deg, #6366F1 0%, #4F46E5 100%)', count: 789 },
  { id: 'education', name: 'Education', icon: '📚', iconBg: 'linear-gradient(135deg, #F97316 0%, #EA580C 100%)', count: 1012 },
  { id: 'lifestyle', name: 'Lifestyle', icon: '🌟', iconBg: 'linear-gradient(135deg, #EC4899 0%, #DB2777 100%)', count: 1567 },
  { id: 'utilities', name: 'Utilities', icon: '🔧', iconBg: 'linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%)', count: 945 },
  { id: 'social', name: 'Social Networking', icon: '💬', iconBg: 'linear-gradient(135deg, #3B82F6 0%, #2563EB 100%)', count: 432 },
  { id: 'health', name: 'Health & Fitness', icon: '❤️', iconBg: 'linear-gradient(135deg, #EF4444 0%, #DC2626 100%)', count: 678 },
  { id: 'finance', name: 'Finance', icon: '💰', iconBg: 'linear-gradient(135deg, #10B981 0%, #059669 100%)', count: 523 },
  { id: 'travel', name: 'Travel', icon: '✈️', iconBg: 'linear-gradient(135deg, #3B82F6 0%, #2563EB 100%)', count: 345 },
  { id: 'reference', name: 'Reference', icon: '📖', iconBg: 'linear-gradient(135deg, #F59E0B 0%, #D97706 100%)', count: 234 },
  { id: 'news', name: 'News', icon: '📰', iconBg: 'linear-gradient(135deg, #6366F1 0%, #4F46E5 100%)', count: 412 },
];

export function CategoriesPage({ onCategoryClick }: CategoriesPageProps) {
  return (
    <>
      <PageHeader title="Categories" />
      
      <main className="flex-1 overflow-y-auto">
        <div className="px-8 py-6">
          <div className="grid grid-cols-4 gap-4">
            {categories.map(category => (
              <CategoryCard
                key={category.id}
                {...category}
                onClick={() => onCategoryClick(category.id)}
              />
            ))}
          </div>
        </div>
      </main>
    </>
  );
}
