import { PageHeader } from '../components/PageHeader';
import { QuickStats } from '../components/QuickStats';
import { ActivityFeed, Activity } from '../components/ActivityFeed';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

// Mock data
const revenueData = [
  { month: 'Jan', revenue: 42000 },
  { month: 'Feb', revenue: 45000 },
  { month: 'Mar', revenue: 48000 },
  { month: 'Apr', revenue: 52000 },
  { month: 'May', revenue: 58000 },
  { month: 'Jun', revenue: 62000 },
];

const topGames = [
  { name: 'Cyberpunk 2077', sales: 1250 },
  { name: 'Stardew Valley', sales: 1100 },
  { name: 'Hollow Knight', sales: 950 },
  { name: 'Celeste', sales: 850 },
  { name: 'Hades', sales: 750 },
];

const recentActivities: Activity[] = [
  {
    id: '1',
    type: 'purchase',
    title: 'New game purchase',
    description: 'Cyberpunk 2077 purchased by user @john_doe',
    timestamp: new Date(Date.now() - 1000 * 60 * 5),
  },
  {
    id: '2',
    type: 'download',
    title: 'Game downloaded',
    description: 'Stardew Valley downloaded 50 times today',
    timestamp: new Date(Date.now() - 1000 * 60 * 30),
  },
  {
    id: '3',
    type: 'review',
    title: 'New review received',
    description: 'Hollow Knight received a 5-star review',
    timestamp: new Date(Date.now() - 1000 * 60 * 60),
  },
  {
    id: '4',
    type: 'update',
    title: 'Game updated',
    description: 'Celeste v1.4.0 released with new features',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2),
  },
];

export function DashboardPage() {
  return (
    <>
      <PageHeader 
        title="Dashboard"
        subtitle="Welcome back! Here's what's happening with your store."
      />

      <main className="flex-1 overflow-y-auto">
        <div className="px-8 py-6 space-y-8">
          {/* Quick Stats */}
          <QuickStats
            totalRevenue="$62,450"
            totalSales={5800}
            activeUsers={12450}
            growthRate={18.2}
          />

          {/* Charts Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Revenue Chart */}
            <div
              className="p-6 rounded-2xl"
              style={{
                background: 'var(--bg-panel)',
                border: '1px solid var(--border-glass)',
              }}
              role="region"
              aria-label="Revenue overview chart"
            >
              <h3
                className="mb-6"
                style={{
                  fontSize: 'var(--text-lg)',
                  fontWeight: 'var(--font-weight-semibold)',
                  color: 'var(--txt-primary)',
                }}
              >
                Revenue Overview
              </h3>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={revenueData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border-subtle)" />
                  <XAxis 
                    dataKey="month" 
                    stroke="var(--txt-tertiary)"
                    style={{ fontSize: 'var(--text-xs)' }}
                  />
                  <YAxis 
                    stroke="var(--txt-tertiary)"
                    style={{ fontSize: 'var(--text-xs)' }}
                  />
                  <Tooltip
                    contentStyle={{
                      background: 'var(--bg-panel)',
                      border: '1px solid var(--border-glass)',
                      borderRadius: 'var(--radius-lg)',
                      color: 'var(--txt-primary)',
                      fontSize: 'var(--text-sm)',
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="revenue"
                    stroke="url(#colorGradient)"
                    strokeWidth={3}
                    dot={{ fill: 'var(--color-primary)', r: 4 }}
                  />
                  <defs>
                    <linearGradient id="colorGradient" x1="0" y1="0" x2="1" y2="0">
                      <stop offset="0%" stopColor="var(--brand-start)" />
                      <stop offset="100%" stopColor="var(--brand-end)" />
                    </linearGradient>
                  </defs>
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Top Games Chart */}
            <div
              className="p-6 rounded-2xl"
              style={{
                background: 'var(--bg-panel)',
                border: '1px solid var(--border-glass)',
              }}
              role="region"
              aria-label="Top selling games chart"
            >
              <h3
                className="mb-6"
                style={{
                  fontSize: 'var(--text-lg)',
                  fontWeight: 'var(--font-weight-semibold)',
                  color: 'var(--txt-primary)',
                }}
              >
                Top Selling Games
              </h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={topGames}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border-subtle)" />
                  <XAxis 
                    dataKey="name" 
                    stroke="var(--txt-tertiary)"
                    style={{ fontSize: 'var(--text-xs)' }}
                    angle={-15}
                    textAnchor="end"
                    height={80}
                  />
                  <YAxis 
                    stroke="var(--txt-tertiary)"
                    style={{ fontSize: 'var(--text-xs)' }}
                  />
                  <Tooltip
                    contentStyle={{
                      background: 'var(--bg-panel)',
                      border: '1px solid var(--border-glass)',
                      borderRadius: 'var(--radius-lg)',
                      color: 'var(--txt-primary)',
                      fontSize: 'var(--text-sm)',
                    }}
                  />
                  <Bar dataKey="sales" fill="url(#barGradient)" radius={[8, 8, 0, 0]} />
                  <defs>
                    <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--brand-start)" />
                      <stop offset="100%" stopColor="var(--brand-end)" />
                    </linearGradient>
                  </defs>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Activity Feed */}
          <ActivityFeed activities={recentActivities} />
        </div>
      </main>
    </>
  );
}