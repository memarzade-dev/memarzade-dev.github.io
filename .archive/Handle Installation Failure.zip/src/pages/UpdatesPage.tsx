import { useState } from 'react';
import { PageHeader } from '../components/PageHeader';
import { UpdateCard } from '../components/UpdateCard';

interface UpdatesPageProps {
  onAppClick: (appId: string) => void;
}

const updates = [
  {
    id: 'u1',
    name: 'Xcode',
    subtitle: 'Version 15.2',
    category: 'Developer Tools',
    icon: '🔨',
    iconBg: 'linear-gradient(135deg, #3B82F6 0%, #2563EB 100%)',
    version: '15.2',
    size: '6.2 GB',
    date: 'Today',
    releaseNotes: 'This update includes support for visionOS development, improved Swift performance, and bug fixes.',
  },
  {
    id: 'u2',
    name: 'Final Cut Pro',
    subtitle: 'Version 10.7',
    category: 'Photo & Video',
    icon: '🎬',
    iconBg: 'linear-gradient(135deg, #6366F1 0%, #4F46E5 100%)',
    version: '10.7',
    size: '3.8 GB',
    date: 'Today',
    releaseNotes: 'New AI-powered color grading tools, enhanced timeline performance, and support for spatial video editing.',
  },
  {
    id: 'u3',
    name: 'Logic Pro',
    subtitle: 'Version 11.0',
    category: 'Music',
    icon: '🎵',
    iconBg: 'linear-gradient(135deg, #6366F1 0%, #4F46E5 100%)',
    version: '11.0',
    size: '1.4 GB',
    date: 'Yesterday',
    releaseNotes: 'Major update with new instruments, spatial audio mixing, and improved MIDI editing capabilities.',
  },
  {
    id: 'u4',
    name: 'Affinity Designer',
    subtitle: 'Version 2.3',
    category: 'Graphics & Design',
    icon: '🎨',
    iconBg: 'linear-gradient(135deg, #3B82F6 0%, #2563EB 100%)',
    version: '2.3',
    size: '524 MB',
    date: 'Yesterday',
    releaseNotes: 'Performance improvements and new vector tools for precision design work.',
  },
  {
    id: 'u5',
    name: 'CleanMyMac X',
    subtitle: 'Version 4.14',
    category: 'Utilities',
    icon: '🧹',
    iconBg: 'linear-gradient(135deg, #10B981 0%, #059669 100%)',
    version: '4.14',
    size: '86 MB',
    date: '2 days ago',
    releaseNotes: 'Enhanced malware detection and optimization for macOS Sonoma.',
  },
];

export function UpdatesPage({ onAppClick }: UpdatesPageProps) {
  const [updating, setUpdating] = useState<string[]>([]);

  return (
    <>
      <PageHeader 
        title="Updates" 
        rightContent={
          <button
            className="px-5 py-2 rounded-lg transition-all hover:opacity-80"
            style={{
              background: '#007AFF',
              fontSize: '15px',
              fontWeight: 600,
              color: '#FFFFFF',
            }}
            onClick={() => {
              const updateIds = updates.map(u => u.id);
              setUpdating(updateIds);
            }}
          >
            Update All
          </button>
        }
      />
      
      <main className="flex-1 overflow-y-auto">
        <div className="px-8 py-6">
          {/* Stats */}
          <div className="mb-6 p-4 rounded-xl" style={{ background: 'rgba(255, 255, 255, 0.05)' }}>
            <div className="flex items-center justify-between">
              <div>
                <p style={{ fontSize: '13px', color: '#8E8E93' }}>Available Updates</p>
                <p style={{ fontSize: '28px', fontWeight: 700, color: '#FFFFFF' }}>{updates.length}</p>
              </div>
              <div className="text-right">
                <p style={{ fontSize: '13px', color: '#8E8E93' }}>Total Size</p>
                <p className="tabular-nums" style={{ fontSize: '28px', fontWeight: 700, color: '#FFFFFF' }}>
                  {(updates.reduce((acc, u) => {
                    const size = parseFloat(u.size);
                    return acc + (u.size.includes('GB') ? size : size / 1024);
                  }, 0)).toFixed(1)} GB
                </p>
              </div>
            </div>
          </div>

          {/* Update List */}
          <div className="space-y-4">
            {updates.map(update => (
              <UpdateCard
                key={update.id}
                {...update}
                isUpdating={updating.includes(update.id)}
                onUpdate={() => setUpdating([...updating, update.id])}
                onClick={() => onAppClick(update.id)}
              />
            ))}
          </div>
        </div>
      </main>
    </>
  );
}
