
  # Handle Installation Failure

  This is a code bundle for Handle Installation Failure. The original project is available at https://www.figma.com/design/Xi16hlQkpzifqZwicIFbjt/Handle-Installation-Failure.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  