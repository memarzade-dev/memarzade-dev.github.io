
  # Personal Blog Development

  This is a code bundle for Personal Blog Development. The original project is available at https://www.figma.com/design/jl06K30zh9l0PakfI7FLI4/Personal-Blog-Development.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  