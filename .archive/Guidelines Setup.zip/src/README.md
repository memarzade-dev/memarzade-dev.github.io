# 🗂️ Vaults: A Developer's Free Code License

<div dir="rtl">

یک وبلاگ شخصی و باغ دیجیتال در سطح AWWWARDS برای محتوای تکنیکال عمیق، ساخته شده با React 18 + TypeScript + Tailwind CSS

</div>

## ✨ Features

### 🎨 Design System
- **VaultsDS Design System** - سیستم طراحی سفارشی با Tailwind CSS
- **Dark-First Theme** - تم تاریک با پشتیبانی از حالت روشن
- **RTL/LTR Support** - پشتیبانی کامل از فارسی و انگلیسی
- **Responsive Design** - طراحی واکنشگرا از موبایل تا دسکتاپ
- **WCAG AA Compliant** - دسترسی‌پذیری کامل

### 📝 Content Management
- **Markdown Support** - پشتیبانی کامل از GitHub Flavored Markdown
- **Frontmatter Parsing** - پردازش متادیتای YAML
- **Obsidian Extensions** - Callouts، Internal Links، Embeds
- **Code Highlighting** - Syntax highlighting با Prism.js
- **Mermaid Diagrams** - نمودارهای تعاملی
- **Math Equations** - معادلات ریاضی با KaTeX

### 🔍 Discovery & Navigation
- **Full-Text Search** - جستجوی تمام متن با Fuse.js
- **Category System** - سیستم دسته‌بندی سلسله‌مراتبی
- **Tag Cloud** - ابر برچسب تعاملی
- **Knowledge Graph** - نمودار دانش تعاملی
- **Breadcrumbs** - مسیریابی خرده‌نانی

### 📖 Reading Experience
- **Reading Progress** - نوار پیشرفت مطالعه
- **Table of Contents** - فهرست مطالب خودکار
- **Reading Modes** - حالت‌های مختلف خواندن
- **Related Posts** - پست‌های مرتبط هوشمند
- **Social Sharing** - اشتراک‌گذاری در شبکه‌های اجتماعی

### 👤 User Engagement
- **Bookmarks** - نشانک‌گذاری پست‌ها
- **Reading History** - تاریخچه مطالعه
- **View Counter** - شمارنده بازدید
- **Scroll Position** - ذخیره موقعیت اسکرول

### ⚡ Performance
- **Service Worker** - پشتیبانی آفلاین
- **Lazy Loading** - بارگذاری تنبل تصاویر و کامپوننت‌ها
- **Code Splitting** - تقسیم بندل به چانک‌های کوچک
- **Web Vitals Monitoring** - نظارت بر معیارهای عملکرد

### 🔎 SEO & Analytics
- **Dynamic Meta Tags** - تگ‌های متا پویا
- **Open Graph** - پشتیبانی از Open Graph
- **Twitter Cards** - کارت‌های توییتر
- **JSON-LD Structured Data** - داده‌های ساختاریافته
- **RSS Feed** - فید RSS خودکار
- **Sitemap** - نقشه سایت خودکار
- **Google Analytics** - ردیابی آمار

## 🚀 Quick Start

### پیش‌نیازها

```bash
Node.js >= 18.0.0
npm >= 9.0.0
```

### نصب

```bash
# Clone repository
git clone https://github.com/yourusername/vaults-blog.git
cd vaults-blog

# Install dependencies
npm install

# Copy environment variables
cp .env.example .env

# Start development server
npm run dev
```

### ساخت برای Production

```bash
# Build for production
npm run build

# Preview production build
npm run preview

# Generate RSS and Sitemap
npm run generate-feeds
```

## 📁 Project Structure

```
vaults/
├── App.tsx                           # کامپوننت اصلی
├── styles/globals.css                # VaultsDS Design System
├── src/
│   ├── components/                   # کامپوننت‌های قابل استفاده مجدد
│   ├── pages/                        # صفحات Route
│   ├── layouts/                      # Layout اصلی
│   ├── contexts/                     # React Context (Theme)
│   ├── hooks/                        # Custom Hooks
│   ├── utils/                        # توابع کمکی
│   ├── data/                         # داده‌های نمونه
│   └── types/                        # TypeScript Types
├── posts/                            # فایل‌های Markdown
├── public/                           # فایل‌های استاتیک
├── guidelines/                       # مستندات VaultsDS
└── scripts/                          # اسکریپت‌های Build
```

## 📝 Creating Content

### ایجاد یک پست جدید

1. فایل markdown جدید در `/posts` ایجاد کنید:

```markdown
---
title: عنوان پست
subtitle: زیرعنوان
date: 2025-12-04
category: دسته‌بندی
tags:
  - تگ۱
  - تگ۲
author: نام نویسنده
excerpt: توضیح کوتاه برای SEO
featured: true
draft: false
---

# محتوای پست

محتوای شما اینجا...
```

2. از ویژگی‌های Markdown استفاده کنید:

```markdown
# Heading 1
## Heading 2

**Bold text**
*Italic text*

> [!NOTE]
> این یک callout است

\```typescript
const code = "Syntax highlighted";
\```

$$
E = mc^2
$$

\```mermaid
graph TD
    A --> B
\```
```

### Frontmatter Fields

| فیلد | نوع | الزامی | توضیحات |
|------|-----|--------|---------|
| `title` | string | ✅ | عنوان پست |
| `date` | string | ✅ | تاریخ انتشار (YYYY-MM-DD) |
| `category` | string | ✅ | دسته‌بندی اصلی |
| `tags` | array | ✅ | لیست تگ‌ها |
| `subtitle` | string | ❌ | زیرعنوان |
| `author` | string | ❌ | نام نویسنده |
| `excerpt` | string | ❌ | توضیح کوتاه |
| `coverImage` | string | ❌ | URL تصویر کاور |
| `featured` | boolean | ❌ | نمایش در صفحه اصلی |
| `draft` | boolean | ❌ | پنهان در production |

## 🎨 Design System

### رنگ‌ها

```css
/* Backgrounds */
--color-bg-primary: #0a0e1a
--color-bg-secondary: #111827
--color-bg-tertiary: #1e293b

/* Surfaces */
--color-surface: #1e293b
--color-surface-elevated: #334155

/* Accent Colors */
--color-primary: #3b82f6
--color-secondary: #10b981
```

### تایپوگرافی

- **Headings (LTR)**: Space Grotesk
- **Headings (RTL)**: Vazirmatn
- **Body (LTR)**: Inter
- **Body (RTL)**: Vazirmatn
- **Code**: Roboto Mono

### Spacing Scale

```css
xs: 0.5rem (8px)
sm: 0.75rem (12px)
md: 1rem (16px)
lg: 1.5rem (24px)
xl: 2rem (32px)
2xl: 3rem (48px)
3xl: 4rem (64px)
```

## 🛠️ Technology Stack

- **Framework**: React 18 + TypeScript
- **Build Tool**: Vite
- **Styling**: Tailwind CSS v4.0
- **Routing**: React Router v6
- **Markdown**: Remark + Rehype
- **Search**: Fuse.js
- **Icons**: Lucide React
- **Diagrams**: Mermaid.js
- **Math**: KaTeX
- **Syntax**: Prism.js

## 📊 Performance

- **Lighthouse Score**: 95+
- **First Contentful Paint**: < 1.8s
- **Time to Interactive**: < 3.8s
- **Cumulative Layout Shift**: < 0.1
- **Bundle Size**: ~200KB (gzipped)

## 🔐 Security

- **Content Sanitization**: rehype-sanitize
- **HTTPS Only**: در production
- **CSP Headers**: Content Security Policy
- **No External Scripts**: به جز Analytics

## 🌐 Browser Support

- Chrome/Edge: Last 2 versions
- Firefox: Last 2 versions
- Safari: Last 2 versions
- Mobile Safari: Last 2 versions
- Samsung Internet: Last 2 versions

## 📄 License

MIT License - مشاهده [LICENSE](./LICENSE) برای جزئیات

## 👨‍💻 Author

**Memarzade**
- Website: [vaults.memarzade.dev](https://vaults.memarzade.dev)
- GitHub: [@memarzade](https://github.com/memarzade)

## 🙏 Acknowledgments

- [React](https://react.dev)
- [Vite](https://vitejs.dev)
- [Tailwind CSS](https://tailwindcss.com)
- [TypeScript](https://www.typescriptlang.org)
- [Lucide Icons](https://lucide.dev)

---

<div align="center" dir="rtl">

**ساخته شده با ❤️ در ایران**

</div>
