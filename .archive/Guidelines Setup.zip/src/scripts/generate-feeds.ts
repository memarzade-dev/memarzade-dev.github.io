// Build script to generate RSS feed and sitemap
// Run this during build process: node --loader tsx scripts/generate-feeds.ts

import { writeFileSync } from 'fs';
import { resolve } from 'path';
import { mockPosts } from '../src/data/mockPosts';
import { generateBlogRSS } from '../src/utils/rss';
import { generateBlogSitemap } from '../src/utils/sitemap';

const SITE_URL = 'https://vaults.memarzade.dev';
const OUTPUT_DIR = 'public';

async function generateFeeds() {
  console.log('🔨 Generating RSS feed and sitemap...\n');

  try {
    // Prepare post data
    const posts = mockPosts.map(post => ({
      title: post.title,
      subtitle: post.subtitle,
      excerpt: post.excerpt,
      slug: post.slug,
      date: post.date,
      author: post.author,
      category: post.category,
    }));

    // Extract categories and tags
    const categories = Array.from(new Set(mockPosts.map(post => post.category)));
    const tags = Array.from(new Set(mockPosts.flatMap(post => post.tags)));

    // Generate RSS feed
    console.log('📰 Generating RSS feed...');
    const rssContent = generateBlogRSS(posts, SITE_URL);
    const rssPath = resolve(OUTPUT_DIR, 'rss.xml');
    writeFileSync(rssPath, rssContent, 'utf-8');
    console.log(`✅ RSS feed generated: ${rssPath}`);
    console.log(`   - ${posts.length} posts included\n`);

    // Generate sitemap
    console.log('🗺️  Generating sitemap...');
    const sitemapContent = generateBlogSitemap(
      posts.map(p => ({ slug: p.slug, date: p.date })),
      categories,
      tags,
      SITE_URL
    );
    const sitemapPath = resolve(OUTPUT_DIR, 'sitemap.xml');
    writeFileSync(sitemapPath, sitemapContent, 'utf-8');
    console.log(`✅ Sitemap generated: ${sitemapPath}`);
    
    const urlCount = (sitemapContent.match(/<url>/g) || []).length;
    console.log(`   - ${urlCount} URLs included\n`);

    console.log('🎉 Feed generation complete!\n');
  } catch (error) {
    console.error('❌ Error generating feeds:', error);
    process.exit(1);
  }
}

generateFeeds();
