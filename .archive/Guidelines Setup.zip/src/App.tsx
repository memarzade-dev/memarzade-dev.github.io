import React, { Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from './src/contexts/ThemeContext';
import { LayoutShell } from './src/layouts/LayoutShell';
import { LoadingSpinner } from './src/components/LoadingSpinner';
import './styles/globals.css';

// Lazy load pages - all pages now have default exports
const HomePage = React.lazy(() => import('./src/pages/Home'));
const PostDetailPage = React.lazy(() => import('./src/pages/PostDetail'));
const CategoriesPage = React.lazy(() => import('./src/pages/Categories'));
const CategoryDetailPage = React.lazy(() => import('./src/pages/CategoryDetail'));
const SearchPage = React.lazy(() => import('./src/pages/Search'));
const TagsPage = React.lazy(() => import('./src/pages/Tags'));
const TagDetailPage = React.lazy(() => import('./src/pages/TagDetail'));
const GraphPage = React.lazy(() => import('./src/pages/Graph'));
const BookmarksPage = React.lazy(() => import('./src/pages/Bookmarks'));
const HistoryPage = React.lazy(() => import('./src/pages/History'));

/**
 * Main App Component
 * کامپوننت اصلی اپلیکیشن
 */
function App() {
  return (
    <ThemeProvider>
      <Router>
        <LayoutShell>
          <Suspense fallback={
            <div className="flex items-center justify-center min-h-[60vh]">
              <LoadingSpinner size="lg" />
            </div>
          }>
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/posts/:slug" element={<PostDetailPage />} />
              <Route path="/categories" element={<CategoriesPage />} />
              <Route path="/categories/:slug" element={<CategoryDetailPage />} />
              <Route path="/search" element={<SearchPage />} />
              <Route path="/tags" element={<TagsPage />} />
              <Route path="/tags/:tag" element={<TagDetailPage />} />
              <Route path="/graph" element={<GraphPage />} />
              <Route path="/bookmarks" element={<BookmarksPage />} />
              <Route path="/history" element={<HistoryPage />} />
            </Routes>
          </Suspense>
        </LayoutShell>
      </Router>
    </ThemeProvider>
  );
}

export default App;