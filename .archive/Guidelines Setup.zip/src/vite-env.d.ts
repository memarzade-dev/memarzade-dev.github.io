/// <reference types="vite/client" />

/**
 * Type definitions for Vite environment variables
 * تعریف نوع برای متغیرهای محیطی Vite
 */

interface ImportMetaEnv {
  // Site configuration
  readonly VITE_SITE_URL: string;
  readonly VITE_SITE_TITLE: string;
  readonly VITE_SITE_DESCRIPTION: string;
  readonly VITE_SITE_AUTHOR: string;

  // Analytics
  readonly VITE_GA_TRACKING_ID: string;
  readonly VITE_ENABLE_ANALYTICS: string;

  // Performance
  readonly VITE_ENABLE_PERFORMANCE_MONITORING: string;

  // Service Worker
  readonly VITE_ENABLE_SERVICE_WORKER: string;

  // Feature flags
  readonly VITE_ENABLE_KNOWLEDGE_GRAPH: string;
  readonly VITE_ENABLE_SEARCH: string;
  readonly VITE_ENABLE_BOOKMARKS: string;
  readonly VITE_ENABLE_HISTORY: string;
  readonly VITE_ENABLE_SOCIAL_SHARE: string;

  // Development
  readonly VITE_DEBUG_MODE: string;
  readonly VITE_DEV_PORT: string;

  // Build
  readonly VITE_BASE_URL: string;
  readonly VITE_MINIFY: string;
  readonly VITE_SOURCEMAP: string;

  // Social media
  readonly VITE_TWITTER_URL: string;
  readonly VITE_GITHUB_URL: string;
  readonly VITE_LINKEDIN_URL: string;
  readonly VITE_EMAIL: string;
  readonly VITE_TWITTER_USERNAME: string;

  // Content
  readonly VITE_HOME_POSTS_COUNT: string;
  readonly VITE_RELATED_POSTS_COUNT: string;
  readonly VITE_HISTORY_MAX_ITEMS: string;

  // Search
  readonly VITE_SEARCH_MIN_LENGTH: string;
  readonly VITE_SEARCH_MAX_RESULTS: string;
  readonly VITE_SEARCH_THRESHOLD: string;

  // Cache
  readonly VITE_CACHE_NAME: string;
  readonly VITE_CACHE_DURATION: string;

  // API (future use)
  readonly VITE_API_URL: string;
  readonly VITE_API_KEY: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}

/**
 * Vite glob import types
 * تایپ‌های glob import در Vite
 */
interface ImportMetaGlob {
  (pattern: string, options?: {
    as?: 'raw' | 'url';
    eager?: boolean;
  }): Record<string, () => Promise<unknown>>;
}

interface ImportMeta {
  glob: ImportMetaGlob;
}

/**
 * Module declarations for non-TypeScript files
 * تعریف ماژول‌ها برای فایل‌های غیر TypeScript
 */

// CSS modules
declare module '*.module.css' {
  const classes: { readonly [key: string]: string };
  export default classes;
}

// Images
declare module '*.svg' {
  import React = require('react');
  export const ReactComponent: React.FC<React.SVGProps<SVGSVGElement>>;
  const src: string;
  export default src;
}

declare module '*.png' {
  const src: string;
  export default src;
}

declare module '*.jpg' {
  const src: string;
  export default src;
}

declare module '*.jpeg' {
  const src: string;
  export default src;
}

declare module '*.gif' {
  const src: string;
  export default src;
}

declare module '*.webp' {
  const src: string;
  export default src;
}

declare module '*.ico' {
  const src: string;
  export default src;
}

// Fonts
declare module '*.woff' {
  const src: string;
  export default src;
}

declare module '*.woff2' {
  const src: string;
  export default src;
}

declare module '*.ttf' {
  const src: string;
  export default src;
}

declare module '*.eot' {
  const src: string;
  export default src;
}

// Other
declare module '*.md' {
  const content: string;
  export default content;
}

declare module '*.json' {
  const value: unknown;
  export default value;
}

/**
 * Global type augmentations
 * افزودن تایپ‌های global
 */

// Service Worker
interface Navigator {
  readonly serviceWorker: ServiceWorkerContainer;
}

interface ServiceWorkerContainer {
  readonly ready: Promise<ServiceWorkerRegistration>;
  readonly controller: ServiceWorker | null;
  register(scriptURL: string | URL, options?: RegistrationOptions): Promise<ServiceWorkerRegistration>;
  getRegistration(clientURL?: string | URL): Promise<ServiceWorkerRegistration | undefined>;
  getRegistrations(): Promise<ReadonlyArray<ServiceWorkerRegistration>>;
}

// Web Share API
interface Navigator {
  share?: (data?: ShareData) => Promise<void>;
  canShare?: (data?: ShareData) => boolean;
}

interface ShareData {
  title?: string;
  text?: string;
  url?: string;
}

// Intersection Observer (for older TS versions)
interface IntersectionObserverInit {
  root?: Element | Document | null;
  rootMargin?: string;
  threshold?: number | number[];
}
