# Content Management Guide

This guide explains how to create and manage content in the Vaults blog system.

## Quick Start

### Creating a New Post

1. **Create a markdown file** in the `/posts` directory:
   ```bash
   touch /posts/my-awesome-post.md
   ```

2. **Add frontmatter** at the top of your file:
   ```yaml
   ---
   title: My Awesome Post
   subtitle: A brief subtitle
   date: 2025-12-04
   category: Tutorial
   tags:
     - React
     - TypeScript
     - Guide
   author: Your Name
   excerpt: A brief description for SEO and previews
   coverImage: https://images.unsplash.com/photo-...
   featured: true
   draft: false
   ---
   ```

3. **Write your content** using Markdown below the frontmatter

4. **Build and deploy** your site

## Frontmatter Fields

### Required Fields

| Field | Type | Description |
|-------|------|-------------|
| `title` | string | Post title (used in SEO and navigation) |
| `date` | string | Publication date (YYYY-MM-DD format) |
| `category` | string | Primary category for the post |
| `tags` | array | List of tags for categorization |

### Optional Fields

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `subtitle` | string | - | Subtitle displayed below title |
| `author` | string | "Vaults" | Author name |
| `excerpt` | string | First 150 chars | Brief description for previews |
| `coverImage` | string | - | URL to cover image |
| `featured` | boolean | false | Show on homepage featured section |
| `draft` | boolean | false | Hide from production builds |
| `readingTime` | number | Auto-calculated | Reading time in minutes |
| `relatedPosts` | array | Auto-detected | Slugs of related posts |

## Markdown Features

### Basic Formatting

```markdown
# Heading 1
## Heading 2
### Heading 3

**Bold text**
*Italic text*
~~Strikethrough~~

- Bullet list
- Another item

1. Numbered list
2. Another item

[Link text](https://example.com)
![Image alt](https://example.com/image.jpg)
```

### Code Blocks

Use triple backticks with language identifier:

````markdown
```typescript
const greeting: string = "Hello, World!";
console.log(greeting);
```
````

Supported languages:
- TypeScript/JavaScript
- Python, Rust, Go
- CSS, JSON, Markdown
- Bash, Shell

### Callouts (Obsidian-style)

```markdown
> [!NOTE]
> This is a note callout

> [!TIP]
> This is a helpful tip

> [!WARNING]
> This is a warning

> [!DANGER]
> This is dangerous information

> [!SUCCESS]
> This is a success message

> [!INFO]
> This is informational

> [!EXAMPLE]
> This is an example

> [!QUOTE]
> This is a quote
```

### Math Equations

Inline math: `$E = mc^2$`

Display math:
```markdown
$$
\int_{-\infty}^{\infty} e^{-x^2} dx = \sqrt{\pi}
$$
```

### Mermaid Diagrams

````markdown
```mermaid
graph TD
    A[Start] --> B{Decision}
    B -->|Yes| C[Action 1]
    B -->|No| D[Action 2]
    C --> E[End]
    D --> E
```
````

Supported diagram types:
- Flowcharts (`graph`)
- Sequence diagrams (`sequenceDiagram`)
- Class diagrams (`classDiagram`)
- State diagrams (`stateDiagram`)
- Gantt charts (`gantt`)
- Pie charts (`pie`)

### Tables

```markdown
| Column 1 | Column 2 | Column 3 |
|----------|----------|----------|
| Data 1   | Data 2   | Data 3   |
| Data 4   | Data 5   | Data 6   |
```

### Internal Links

Link to other posts using wiki-style links:

```markdown
[[Other Post Title]]
[[specific-post-slug]]
```

## File Organization

### Directory Structure

```
/posts/
├── getting-started.md
├── tutorials/
│   ├── react-basics.md
│   └── typescript-guide.md
├── guides/
│   ├── performance.md
│   └── security.md
└── reference/
    ├── api-docs.md
    └── glossary.md
```

### Naming Conventions

- Use lowercase with hyphens: `my-post-title.md`
- Be descriptive: `react-hooks-guide.md` not `guide.md`
- Avoid special characters
- Use date prefixes for chronological content: `2025-12-04-post.md`

## Content Guidelines

### SEO Best Practices

1. **Use descriptive titles** (50-60 characters)
2. **Write compelling excerpts** (150-160 characters)
3. **Choose relevant tags** (3-5 tags per post)
4. **Add alt text to images**
5. **Use heading hierarchy** (H1 → H2 → H3)

### Writing Tips

1. **Start with a hook** - Grab attention in the first paragraph
2. **Use subheadings** - Break content into scannable sections
3. **Include code examples** - Show, don't just tell
4. **Add visuals** - Diagrams, screenshots, charts
5. **Link to related content** - Build your knowledge graph
6. **Proofread** - Check for spelling and grammar

### Accessibility

1. **Use semantic HTML** - Let markdown do its job
2. **Provide alt text** - Describe images for screen readers
3. **Use descriptive link text** - Avoid "click here"
4. **Maintain heading hierarchy** - Don't skip levels
5. **Test with screen readers** - Ensure content is accessible

## Build Configuration

### Vite Configuration

The blog uses a Vite plugin to automatically generate RSS and sitemap:

```typescript
// vite.config.ts
import { feedsPlugin } from './vite-plugin-feeds';
import { mockPosts } from './src/data/mockPosts';

export default {
  plugins: [
    feedsPlugin({
      siteUrl: 'https://vaults.memarzade.dev',
      posts: mockPosts.map(post => ({
        title: post.title,
        slug: post.slug,
        date: post.date,
        excerpt: post.excerpt,
        category: post.category,
        author: post.author,
      })),
    }),
  ],
};
```

### Build Commands

```bash
# Development server
npm run dev

# Production build
npm run build

# Preview production build
npm run preview

# Generate RSS and sitemap manually
npm run generate-feeds
```

## Deployment

### GitHub Pages

1. Build the site: `npm run build`
2. Deploy to GitHub Pages: `npm run deploy`

### Manual Deployment

1. Build the site: `npm run build`
2. Upload the `dist/` directory to your hosting provider

### Environment Variables

Create a `.env` file for configuration:

```env
VITE_SITE_URL=https://vaults.memarzade.dev
VITE_GA_TRACKING_ID=G-XXXXXXXXXX
```

## Advanced Features

### Custom Categories

Define category hierarchy in frontmatter:

```yaml
category: Programming/TypeScript
```

### Series Posts

Link posts in a series:

```yaml
series: Advanced TypeScript
seriesOrder: 1
```

### External Resources

Embed external content:

```yaml
resources:
  - title: TypeScript Handbook
    url: https://www.typescriptlang.org/docs/
  - title: React Docs
    url: https://react.dev
```

## Troubleshooting

### Post Not Showing

1. Check frontmatter syntax
2. Ensure `draft: false`
3. Verify date format (YYYY-MM-DD)
4. Rebuild the site

### Images Not Loading

1. Use absolute URLs for external images
2. Check image file paths
3. Verify CORS settings for external domains

### Syntax Highlighting Not Working

1. Verify language identifier is supported
2. Check for proper code fence formatting
3. Ensure Prism.js is loaded

## Resources

- [Markdown Guide](https://www.markdownguide.org/)
- [GitHub Flavored Markdown](https://github.github.com/gfm/)
- [Mermaid Documentation](https://mermaid.js.org/)
- [KaTeX Supported Functions](https://katex.org/docs/supported.html)

## Support

For issues or questions:
- Check documentation in `/guidelines`
- Review examples in `/posts`
- Open an issue on GitHub
