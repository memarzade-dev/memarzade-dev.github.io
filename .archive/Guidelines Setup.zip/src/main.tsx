/**
 * Main Entry Point - نقطه ورود اصلی اپلیکیشن
 * 
 * این فایل React app را mount می‌کند و تمام setup‌های اولیه را انجام می‌دهد
 */

import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './styles/globals.css';

// Import utilities
import { SERVICE_WORKER, PERFORMANCE } from './src/utils/constants';

// Lazy load service worker registration only in production
const registerServiceWorkerInProduction = async () => {
  if (SERVICE_WORKER.enabled && typeof import.meta !== 'undefined' && import.meta.env && import.meta.env.PROD) {
    const { registerServiceWorker } = await import('./src/utils/serviceWorker');
    registerServiceWorker();
  }
};

// Lazy load performance monitoring
const initPerformanceMonitoringIfEnabled = async () => {
  if (PERFORMANCE.enabled) {
    const { initPerformanceMonitoring } = await import('./src/utils/performance');
    initPerformanceMonitoring();
  }
};

/**
 * Initialize app features
 * راه‌اندازی ویژگی‌های اپلیکیشن
 */
window.addEventListener('load', () => {
  // Register service worker
  registerServiceWorkerInProduction();
  
  // Initialize performance monitoring
  initPerformanceMonitoringIfEnabled();
});

/**
 * Mount React app
 * Mount کردن React app به DOM
 */
const rootElement = document.getElementById('root');

if (!rootElement) {
  throw new Error('Root element not found');
}

ReactDOM.createRoot(rootElement).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

/**
 * Hot Module Replacement (HMR) for development
 * بارگذاری مجدد داغ برای محیط development
 */
if (import.meta.hot) {
  import.meta.hot.accept();
}