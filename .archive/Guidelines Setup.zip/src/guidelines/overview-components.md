# Component Catalog Overview

## Layout & Shell

### LayoutShell
**File**: `src/layouts/LayoutShell.tsx`  
**Purpose**: Master layout wrapper with header, sidebar, main content area, and footer  
**Usage**: Wrap all pages in `<LayoutShell>`  
**Features**: Responsive grid, collapsible sidebar, sticky header

### Header
**File**: `src/components/Header.tsx`  
**Purpose**: Global navigation bar  
**Usage**: Rendered by `LayoutShell`  
**Features**: Logo/title, global search, theme toggle (dark/light/system), language toggle, minimal sticky design

### Sidebar
**File**: `src/components/Sidebar.tsx`  
**Purpose**: Nested category tree navigation  
**Usage**: Rendered by `LayoutShell`, collapsible on mobile  
**Features**: Expandable tree, hover states, breadcrumb integration, scroll-to-active

### Footer
**File**: `src/components/Footer.tsx`  
**Purpose**: Site footer with links and credits  
**Usage**: Rendered by `LayoutShell`  
**Features**: Social links, copyright, subtle wave animation, minimal

---

## Content Display

### Hero
**File**: `src/components/Hero.tsx`  
**Purpose**: Immersive landing section for home page  
**Usage**: `<Hero />` on home page only  
**Features**: Parallax background, typewriter effect, gradient text, CTA buttons, floating profile image  
**Never**: Use on post pages or category pages

### PostCard
**File**: `src/components/PostCard.tsx`  
**Purpose**: Card component for listing posts in grids/lists  
**Usage**: `<PostCard post={post} />` in home, category, search results  
**Features**: Thumbnail, title, excerpt, tags, date, reading time, hover micro-interactions  
**Never**: Use for full post content display

### TagChip
**File**: `src/components/TagChip.tsx`  
**Purpose**: Individual tag badge  
**Usage**: `<TagChip tag="ai" />` inside `PostCard`, post headers, tag lists  
**Features**: Clickable, themed colors, hover states

### TagCloud
**File**: `src/components/TagCloud.tsx`  
**Purpose**: Interactive tag cloud visualization  
**Usage**: `<TagCloud tags={allTags} />` on home or dedicated tag page  
**Features**: Size by frequency, click to filter, animated layout

### Breadcrumbs
**File**: `src/components/Breadcrumbs.tsx`  
**Purpose**: Navigation breadcrumb trail  
**Usage**: `<Breadcrumbs path={['AI', 'Machine Learning', 'Neural Nets']} />`  
**Features**: Derived from categories and route segments, clickable links, separator icons

---

## Markdown & Content

### MarkdownRenderer
**File**: `src/components/MarkdownRenderer.tsx`  
**Purpose**: Render full GFM + Obsidian Markdown to React  
**Usage**: `<MarkdownRenderer content={post.body} />`  
**Features**: All features from `overview-markdown.md`, RTL/LTR detection, code highlighting, callouts, mermaid, math, internal links  
**Never**: Use raw `dangerouslySetInnerHTML`

### TOC (Table of Contents)
**File**: `src/components/TOC.tsx`  
**Purpose**: Article table of contents from extracted headings  
**Usage**: `<TOC headings={extractedHeadings} />` in post sidebar  
**Features**: Smooth scroll anchors, active section highlighting, collapsible on mobile

### Callout
**File**: `src/components/Callout.tsx`  
**Purpose**: Styled admonition boxes (note, tip, warning, etc.)  
**Usage**: `<Callout variant="warning" title="Important">Content</Callout>`  
**Features**: Icon, themed colors, collapsible, supports all Obsidian callout types

---

## Interactive & Advanced

### GraphView
**File**: `src/components/GraphView.tsx`  
**Purpose**: Interactive knowledge graph from tags and internal links  
**Usage**: `<GraphView nodes={posts} links={relations} />` on `/graph` page  
**Features**: Drag nodes, zoom, pan, hover tooltips, click to navigate, force-directed layout  
**Library**: `react-force-graph`, `vis-network`, or `react-flow`

### SearchBar / SearchOverlay
**File**: `src/components/SearchBar.tsx`  
**Purpose**: Global fuzzy search input  
**Usage**: Rendered in `Header`, expands to overlay on focus  
**Features**: Fuse.js integration, instant results, keyboard navigation, highlights, recent searches

### ProgressBar
**File**: `src/components/ProgressBar.tsx`  
**Purpose**: Reading progress indicator  
**Usage**: `<ProgressBar />` at top of post pages  
**Features**: Scroll-based progress, smooth animation, theme-aware colors, `aria-live` announcements

### ReadingModeToggle
**File**: `src/components/ReadingModeToggle.tsx`  
**Purpose**: Toggle serif/sans, font size, line height  
**Usage**: `<ReadingModeToggle />` in post header or floating button  
**Features**: Persist to localStorage, apply to `MarkdownRenderer`, accessibility controls

### ShareButtons
**File**: `src/components/ShareButtons.tsx`  
**Purpose**: Social sharing buttons  
**Usage**: `<ShareButtons url={postUrl} title={postTitle} />` sticky on post pages  
**Features**: Twitter, LinkedIn, Telegram, email, copy link, tooltips

---

## Utilities & Feedback

### ErrorBoundary
**File**: `src/components/ErrorBoundary.tsx`  
**Purpose**: Catch React errors and display fallback UI  
**Usage**: Wrap app or routes in `<ErrorBoundary>`  
**Features**: Retry button, friendly error message, stack trace in dev mode

### ErrorPage / NotFound
**File**: `src/pages/ErrorPage.tsx`, `src/pages/NotFound.tsx`  
**Purpose**: Error and 404 pages  
**Usage**: Route to `/404` or error state  
**Features**: Search suggestions, navigation links, small animation, helpful messaging

### LoadingSpinner
**File**: `src/components/LoadingSpinner.tsx`  
**Purpose**: Branded loading animation  
**Usage**: `<LoadingSpinner />` in Suspense fallbacks, lazy-loaded components  
**Features**: Code-themed animation (e.g., spinning brackets or vault icon), theme-aware

---

## Theme & Providers

### ThemeProvider
**File**: `src/contexts/ThemeContext.tsx`  
**Purpose**: Manage dark/light/system theme state  
**Usage**: Wrap app in `<ThemeProvider>`  
**Features**: `prefers-color-scheme` detection, localStorage persistence, toggle function

### RTLProvider (if needed)
**File**: `src/contexts/RTLContext.tsx`  
**Purpose**: Manage global RTL/LTR state (optional, can be per-block)  
**Usage**: Wrap app or use per-component

### SearchProvider
**File**: `src/contexts/SearchContext.tsx`  
**Purpose**: Build and expose Fuse.js search index  
**Usage**: Wrap app in `<SearchProvider>`  
**Features**: Index posts on mount, memoized search function, return typed results

---

## Component Usage Rules

- **Always** read component guideline file before implementing or modifying
- **Always** use design tokens for styling (no hardcoded colors/spacing)
- **Always** ensure components are responsive and accessible
- **Never** break existing component APIs without updating all usages
- **Never** skip lazy-loading for heavy components (graphs, mermaid, large images)
- **Never** forget to memoize expensive computations (search, graph layouts)
