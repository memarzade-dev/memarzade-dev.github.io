# App Overview: Vaults

## Purpose

**Vaults: A Developer's Free Code License** is a personal AWWWARDS-level developer blog and digital garden for **memarzade-dev**, hosting:

- Daily research notes and experiments
- Deep technical articles (code-heavy, text-heavy)
- Nested topic hierarchies (e.g., AI → Machine Learning → Neural Networks)
- Mixed Persian (fa-IR) and English (en-US) content
- Interlinked knowledge graph with tags and internal links

## Target Platform

- **Hosting**: GitHub Pages (static site)
- **Repo**: `memarzade-dev/vaults`
- **Branch**: `gh-pages`
- **URL**: `https://vaults.memarzade.dev`

## Layout Philosophy

- **Immersive, minimalist, dark-first** aesthetic
- **Mobile-first** (320px → ultra-wide monitors)
- **Fluid typography and spacing** that scales naturally
- **Edge-to-edge hero sections**, but comfortable 65ch reading width for articles
- **Sticky header** with search and theme toggle
- **Collapsible sidebar** for nested category tree
- **Graph/tag cloud views** for exploratory browsing

## Core User Flows

1. **Browse by category** → nested tree navigation with breadcrumbs
2. **Search** → global fuzzy search across titles, tags, categories, content
3. **Read post** → immersive article view with TOC, progress bar, reading modes, related posts
4. **Explore graph** → interactive knowledge graph from tags and internal links
5. **Filter by tag** → tag cloud and tag-based post filtering

## SEO & GEO Requirements

- **Meta tags** generated from frontmatter (title, description, author, lang)
- **Open Graph** and **Twitter Cards** for social sharing
- **JSON-LD** structured data for articles and breadcrumbs
- **Sitemap.xml** and **robots.txt** generated from available routes/posts
- **hreflang** tags for multi-language posts
- **Authoritative phrasing** to aid AI citation and GEO ranking

## Accessibility & Performance

- **WCAG AA minimum** contrast ratios
- **Full keyboard navigation** with visible focus states
- **Semantic HTML5** throughout
- **ARIA roles and labels** for dynamic content (graphs, search, progress bars)
- **Lazy-loading** for images, graphs, mermaid diagrams, heavy components
- **Code-splitting** by route with React.Suspense
- **Memoization** for search indices, graph calculations, expensive renders

## Design Mood & Metaphors

- **Visual language**: Vault doors opening to reveal knowledge, branching paths in a garden, code vines, network graphs, digital nature
- **Color palette**: Dark blues and grays with subtle green/blue gradients, high-contrast text
- **Animations**: Subtle parallax on hero, staggered list reveals, spring hover on cards, smooth theme transitions
- **References**: AWWWARDS dark portfolios (2025), immersive typography projects, interactive knowledge graphs
