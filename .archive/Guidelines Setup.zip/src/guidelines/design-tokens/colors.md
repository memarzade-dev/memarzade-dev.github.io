# Color Tokens

## Philosophy

**Dark-first** palette with deep backgrounds, elevated surfaces, and subtle blue/green gradients. High contrast for accessibility (WCAG AA minimum). Inspired by vaults, code editors, and digital gardens at night.

---

## Background Layers

### Base Backgrounds
```css
--color-bg-base: #0a0e1a;           /* Deepest background (body) */
--color-bg-surface: #111827;        /* Primary surface (cards, modals) */
--color-bg-elevated: #1e293b;       /* Elevated elements (dropdowns, tooltips) */
--color-bg-hover: #334155;          /* Hover state for interactive elements */
```

### Light Mode Overrides
```css
--color-bg-base-light: #f8fafc;
--color-bg-surface-light: #ffffff;
--color-bg-elevated-light: #f1f5f9;
--color-bg-hover-light: #e2e8f0;
```

---

## Text Colors

### Dark Mode
```css
--color-text-primary: #f8fafc;      /* Primary text (headings, body) */
--color-text-secondary: #cbd5e1;    /* Secondary text (captions, metadata) */
--color-text-muted: #94a3b8;        /* Muted text (disabled, placeholders) */
--color-text-inverse: #0f172a;      /* Text on light backgrounds */
```

### Light Mode Overrides
```css
--color-text-primary-light: #0f172a;
--color-text-secondary-light: #475569;
--color-text-muted-light: #64748b;
--color-text-inverse-light: #f8fafc;
```

---

## Accent & Brand Colors

### Primary (Blue)
```css
--color-accent-primary: #3b82f6;         /* Primary CTA, links */
--color-accent-primary-hover: #2563eb;   /* Hover state */
--color-accent-primary-dim: #1e3a8a;     /* Backgrounds, subtle highlights */
```

### Secondary (Green)
```css
--color-accent-secondary: #10b981;       /* Success, secondary actions */
--color-accent-secondary-hover: #059669;
--color-accent-secondary-dim: #064e3b;
```

### Gradients
```css
--gradient-primary: linear-gradient(135deg, #3b82f6 0%, #10b981 100%);
--gradient-hero: linear-gradient(180deg, #0a0e1a 0%, #1e293b 100%);
```

---

## Semantic Colors

### Info
```css
--color-info: #3b82f6;
--color-info-bg: rgba(59, 130, 246, 0.1);
--color-info-border: rgba(59, 130, 246, 0.3);
```

### Success
```css
--color-success: #10b981;
--color-success-bg: rgba(16, 185, 129, 0.1);
--color-success-border: rgba(16, 185, 129, 0.3);
```

### Warning
```css
--color-warning: #f59e0b;
--color-warning-bg: rgba(245, 158, 11, 0.1);
--color-warning-border: rgba(245, 158, 11, 0.3);
```

### Danger / Error
```css
--color-danger: #ef4444;
--color-danger-bg: rgba(239, 68, 68, 0.1);
--color-danger-border: rgba(239, 68, 68, 0.3);
```

---

## Borders & Dividers

```css
--color-border-subtle: rgba(255, 255, 255, 0.08);   /* Subtle dividers */
--color-border-default: rgba(255, 255, 255, 0.12);  /* Default borders */
--color-border-emphasis: rgba(255, 255, 255, 0.2);  /* Emphasized borders */
```

### Light Mode Overrides
```css
--color-border-subtle-light: rgba(0, 0, 0, 0.08);
--color-border-default-light: rgba(0, 0, 0, 0.12);
--color-border-emphasis-light: rgba(0, 0, 0, 0.2);
```

---

## Code & Syntax

```css
--color-code-bg: #1e293b;           /* Code block background */
--color-code-text: #e2e8f0;         /* Code text */
--color-code-comment: #64748b;      /* Comments */
--color-code-keyword: #3b82f6;      /* Keywords */
--color-code-string: #10b981;       /* Strings */
--color-code-function: #f59e0b;     /* Functions */
--color-code-number: #8b5cf6;       /* Numbers */
```

---

## Tailwind Config Mapping

In `tailwind.config.ts`, extend the theme with these tokens:

```js
colors: {
  bg: {
    base: 'var(--color-bg-base)',
    surface: 'var(--color-bg-surface)',
    elevated: 'var(--color-bg-elevated)',
    hover: 'var(--color-bg-hover)',
  },
  text: {
    primary: 'var(--color-text-primary)',
    secondary: 'var(--color-text-secondary)',
    muted: 'var(--color-text-muted)',
    inverse: 'var(--color-text-inverse)',
  },
  accent: {
    primary: 'var(--color-accent-primary)',
    'primary-hover': 'var(--color-accent-primary-hover)',
    secondary: 'var(--color-accent-secondary)',
  },
  // ... semantic colors
}
```

---

## Usage Rules

- **Always** use tokens via Tailwind classes or CSS variables
- **Never** hardcode hex colors in components
- **Always** ensure 4.5:1 contrast ratio minimum for text (WCAG AA)
- **Test** both dark and light modes for every component
