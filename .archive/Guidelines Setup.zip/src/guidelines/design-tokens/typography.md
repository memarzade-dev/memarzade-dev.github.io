# Typography Tokens

## Philosophy

Fluid, accessible typography that scales naturally from mobile to desktop. **RTL-aware** with Persian (Vazirmatn) and English (Space Grotesk, Inter, Roboto Mono) font families. **Never use font classes below 14px** except metadata captions (12px minimum).

---

## Font Families

### RTL (Persian/Arabic)
```css
--font-rtl: 'Vazirmatn', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
```

**Import from**: `@memarzade-dev/persian-fonts` or CDN  
**Weights**: 300 (Light), 400 (Regular), 500 (Medium), 600 (SemiBold), 700 (Bold)

### LTR Headings (English UI)
```css
--font-heading: 'Space Grotesk', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
```

**Import from**: Google Fonts or CDN  
**Weights**: 400 (Regular), 500 (Medium), 600 (SemiBold), 700 (Bold)

### LTR Body (English text)
```css
--font-body: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
```

**Import from**: Google Fonts or CDN  
**Weights**: 300 (Light), 400 (Regular), 500 (Medium), 600 (SemiBold), 700 (Bold)

### Code (Monospace, all languages)
```css
--font-code: 'Roboto Mono', 'Fira Code', 'Consolas', 'Monaco', monospace;
```

**Import from**: Google Fonts or CDN  
**Weights**: 400 (Regular), 500 (Medium), 700 (Bold)  
**Features**: Enable font ligatures for code

---

## Type Scale (Fluid)

Use `clamp()` for responsive scaling:

### Display (Hero, Landing)
```css
--font-size-display: clamp(2.5rem, 5vw, 4rem);      /* 40px → 64px */
--line-height-display: 1.1;
--font-weight-display: 700;
```

### Headings
```css
--font-size-h1: clamp(2rem, 4vw, 3rem);             /* 32px → 48px */
--font-size-h2: clamp(1.75rem, 3vw, 2.25rem);       /* 28px → 36px */
--font-size-h3: clamp(1.5rem, 2.5vw, 1.875rem);     /* 24px → 30px */
--font-size-h4: clamp(1.25rem, 2vw, 1.5rem);        /* 20px → 24px */
--font-size-h5: clamp(1.125rem, 1.5vw, 1.25rem);    /* 18px → 20px */
--font-size-h6: clamp(1rem, 1.25vw, 1.125rem);      /* 16px → 18px */

--line-height-heading: 1.3;
--font-weight-heading: 600;
```

### Body Text
```css
--font-size-body: clamp(1rem, 1.5vw, 1.125rem);     /* 16px → 18px */
--line-height-body: 1.7;
--font-weight-body: 400;
```

### Small Text
```css
--font-size-small: clamp(0.875rem, 1.25vw, 1rem);   /* 14px → 16px */
--line-height-small: 1.6;
--font-weight-small: 400;
```

### Metadata / Captions (Minimum 12px)
```css
--font-size-caption: clamp(0.75rem, 1vw, 0.875rem); /* 12px → 14px */
--line-height-caption: 1.5;
--font-weight-caption: 400;
```

### Code
```css
--font-size-code-inline: 0.9em;                     /* Relative to parent */
--font-size-code-block: clamp(0.875rem, 1vw, 1rem); /* 14px → 16px */
--line-height-code: 1.6;
```

---

## RTL/LTR Detection & Application

### Automatic Detection
Use script detection (e.g., `rtl-detect` library or regex) to determine direction per paragraph/block:

```ts
const isRTL = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/.test(text);
const fontFamily = isRTL ? 'var(--font-rtl)' : 'var(--font-body)';
const direction = isRTL ? 'rtl' : 'ltr';
```

### Headings
```tsx
<h1 
  dir={direction} 
  style={{ fontFamily: isRTL ? 'var(--font-rtl)' : 'var(--font-heading)' }}
>
  {title}
</h1>
```

### Mixed Content
Use `<bdi>` for inline mixed-direction text:
```tsx
<p dir="auto">
  This is English, <bdi>این فارسی است</bdi>, back to English.
</p>
```

---

## Tailwind Config Mapping

Extend Tailwind with custom font families and sizes:

```js
fontFamily: {
  rtl: 'var(--font-rtl)',
  heading: 'var(--font-heading)',
  body: 'var(--font-body)',
  code: 'var(--font-code)',
},
fontSize: {
  display: ['var(--font-size-display)', { lineHeight: 'var(--line-height-display)' }],
  h1: ['var(--font-size-h1)', { lineHeight: 'var(--line-height-heading)' }],
  h2: ['var(--font-size-h2)', { lineHeight: 'var(--line-height-heading)' }],
  // ... h3-h6
  body: ['var(--font-size-body)', { lineHeight: 'var(--line-height-body)' }],
  small: ['var(--font-size-small)', { lineHeight: 'var(--line-height-small)' }],
  caption: ['var(--font-size-caption)', { lineHeight: 'var(--line-height-caption)' }],
  'code-inline': 'var(--font-size-code-inline)',
  'code-block': ['var(--font-size-code-block)', { lineHeight: 'var(--line-height-code)' }],
}
```

---

## Reading Mode Adjustments

`ReadingModeToggle` component should allow users to:

1. **Toggle serif/sans**: Apply `font-family: Georgia, serif` for body in reading mode
2. **Adjust font size**: Scale `--font-size-body` by ±10-20%
3. **Adjust line height**: Toggle between `1.7` (default) and `2.0` (relaxed)
4. **Persist to localStorage**

---

## Usage Rules

- **Never** use font sizes below 14px except captions (12px minimum)
- **Always** detect RTL/LTR per block and apply correct font
- **Always** use fluid `clamp()` for responsive scaling
- **Never** mix font families incorrectly (e.g., Space Grotesk for Persian text)
- **Test** readability on mobile (320px) and desktop (1920px+)
- **Respect** `prefers-reduced-motion` for any animated typography effects
