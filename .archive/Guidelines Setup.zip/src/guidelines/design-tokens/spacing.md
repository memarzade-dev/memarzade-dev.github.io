# Spacing Tokens

## Philosophy

Consistent, harmonious spacing scale based on **8px base unit** with fluid scaling for responsive layouts. Supports mobile-first design from 320px to ultra-wide monitors.

---

## Base Unit

```css
--spacing-base: 0.5rem;  /* 8px at default 16px root font size */
```

---

## Spacing Scale

### Fixed Scale (px-based)
```css
--spacing-xs: 0.25rem;   /* 4px - Tight spacing, borders */
--spacing-sm: 0.5rem;    /* 8px - Small gaps, inline elements */
--spacing-md: 1rem;      /* 16px - Default spacing, paragraphs */
--spacing-lg: 1.5rem;    /* 24px - Section spacing, card padding */
--spacing-xl: 2rem;      /* 32px - Large gaps, component spacing */
--spacing-2xl: 3rem;     /* 48px - Major sections */
--spacing-3xl: 4rem;     /* 64px - Hero, page sections */
--spacing-4xl: 6rem;     /* 96px - Extra large gaps */
--spacing-5xl: 8rem;     /* 128px - Page-level spacing */
```

### Fluid Spacing (Responsive)
For sections that need to scale fluidly:

```css
--spacing-section-sm: clamp(2rem, 5vw, 3rem);       /* 32px → 48px */
--spacing-section-md: clamp(3rem, 7vw, 5rem);       /* 48px → 80px */
--spacing-section-lg: clamp(4rem, 10vw, 8rem);      /* 64px → 128px */
```

---

## Container & Layout

### Max Widths
```css
--width-content-narrow: 42rem;    /* 672px - Long-form reading (65ch) */
--width-content: 56rem;           /* 896px - Default content */
--width-content-wide: 72rem;      /* 1152px - Wide content, code blocks */
--width-container: 80rem;         /* 1280px - Max container */
--width-container-full: 90rem;    /* 1440px - Ultra-wide */
```

### Padding & Margins
```css
--padding-page-mobile: 1rem;      /* 16px mobile edge padding */
--padding-page-tablet: 2rem;      /* 32px tablet padding */
--padding-page-desktop: 3rem;     /* 48px desktop padding */

--padding-card: clamp(1rem, 2vw, 1.5rem);          /* Card inner padding */
--padding-button: clamp(0.5rem, 1.5vw, 0.75rem);   /* Button padding */
```

---

## Component-Specific Spacing

### Header
```css
--header-height: 4rem;            /* 64px sticky header */
--header-padding-y: 1rem;
--header-padding-x: clamp(1rem, 3vw, 2rem);
```

### Sidebar
```css
--sidebar-width: 16rem;           /* 256px desktop */
--sidebar-width-collapsed: 4rem;  /* 64px collapsed */
--sidebar-padding: 1rem;
```

### Cards
```css
--card-padding: var(--spacing-lg);
--card-gap: var(--spacing-md);    /* Gap between cards in grid */
```

### Forms
```css
--input-padding-y: 0.5rem;        /* 8px vertical */
--input-padding-x: 0.75rem;       /* 12px horizontal */
--input-gap: 1rem;                /* Gap between form fields */
```

---

## Grid & Flexbox Gaps

```css
--gap-xs: 0.5rem;    /* 8px */
--gap-sm: 1rem;      /* 16px */
--gap-md: 1.5rem;    /* 24px */
--gap-lg: 2rem;      /* 32px */
--gap-xl: 3rem;      /* 48px */
```

**Usage**:
```tsx
<div className="grid gap-md">
  {/* Grid items */}
</div>
```

---

## Tailwind Config Mapping

Extend Tailwind spacing with custom tokens:

```js
spacing: {
  'xs': 'var(--spacing-xs)',
  'sm': 'var(--spacing-sm)',
  'md': 'var(--spacing-md)',
  'lg': 'var(--spacing-lg)',
  'xl': 'var(--spacing-xl)',
  '2xl': 'var(--spacing-2xl)',
  '3xl': 'var(--spacing-3xl)',
  '4xl': 'var(--spacing-4xl)',
  '5xl': 'var(--spacing-5xl)',
  'section-sm': 'var(--spacing-section-sm)',
  'section-md': 'var(--spacing-section-md)',
  'section-lg': 'var(--spacing-section-lg)',
},
maxWidth: {
  'content-narrow': 'var(--width-content-narrow)',
  'content': 'var(--width-content)',
  'content-wide': 'var(--width-content-wide)',
  'container': 'var(--width-container)',
  'container-full': 'var(--width-container-full)',
},
gap: {
  'xs': 'var(--gap-xs)',
  'sm': 'var(--gap-sm)',
  'md': 'var(--gap-md)',
  'lg': 'var(--gap-lg)',
  'xl': 'var(--gap-xl)',
}
```

---

## Responsive Breakpoints

Align spacing with breakpoints:

```js
screens: {
  'sm': '640px',   // Mobile landscape
  'md': '768px',   // Tablet
  'lg': '1024px',  // Desktop
  'xl': '1280px',  // Large desktop
  '2xl': '1536px', // Ultra-wide
}
```

**Adaptive Spacing Example**:
```tsx
<section className="py-section-sm md:py-section-md lg:py-section-lg">
  {/* Content scales padding with screen size */}
</section>
```

---

## Usage Rules

- **Always** use spacing tokens instead of arbitrary values
- **Use** fluid spacing (`clamp()`) for major sections and hero areas
- **Use** fixed spacing for UI components and small gaps
- **Never** use spacing below `4px` except for borders (1-2px)
- **Test** layouts on mobile (320px), tablet (768px), desktop (1280px), ultra-wide (1920px+)
- **Maintain** vertical rhythm with consistent multiples of base unit (8px)
