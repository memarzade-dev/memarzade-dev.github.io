# Border Radius & Shadow Tokens

## Philosophy

Subtle, modern radius and shadow system that creates depth without overwhelming the minimal aesthetic. Shadows respect dark/light modes with appropriate opacity.

---

## Border Radius Scale

```css
--radius-none: 0;
--radius-sm: 0.25rem;      /* 4px - Buttons, small chips */
--radius-md: 0.5rem;       /* 8px - Cards, inputs, default */
--radius-lg: 0.75rem;      /* 12px - Large cards, modals */
--radius-xl: 1rem;         /* 16px - Hero sections, images */
--radius-2xl: 1.5rem;      /* 24px - Feature cards */
--radius-full: 9999px;     /* Fully rounded (pills, avatars) */
```

### Component-Specific
```css
--radius-card: var(--radius-lg);
--radius-button: var(--radius-md);
--radius-input: var(--radius-md);
--radius-tooltip: var(--radius-sm);
--radius-modal: var(--radius-xl);
```

---

## Shadow Scale (Dark Mode)

### Elevation Layers
```css
/* Level 1 - Subtle elevation (cards on surface) */
--shadow-sm: 
  0 1px 2px 0 rgba(0, 0, 0, 0.3),
  0 1px 3px 0 rgba(0, 0, 0, 0.2);

/* Level 2 - Default elevation (cards, dropdowns) */
--shadow-md: 
  0 4px 6px -1px rgba(0, 0, 0, 0.4),
  0 2px 4px -1px rgba(0, 0, 0, 0.3);

/* Level 3 - Raised (modals, popovers) */
--shadow-lg: 
  0 10px 15px -3px rgba(0, 0, 0, 0.5),
  0 4px 6px -2px rgba(0, 0, 0, 0.4);

/* Level 4 - Floating (tooltips, floating buttons) */
--shadow-xl: 
  0 20px 25px -5px rgba(0, 0, 0, 0.6),
  0 10px 10px -5px rgba(0, 0, 0, 0.5);

/* Level 5 - Maximum depth (important modals) */
--shadow-2xl: 
  0 25px 50px -12px rgba(0, 0, 0, 0.7);
```

### Special Shadows
```css
/* Glow effect for focus states */
--shadow-glow-primary: 
  0 0 0 3px rgba(59, 130, 246, 0.3);

--shadow-glow-secondary: 
  0 0 0 3px rgba(16, 185, 129, 0.3);

/* Inner shadow for inputs */
--shadow-inset: 
  inset 0 2px 4px 0 rgba(0, 0, 0, 0.2);
```

---

## Shadow Scale (Light Mode)

Override with lighter shadows for light mode:

```css
--shadow-sm-light: 
  0 1px 2px 0 rgba(0, 0, 0, 0.05),
  0 1px 3px 0 rgba(0, 0, 0, 0.08);

--shadow-md-light: 
  0 4px 6px -1px rgba(0, 0, 0, 0.1),
  0 2px 4px -1px rgba(0, 0, 0, 0.06);

--shadow-lg-light: 
  0 10px 15px -3px rgba(0, 0, 0, 0.12),
  0 4px 6px -2px rgba(0, 0, 0, 0.08);

--shadow-xl-light: 
  0 20px 25px -5px rgba(0, 0, 0, 0.15),
  0 10px 10px -5px rgba(0, 0, 0, 0.1);

--shadow-2xl-light: 
  0 25px 50px -12px rgba(0, 0, 0, 0.2);
```

---

## Hover & Interaction Shadows

For cards and interactive elements:

```css
--shadow-hover: 
  0 12px 24px -6px rgba(59, 130, 246, 0.2),
  0 6px 12px -3px rgba(59, 130, 246, 0.15);

--shadow-card-hover: 
  0 20px 25px -5px rgba(0, 0, 0, 0.6),
  0 10px 10px -5px rgba(0, 0, 0, 0.5);
```

**Usage**: Transition from `shadow-md` to `shadow-hover` on hover

---

## Tailwind Config Mapping

Extend Tailwind with custom shadows and radii:

```js
borderRadius: {
  'none': 'var(--radius-none)',
  'sm': 'var(--radius-sm)',
  'md': 'var(--radius-md)',
  'lg': 'var(--radius-lg)',
  'xl': 'var(--radius-xl)',
  '2xl': 'var(--radius-2xl)',
  'full': 'var(--radius-full)',
  'card': 'var(--radius-card)',
  'button': 'var(--radius-button)',
},
boxShadow: {
  'sm': 'var(--shadow-sm)',
  'md': 'var(--shadow-md)',
  'lg': 'var(--shadow-lg)',
  'xl': 'var(--shadow-xl)',
  '2xl': 'var(--shadow-2xl)',
  'glow-primary': 'var(--shadow-glow-primary)',
  'glow-secondary': 'var(--shadow-glow-secondary)',
  'inset': 'var(--shadow-inset)',
  'hover': 'var(--shadow-hover)',
  'card-hover': 'var(--shadow-card-hover)',
}
```

---

## Component Examples

### Card with Hover Effect
```tsx
<div className="
  rounded-card 
  shadow-md 
  hover:shadow-card-hover 
  transition-shadow 
  duration-300
">
  {/* Card content */}
</div>
```

### Focus State
```tsx
<button className="
  rounded-button 
  focus:outline-none 
  focus:shadow-glow-primary
">
  {/* Button content */}
</button>
```

### Modal
```tsx
<div className="
  rounded-modal 
  shadow-2xl 
  bg-bg-elevated
">
  {/* Modal content */}
</div>
```

---

## Usage Rules

- **Always** use token-based shadows, never inline shadow values
- **Always** transition shadows smoothly (300ms duration)
- **Use** lighter shadows in light mode (auto-switch via theme)
- **Never** stack too many shadow layers (causes performance issues)
- **Use** `shadow-glow` only for focus states, not hover
- **Test** shadow visibility on both dark and light backgrounds
- **Respect** `prefers-reduced-motion` by disabling shadow transitions if needed
