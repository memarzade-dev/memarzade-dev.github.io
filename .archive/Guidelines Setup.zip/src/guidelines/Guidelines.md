# VaultsDS – Digital Garden Blog System

## Core Directive

This design system governs **Vaults: A Developer's Free Code License** — an AWWWARDS-level personal blog and digital garden for deep technical content, built with React + TypeScript + Tailwind CSS for GitHub Pages.

---

## Mandatory Reading Order

Before writing or modifying any code in `src/`, you **must** read files in this exact sequence:

### 1. Overview Files (ALWAYS READ FIRST)
- `guidelines/overview-app.md`
- `guidelines/overview-markdown.md`
- `guidelines/overview-components.md`

### 2. Design Token Files (ALWAYS READ SECOND)
- `guidelines/design-tokens/colors.md`
- `guidelines/design-tokens/typography.md`
- `guidelines/design-tokens/spacing.md`
- `guidelines/design-tokens/radii-shadows.md`

### 3. Component Guidelines (READ BEFORE USING EACH COMPONENT)
Before implementing or modifying any component, read its corresponding guideline:

- **Layout & Shell**: `guidelines/components/layout-shell.md`
- **Header**: `guidelines/components/header.md`
- **Sidebar**: `guidelines/components/sidebar.md`
- **Post Card**: `guidelines/components/post-card.md`
- **Markdown Renderer**: `guidelines/components/markdown-renderer.md`
- **Buttons & Links**: `guidelines/components/buttons-links.md`
- **Graphs & Mindmaps**: `guidelines/components/graphs-mindmaps.md`
- **Callouts & Admonitions**: `guidelines/components/callouts-admonitions.md`

---

## DOs

- **Always** use design tokens from `design-tokens/` files — never hardcode colors, spacing, or typography
- **Always** detect RTL/LTR at block level and apply appropriate fonts (Vazirmatn for Persian, Space Grotesk for English UI, Roboto Mono for code)
- **Always** implement dark-first with smooth transitions between dark/light/system themes
- **Always** ensure WCAG AA contrast ratios minimum
- **Always** implement mobile-first responsive design, fluid from 320px to ultra-wide
- **Always** use semantic HTML5 elements (header, nav, main, aside, article, section, footer)
- **Always** provide keyboard navigation and visible focus states
- **Always** lazy-load heavy components (graphs, mermaid diagrams, large images)
- **Always** generate SEO meta tags from frontmatter (title, description, OG, Twitter cards, JSON-LD)
- **Always** sanitize Markdown with rehype-sanitize — never use raw dangerouslySetInnerHTML
- **Always** support full GitHub Flavored Markdown + Obsidian extensions (callouts, internal links, mermaid, math, embeds)

## DON'Ts

- **Never** use font sizes below 14px except for metadata captions (12px minimum)
- **Never** use hardcoded colors — always reference CSS variables or Tailwind tokens
- **Never** break RTL/LTR text direction or mix fonts incorrectly
- **Never** skip accessibility attributes (alt text, aria-labels, roles, landmarks)
- **Never** implement animations that ignore `prefers-reduced-motion`
- **Never** create components without reading their guideline file first
- **Never** modify design token files without updating all affected components
- **Never** use tiny contrast ratios or inaccessible color combinations
- **Never** implement search, graphs, or heavy features without lazy-loading and memoization
- **Never** forget to add breadcrumbs for nested category navigation

---

## Theme & Visual Identity

- **Mood**: Dark, minimal, experimental, AWWWARDS-inspired, digital garden, graph-driven
- **Palette**: Deep backgrounds (`#0a0e1a`, `#111827`), elevated surfaces, subtle blue/green gradients, high-contrast text
- **Typography**: Vazirmatn (RTL), Space Grotesk (LTR headings), Inter/system (LTR body), Roboto Mono (code)
- **Motion**: Subtle parallax, staggered list reveals, spring hover effects, smooth theme transitions
- **Metaphors**: Vault doors, branching paths, code vines, knowledge graphs, network nodes

---

## Workflow Enforcement

1. Read all overview files
2. Read all design token files
3. Plan component structure and layout
4. Read per-component guideline before coding
5. Implement with strict adherence to tokens and guidelines
6. Test responsiveness, accessibility, RTL/LTR, and dark/light modes
7. Optimize and lazy-load
