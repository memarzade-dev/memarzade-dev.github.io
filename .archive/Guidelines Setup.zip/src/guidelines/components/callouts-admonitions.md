# Callouts & Admonitions Component Guidelines

## Purpose

Styled callout/admonition boxes for Obsidian-style Markdown callouts: `> [!type] Title`.

---

## When to Use

- **Inside MarkdownRenderer**: Auto-parsed from Markdown
- **Manual usage**: Custom callouts in React components
- **Documentation**: Highlight important notes, warnings, tips

---

## Supported Types

### Note (Blue)
```markdown
> [!note] Title
> Default informational callout
```
- Icon: Info circle
- Color: `var(--color-info)`
- Use for: General information, explanations

### Tip (Green)
```markdown
> [!tip] Pro Tip
> Helpful suggestion or best practice
```
- Icon: Lightbulb
- Color: `var(--color-success)`
- Use for: Tips, best practices, suggestions

### Warning (Orange)
```markdown
> [!warning] Caution
> Something to be careful about
```
- Icon: Alert triangle
- Color: `var(--color-warning)`
- Use for: Warnings, cautions, potential issues

### Danger (Red)
```markdown
> [!danger] Critical
> Something dangerous or destructive
```
- Icon: Alert octagon
- Color: `var(--color-danger)`
- Use for: Errors, critical warnings, destructive actions

### Info (Blue, lighter)
```markdown
> [!info] Information
> Additional context or details
```
- Icon: Info
- Color: `var(--color-info)`
- Use for: Supplementary information

### Quote (Gray)
```markdown
> [!quote] Citation
> A quotation from a source
```
- Icon: Quote marks
- Color: Muted gray
- Use for: Quotes, citations

### Example (Purple)
```markdown
> [!example] Example
> A code or concept example
```
- Icon: Code brackets
- Color: Purple accent
- Use for: Examples, demonstrations

### Question (Cyan)
```markdown
> [!question] Question
> A question or discussion point
```
- Icon: Question mark
- Color: Cyan
- Use for: Questions, discussion prompts

### Success (Green)
```markdown
> [!success] Success
> Positive outcome or achievement
```
- Icon: Check circle
- Color: `var(--color-success)`
- Use for: Success messages, completed tasks

### Failure (Red)
```markdown
> [!failure] Error
> Something that failed
```
- Icon: X circle
- Color: `var(--color-danger)`
- Use for: Errors, failures

### Bug (Red/Orange)
```markdown
> [!bug] Known Issue
> A bug or known issue
```
- Icon: Bug
- Color: Orange/Red
- Use for: Bug reports, known issues

---

## Component Structure

```tsx
<div className={`callout callout-${variant}`}>
  <div className="callout-header">
    <Icon name={getIcon(variant)} />
    {title && <span className="callout-title">{title}</span>}
    {collapsible && <CollapseButton />}
  </div>
  
  <div className="callout-content">
    {children}
  </div>
</div>
```

---

## Props

```tsx
interface CalloutProps {
  variant: 'note' | 'tip' | 'warning' | 'danger' | 'info' | 'quote' | 
           'example' | 'question' | 'success' | 'failure' | 'bug';
  title?: string;
  collapsible?: boolean;
  defaultCollapsed?: boolean;
  icon?: React.ReactNode; // Custom icon override
  className?: string;
  children: React.ReactNode;
}
```

---

## Styling

### Layout
- **Border-left**: 4px solid, variant color
- **Background**: `rgba(variant-color, 0.1)`
- **Border-radius**: `var(--radius-md)`
- **Padding**: `var(--spacing-md)`
- **Margin**: `var(--spacing-lg)` vertical

### Header
- **Display**: Flex row, align center
- **Icon**: 20px, variant color
- **Title**: Font `var(--font-heading)`, weight 600, variant color
- **Gap**: `var(--spacing-sm)`

### Content
- **Padding-top**: `var(--spacing-sm)`
- **Color**: `var(--color-text-primary)`
- **Font**: `var(--font-body)`

### Collapsible
- Smooth transition (300ms)
- Chevron icon rotates when expanded
- Content slides in/out

---

## Color Mapping

```css
.callout-note {
  --callout-color: var(--color-info);
  --callout-bg: rgba(59, 130, 246, 0.1);
  --callout-border: var(--color-info);
}

.callout-tip {
  --callout-color: var(--color-success);
  --callout-bg: rgba(16, 185, 129, 0.1);
  --callout-border: var(--color-success);
}

.callout-warning {
  --callout-color: var(--color-warning);
  --callout-bg: rgba(245, 158, 11, 0.1);
  --callout-border: var(--color-warning);
}

.callout-danger {
  --callout-color: var(--color-danger);
  --callout-bg: rgba(239, 68, 68, 0.1);
  --callout-border: var(--color-danger);
}

/* ... other variants */
```

---

## Icon Mapping

Use `lucide-react` icons:

```tsx
const iconMap = {
  note: 'Info',
  tip: 'Lightbulb',
  warning: 'AlertTriangle',
  danger: 'AlertOctagon',
  info: 'Info',
  quote: 'Quote',
  example: 'Code',
  question: 'HelpCircle',
  success: 'CheckCircle',
  failure: 'XCircle',
  bug: 'Bug',
};
```

---

## Markdown Parsing

In `MarkdownRenderer`, detect and parse callouts:

```tsx
function parseCallout(blockquoteChildren: ReactNode): CalloutProps | null {
  // Extract first paragraph text
  const firstPara = extractFirstParagraph(blockquoteChildren);
  
  // Match pattern: [!type] Title
  const match = firstPara.match(/^\[!(\w+)\]\s*(.*)$/);
  if (!match) return null;
  
  const [, variant, title] = match;
  
  // Remove first paragraph from children
  const content = removeFirstParagraph(blockquoteChildren);
  
  return {
    variant: variant.toLowerCase() as CalloutVariant,
    title: title || undefined,
    children: content,
  };
}

// In custom blockquote component:
function Blockquote({ children }) {
  const callout = parseCallout(children);
  
  if (callout) {
    return <Callout {...callout} />;
  }
  
  return <blockquote>{children}</blockquote>;
}
```

---

## Collapsible Behavior

```tsx
function Callout({ variant, title, collapsible, defaultCollapsed, children }) {
  const [isOpen, setIsOpen] = useState(!defaultCollapsed);
  
  return (
    <div className={`callout callout-${variant}`}>
      <div 
        className="callout-header"
        onClick={collapsible ? () => setIsOpen(!isOpen) : undefined}
        style={{ cursor: collapsible ? 'pointer' : 'default' }}
      >
        <Icon name={iconMap[variant]} />
        {title && <span>{title}</span>}
        {collapsible && (
          <ChevronIcon 
            className="callout-chevron"
            style={{ transform: isOpen ? 'rotate(180deg)' : 'rotate(0)' }}
          />
        )}
      </div>
      
      {isOpen && (
        <div className="callout-content">
          {children}
        </div>
      )}
    </div>
  );
}
```

---

## Accessibility

- **Semantic HTML**: `<aside>` wrapper with `role="note"`
- **ARIA**: 
  - `aria-label="{variant} callout"`
  - If collapsible: `aria-expanded={isOpen}`
- **Keyboard**: 
  - If collapsible, `Enter`/`Space` to toggle
  - Tab to focus, visible outline
- **Screen reader**: Announce callout type and title

---

## Example Usage

### Manual (React)
```tsx
<Callout variant="warning" title="Important Notice">
  Make sure to backup your data before proceeding.
</Callout>
```

### Markdown (Auto-parsed)
```markdown
> [!tip] Performance Tip
> Use memoization to prevent unnecessary re-renders.
```

---

## DON'Ts

- **Never** use more than 2-3 callouts per article (overwhelming)
- **Never** use danger callout for non-critical issues
- **Never** nest callouts (visual confusion)
- **Never** use low-contrast colors (accessibility)
- **Never** make collapsible callouts without keyboard support
- **Never** forget icons (they provide quick visual identification)
