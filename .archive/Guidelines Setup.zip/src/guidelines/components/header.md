# Header Component

## Purpose

Global navigation bar with logo, search, theme toggle, and optional language toggle. Sticky at top of viewport.

---

## When to Use

- Rendered automatically by `LayoutShell`
- Always visible on all pages
- Contains global actions (search, theme, language)

---

## Structure

```tsx
<header className="header">
  <div className="header-left">
    <Logo />
    <SidebarToggle /> {/* Mobile only */}
  </div>
  
  <div className="header-center">
    <SearchBar />
  </div>
  
  <div className="header-right">
    <ThemeToggle />
    <LanguageToggle /> {/* Optional */}
  </div>
</header>
```

---

## Features

### Logo / Title
- Displays site title: "Vaults: A Developer's Free Code License"
- Clickable, links to home `/`
- Gradient text effect using `--gradient-primary`
- Font: `var(--font-heading)` for LTR, `var(--font-rtl)` for RTL

### Search Bar
- Global fuzzy search (Fuse.js)
- Expands to overlay on focus (mobile)
- Keyboard shortcut: `Cmd/Ctrl + K`
- Shows recent searches and instant results

### Theme Toggle
- Cycles: Dark → Light → System
- Icon changes: Moon → Sun → Auto
- Persists to localStorage
- Smooth transition (300ms)

### Language Toggle (Optional)
- Toggles between `fa-IR` and `en-US`
- Icon: Flag or language code
- Persists to localStorage

---

## Props

```tsx
interface HeaderProps {
  className?: string;
  showSearch?: boolean; // Default: true
  showThemeToggle?: boolean; // Default: true
  showLanguageToggle?: boolean; // Default: true
}
```

---

## Styling

- **Height**: `var(--header-height)` (64px)
- **Background**: `var(--color-bg-surface)` with backdrop blur
- **Border**: Bottom border `var(--color-border-subtle)`
- **Position**: `sticky`, `top: 0`, `z-index: 50`
- **Padding**: `var(--header-padding-y)` `var(--header-padding-x)`

### Responsive Behavior
- **Mobile**: Logo + Sidebar toggle + Theme toggle (search in dropdown)
- **Tablet**: Logo + Search + Theme toggle
- **Desktop**: Full layout with all elements

---

## UX Rules

- **Always visible** (sticky)
- **Minimal height** (64px) to maximize content space
- **Search focus** should not obscure content (use overlay or dropdown)
- **Theme toggle** should provide immediate visual feedback
- **Keyboard accessible** (Tab navigation, Enter to activate)

---

## Accessibility

- **Role**: `<header>` with `role="banner"`
- **Skip link**: Hidden "Skip to content" link for screen readers
- **Focus states**: Visible outline on all interactive elements
- **ARIA labels**: 
  - `aria-label="Search"` for search input
  - `aria-label="Toggle theme"` for theme button
  - `aria-label="Toggle language"` for language button
- **Keyboard shortcuts**: Announce `Cmd+K` for search in tooltip

---

## Example

```tsx
<Header 
  showSearch={true}
  showThemeToggle={true}
  showLanguageToggle={true}
/>
```

---

## DON'Ts

- **Never** make header non-sticky (loses global navigation)
- **Never** exceed 64px height (wastes vertical space)
- **Never** use low-contrast colors (must be readable on all backgrounds)
- **Never** hide search on desktop (primary discovery mechanism)
- **Never** forget to blur backdrop (creates depth)
