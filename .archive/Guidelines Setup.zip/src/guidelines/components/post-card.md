# PostCard Component

## Purpose

Card component for displaying post previews in lists, grids, search results, and category pages.

---

## When to Use

- **Home page**: Featured posts, recent posts
- **Category pages**: List of posts in category
- **Search results**: Matching posts
- **Related posts**: At bottom of article

### When NOT to Use

- **Never** use for full post content display (use `MarkdownRenderer` in post page)
- **Never** use in sidebar or header (too large)

---

## Structure

```tsx
<article className="post-card">
  {coverImage && <PostCardImage src={coverImage} alt={coverAlt} />}
  
  <div className="post-card-content">
    <PostCardMeta date={date} readingTime={readingTime} lang={lang} />
    
    <h3 className="post-card-title">
      <Link to={url}>{title}</Link>
    </h3>
    
    {subtitle && <p className="post-card-subtitle">{subtitle}</p>}
    
    {excerpt && <p className="post-card-excerpt">{excerpt}</p>}
    
    <PostCardTags tags={tags} />
  </div>
  
  {featured && <FeaturedBadge />}
</article>
```

---

## Features

### Cover Image (Optional)
- Aspect ratio: 16:9 or 2:1
- Lazy-loaded with `loading="lazy"`
- Hover: Subtle zoom effect (scale 1.05)
- Gradient overlay for readability

### Metadata
- Date (relative: "2 days ago" or absolute: "Dec 4, 2025")
- Reading time estimate (e.g., "5 min read")
- Language indicator (flag icon for `fa-IR` / `en-US`)

### Title
- Font: `var(--font-heading)` (LTR) or `var(--font-rtl)` (RTL)
- Size: `var(--font-size-h3)` → `var(--font-size-h4)` responsive
- Line clamp: 2 lines max (with ellipsis)
- Hover: Gradient text effect

### Subtitle (Optional)
- Smaller, muted text
- Line clamp: 1 line

### Excerpt (Optional)
- First 150-200 characters of post
- Line clamp: 3 lines
- Color: `var(--color-text-secondary)`

### Tags
- Display up to 3 tags
- `<TagChip>` component
- Clickable, links to tag filter page
- Overflow: "+2 more" if >3 tags

### Featured Badge
- Top-right corner badge
- Icon: Star or pin
- Color: `var(--color-accent-primary)`

---

## Props

```tsx
interface PostCardProps {
  post: {
    title: string;
    subtitle?: string;
    slug: string;
    url: string;
    excerpt?: string;
    coverImage?: string;
    coverAlt?: string;
    date: string;
    readingTimeMinutes?: number;
    tags: string[];
    lang: string;
    featured?: boolean;
  };
  variant?: 'default' | 'compact' | 'wide';
  showImage?: boolean; // Default: true
  showExcerpt?: boolean; // Default: true
  className?: string;
}
```

---

## Variants

### Default
- Vertical layout, image top
- Full excerpt and metadata

### Compact
- Smaller padding, no excerpt
- For dense lists or sidebar

### Wide
- Horizontal layout, image left
- For featured posts or hero sections

---

## Styling

- **Background**: `var(--color-bg-surface)`
- **Border radius**: `var(--radius-card)`
- **Shadow**: `var(--shadow-md)` → `var(--shadow-card-hover)` on hover
- **Padding**: `var(--card-padding)`
- **Transition**: All 300ms ease
- **Hover effects**:
  - Lift: `translateY(-4px)`
  - Shadow increase
  - Image zoom
  - Title gradient

---

## Micro-Interactions

- **Hover**: Lift card, increase shadow, zoom image, gradient title
- **Focus**: Outline on card container (keyboard accessible)
- **Click**: Subtle press effect (`scale(0.98)` for 100ms)
- **Tag hover**: Tag chips scale and change color

---

## Accessibility

- **Semantic HTML**: `<article>` wrapper
- **Heading hierarchy**: `<h3>` for title (assumes `<h1>` on page, `<h2>` for sections)
- **Alt text**: Always provide for cover images
- **Link text**: Full card is clickable via overlay link (title link)
- **ARIA**: `aria-label` for date (human-readable format)
- **Focus**: Visible outline on keyboard focus

---

## Example Usage

```tsx
<PostCard 
  post={post} 
  variant="default"
  showImage={true}
  showExcerpt={true}
/>
```

---

## DON'Ts

- **Never** use for full post content (only previews)
- **Never** make cards too small (<280px width)
- **Never** exceed 3 lines for title (use ellipsis)
- **Never** show all tags (limit to 3, then "+N more")
- **Never** forget to lazy-load images
- **Never** use low-contrast text on images (add gradient overlay)
