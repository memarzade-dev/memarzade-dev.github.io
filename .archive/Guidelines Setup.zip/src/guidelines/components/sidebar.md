# Sidebar Component

## Purpose

Nested category tree navigation for browsing blog content by topic hierarchy.

---

## When to Use

- Rendered automatically by `LayoutShell`
- Displays on desktop, collapsible on mobile
- Shows nested categories (e.g., AI → Machine Learning → Neural Nets)

---

## Structure

```tsx
<aside className="sidebar">
  <nav aria-label="Category navigation">
    <CategoryTree categories={nestedCategories} />
  </nav>
  
  {/* Optional: Quick links */}
  <div className="sidebar-footer">
    <QuickLinks />
  </div>
</aside>
```

---

## Features

### Nested Category Tree
- Recursive structure from frontmatter `categories` arrays
- Expandable/collapsible branches with chevron icons
- Highlight active category path
- Smooth expand/collapse animation

### Hover States
- Subtle background change on hover
- Show post count badge on hover
- Expand nested categories on hover (desktop)

### Scroll-to-Active
- Auto-scroll to active category on page load
- Expand parent categories of active item

### Collapse/Expand All
- Button to collapse/expand all categories
- Persist state to localStorage

---

## Props

```tsx
interface SidebarProps {
  categories: NestedCategory[];
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
  className?: string;
}

interface NestedCategory {
  name: string;
  slug: string;
  children?: NestedCategory[];
  postCount?: number;
}
```

---

## Styling

- **Width**: 
  - Desktop: `var(--sidebar-width)` (256px)
  - Collapsed: `var(--sidebar-width-collapsed)` (64px, icons only)
  - Mobile: Full screen overlay or slide-in
- **Background**: `var(--color-bg-surface)`
- **Border**: Right border `var(--color-border-subtle)`
- **Padding**: `var(--sidebar-padding)` (16px)
- **Position**: Fixed on desktop, overlay on mobile

### Responsive Behavior
- **Mobile** (<768px): Hidden by default, hamburger menu in header
- **Tablet** (768-1024px): Collapsed (icons only), expand on hover
- **Desktop** (>1024px): Fully expanded by default

---

## UX Rules

- **Always** highlight active category and expand parent path
- **Smooth animations** for expand/collapse (300ms)
- **Keyboard navigable** (Arrow keys for tree navigation)
- **Persist** expand/collapse state to localStorage
- **Auto-scroll** to active item on mount

---

## Accessibility

- **Role**: `<aside>` with `aria-label="Category navigation"`
- **Tree navigation**: Use `role="tree"`, `role="treeitem"`, `aria-expanded`
- **Keyboard support**:
  - `Arrow Up/Down`: Navigate items
  - `Arrow Left`: Collapse node
  - `Arrow Right`: Expand node
  - `Enter/Space`: Activate link
- **Focus visible**: Clear outline on focused items
- **Screen reader**: Announce expanded/collapsed state and post counts

---

## Example Data Structure

```ts
const categories: NestedCategory[] = [
  {
    name: 'AI',
    slug: 'ai',
    postCount: 42,
    children: [
      {
        name: 'Machine Learning',
        slug: 'ai/machine-learning',
        postCount: 18,
        children: [
          { name: 'Neural Networks', slug: 'ai/machine-learning/neural-networks', postCount: 8 },
          { name: 'Deep Learning', slug: 'ai/machine-learning/deep-learning', postCount: 10 }
        ]
      },
      { name: 'NLP', slug: 'ai/nlp', postCount: 12 }
    ]
  },
  // ... more categories
];
```

---

## Example Usage

```tsx
<Sidebar 
  categories={nestedCategories} 
  isCollapsed={false}
  onToggleCollapse={() => setCollapsed(!isCollapsed)}
/>
```

---

## DON'Ts

- **Never** nest more than 4 levels deep (UX gets confusing)
- **Never** auto-expand all categories on mount (overwhelming)
- **Never** hide category names when collapsed (use icons or abbreviations)
- **Never** use tiny click targets (<44px for touch)
- **Never** forget to show active state and breadcrumb path
