# LayoutShell Component

## Purpose

Master layout wrapper that provides consistent structure across all pages: sticky header, collapsible sidebar, main content area, and footer.

---

## When to Use

- **Always** wrap all pages in `<LayoutShell>`
- Provides global navigation, theme, and layout structure
- Handles responsive behavior (mobile/tablet/desktop)

---

## Structure

```tsx
<LayoutShell>
  <Header /> {/* Sticky top */}
  <div className="layout-body">
    <Sidebar /> {/* Collapsible, hidden on mobile */}
    <main>{children}</main>
  </div>
  <Footer />
</LayoutShell>
```

---

## Features

### Responsive Grid
- **Mobile** (<768px): Single column, sidebar hidden (hamburger menu)
- **Tablet** (768-1024px): Collapsed sidebar with icons only
- **Desktop** (>1024px): Full sidebar expanded

### Sticky Header
- Height: `var(--header-height)` (64px)
- `position: sticky; top: 0; z-index: 50`
- Backdrop blur for depth

### Collapsible Sidebar
- Desktop width: `var(--sidebar-width)` (256px)
- Collapsed width: `var(--sidebar-width-collapsed)` (64px)
- Toggle button in header on mobile
- Smooth transition (300ms)

### Main Content Area
- Max width: `var(--width-container)` (1280px)
- Centered with auto margins
- Padding: `var(--padding-page-mobile)` → `var(--padding-page-desktop)`

---

## Props

```tsx
interface LayoutShellProps {
  children: React.ReactNode;
  showSidebar?: boolean; // Default: true
  sidebarCollapsed?: boolean; // Default: false
  className?: string;
}
```

---

## UX Rules

- **Header** must always be visible (sticky)
- **Sidebar** collapses automatically on mobile, can be toggled on desktop
- **Main content** should have comfortable reading width (max 1280px)
- **Footer** is always at bottom, even if content is short (use flexbox min-height)
- **Smooth transitions** for sidebar collapse/expand (respect `prefers-reduced-motion`)

---

## Accessibility

- **Landmark roles**: `<header>`, `<nav>`, `<main>`, `<aside>`, `<footer>`
- **Skip to content** link (hidden until focused)
- **Keyboard navigation**: Tab through header → sidebar → main → footer
- **ARIA labels**: `aria-label="Main navigation"` for sidebar

---

## Example Usage

```tsx
// In App.tsx or route layout
import { LayoutShell } from './layouts/LayoutShell';

function App() {
  return (
    <LayoutShell>
      <HomePage />
    </LayoutShell>
  );
}
```

---

## DON'Ts

- **Never** render multiple `LayoutShell` instances (only one per page)
- **Never** place `LayoutShell` inside another layout component
- **Never** hardcode header/sidebar dimensions (use CSS variables)
- **Never** break sticky header behavior (z-index, positioning)
