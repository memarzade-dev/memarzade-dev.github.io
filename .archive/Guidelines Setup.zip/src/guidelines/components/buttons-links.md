# Buttons & Links Component Guidelines

## Purpose

Consistent, accessible button and link components that respect design tokens and provide excellent UX.

---

## Button Variants

### Primary (CTA)
- Background: `var(--color-accent-primary)`
- Text: `var(--color-text-inverse)`
- Hover: `var(--color-accent-primary-hover)` + lift effect
- Use for: Primary actions, CTAs, submit buttons

### Secondary
- Border: `2px solid var(--color-accent-primary)`
- Text: `var(--color-accent-primary)`
- Background: `transparent`
- Hover: `background: var(--color-accent-primary)`, `color: white`
- Use for: Secondary actions, cancel buttons

### Ghost / Text
- Background: `transparent`
- Text: `var(--color-text-secondary)`
- Hover: `background: var(--color-bg-hover)`
- Use for: Tertiary actions, inline links, nav items

### Danger
- Background: `var(--color-danger)`
- Text: `white`
- Use for: Delete, destructive actions

---

## Button Sizes

```tsx
size="sm"  // padding: 0.5rem 0.75rem, font-size: 14px
size="md"  // padding: 0.75rem 1rem, font-size: 16px (default)
size="lg"  // padding: 1rem 1.5rem, font-size: 18px
```

---

## Button Props

```tsx
interface ButtonProps {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  loading?: boolean;
  icon?: React.ReactNode;
  iconPosition?: 'left' | 'right';
  fullWidth?: boolean;
  onClick?: () => void;
  type?: 'button' | 'submit' | 'reset';
  className?: string;
  children: React.ReactNode;
}
```

---

## Button States

### Default
- Cursor: `pointer`
- Transition: `all 300ms ease`

### Hover
- Transform: `translateY(-2px)` (lift)
- Shadow: `var(--shadow-hover)`
- Color: Variant-specific hover color

### Focus
- Outline: `var(--shadow-glow-primary)` (focus ring)
- No default browser outline

### Active (Pressed)
- Transform: `scale(0.98)`
- Duration: `100ms`

### Disabled
- Opacity: `0.5`
- Cursor: `not-allowed`
- No hover effects

### Loading
- Show spinner icon
- Disable interaction
- Text: Optional "Loading..." or keep original

---

## Link Component

### Internal Links (React Router)
```tsx
<Link to="/posts/ai">AI Posts</Link>
```

- Uses `react-router-dom` `Link`
- Color: `var(--color-accent-primary)`
- Hover: Underline + slight brightness increase
- Visited: Same color (not purple)

### External Links
```tsx
<Link href="https://..." external>
  External Site
</Link>
```

- `target="_blank"`
- `rel="noopener noreferrer"`
- Icon: External link indicator (top-right arrow)
- Hover: Same as internal

### Anchor Links (Same Page)
```tsx
<Link to="#section">Jump to Section</Link>
```

- Smooth scroll behavior
- Update URL hash
- Highlight target section briefly

---

## Link Props

```tsx
interface LinkProps {
  to?: string;           // Internal route
  href?: string;         // External URL
  external?: boolean;    // Auto-add target="_blank"
  anchor?: boolean;      // Same-page anchor
  variant?: 'default' | 'underlined' | 'button';
  className?: string;
  children: React.ReactNode;
  onClick?: (e: React.MouseEvent) => void;
}
```

---

## Micro-Interactions

### Button Hover
- Lift: `translateY(-2px)` in 200ms
- Shadow: Fade in `shadow-hover`
- Color: Brighten by 10%

### Button Click
- Press: `scale(0.98)` for 100ms
- Ripple effect (optional)

### Link Hover
- Underline: Fade in from left to right (300ms)
- Color: Brighten by 15%

---

## Accessibility

### Buttons
- **Role**: `<button>` (semantic)
- **Type**: Specify `type="button"` (default) or `type="submit"`
- **ARIA**: 
  - `aria-disabled="true"` for disabled state
  - `aria-busy="true"` for loading state
  - `aria-label` if icon-only
- **Keyboard**: `Enter` and `Space` activate
- **Focus**: Visible focus ring (no `:focus-visible` removal)

### Links
- **Role**: `<a>` (semantic)
- **Text**: Descriptive (not "click here")
- **External**: Announce "opens in new tab" (screen reader)
- **Keyboard**: `Enter` activates
- **Focus**: Visible outline

---

## Example Usage

### Primary Button
```tsx
<Button variant="primary" size="lg" onClick={handleSubmit}>
  Submit Article
</Button>
```

### Secondary with Icon
```tsx
<Button variant="secondary" icon={<PlusIcon />} iconPosition="left">
  Add Post
</Button>
```

### Loading State
```tsx
<Button variant="primary" loading={isSubmitting}>
  {isSubmitting ? 'Saving...' : 'Save'}
</Button>
```

### Internal Link
```tsx
<Link to="/posts/ai">Explore AI Posts</Link>
```

### External Link
```tsx
<Link href="https://github.com/memarzade-dev" external>
  GitHub Profile
</Link>
```

---

## DON'Ts

- **Never** use `<div>` for buttons (use `<button>`)
- **Never** use `<a>` without `href` (use `<button>` instead)
- **Never** remove focus outlines (accessibility)
- **Never** make buttons too small (<44px tap target on mobile)
- **Never** use "click here" or "read more" for link text (describe destination)
- **Never** open external links in same tab without warning
- **Never** forget to disable buttons during async operations
