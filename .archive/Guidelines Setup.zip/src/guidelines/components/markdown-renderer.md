# MarkdownRenderer Component

## Purpose

Core component for rendering GitHub Flavored Markdown + Obsidian extensions to React, with full RTL/LTR support, syntax highlighting, and interactive features.

---

## When to Use

- **Post pages**: Render full article content
- **Category descriptions**: Render Markdown descriptions
- **Any Markdown content**: Never use raw `dangerouslySetInnerHTML`

---

## Structure

```tsx
<div className="markdown-renderer" dir="auto">
  <ReactMarkdown
    remarkPlugins={[remarkGfm, remarkMath, ...customPlugins]}
    rehypePlugins={[rehypeKatex, rehypeHighlight, rehypeSanitize, rehypeRaw]}
    components={customComponents}
  >
    {content}
  </ReactMarkdown>
</div>
```

---

## Plugins Stack

### Remark (Markdown processing)
- `remark-gfm`: Tables, task lists, strikethrough
- `remark-math`: LaTeX math parsing
- **Custom**: Obsidian callouts, internal links, tags

### Rehype (HTML processing)
- `rehype-katex`: Render LaTeX with KaTeX
- `rehype-highlight`: Code syntax highlighting
- `rehype-raw`: Allow trusted HTML
- `rehype-sanitize`: Security (custom schema)

---

## Custom Components Mapping

Map Markdown elements to styled React components:

```tsx
const components = {
  h1: ({ children }) => <Heading level={1} dir="auto">{children}</Heading>,
  h2: ({ children }) => <Heading level={2} dir="auto">{children}</Heading>,
  // ... h3-h6
  
  p: ({ children }) => <Paragraph dir="auto">{children}</Paragraph>,
  
  a: ({ href, children }) => <Link href={href}>{children}</Link>,
  
  code: ({ inline, className, children }) => (
    inline 
      ? <CodeInline>{children}</CodeInline>
      : <CodeBlock language={className?.replace('language-', '')}>{children}</CodeBlock>
  ),
  
  blockquote: ({ children }) => {
    // Detect Obsidian callouts: > [!type]
    if (isCallout(children)) {
      return <Callout {...parseCallout(children)} />;
    }
    return <Blockquote>{children}</Blockquote>;
  },
  
  table: ({ children }) => <Table responsive>{children}</Table>,
  
  img: ({ src, alt, title }) => <Image src={src} alt={alt} title={title} lazy />,
  
  // ... more mappings
};
```

---

## RTL/LTR Detection

### Block-Level Detection
```tsx
function detectDirection(text: string): 'ltr' | 'rtl' | 'auto' {
  const rtlPattern = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/;
  const ltrPattern = /[A-Za-z]/;
  
  const hasRTL = rtlPattern.test(text);
  const hasLTR = ltrPattern.test(text);
  
  if (hasRTL && !hasLTR) return 'rtl';
  if (hasLTR && !hasRTL) return 'ltr';
  return 'auto'; // Mixed content
}

function Paragraph({ children, ...props }) {
  const text = extractText(children);
  const dir = detectDirection(text);
  const fontFamily = dir === 'rtl' ? 'var(--font-rtl)' : 'var(--font-body)';
  
  return (
    <p dir={dir} style={{ fontFamily }} {...props}>
      {children}
    </p>
  );
}
```

### Mixed Inline Content
Use `<bdi>` for bidirectional isolation:
```tsx
<p dir="auto">
  English text <bdi>فارسی</bdi> more English
</p>
```

---

## Obsidian Features

### Callouts / Admonitions
Parse `> [!type] Title` and render as `<Callout>`:

```tsx
// Input Markdown:
> [!warning] Important Notice
> This is a warning callout.

// Renders as:
<Callout variant="warning" title="Important Notice">
  This is a warning callout.
</Callout>
```

Supported types: `note`, `tip`, `info`, `warning`, `danger`, `quote`, `example`, `question`, `success`, `failure`, `bug`

### Internal Links
Parse `[[Note Name]]` and `[[Note#Heading|Alias]]`:

```tsx
// [[Neural Networks]]
<InternalLink to="/posts/neural-networks">Neural Networks</InternalLink>

// [[AI#Machine Learning|ML]]
<InternalLink to="/posts/ai#machine-learning">ML</InternalLink>
```

### Embeds / Transclusions
Parse `![[Note#Heading]]` and `![[image.jpg|400]]`:

```tsx
// ![[Other Post#Section]]
<EmbedContent slug="other-post" anchor="section" />

// ![[diagram.png|600]]
<Image src="/assets/diagram.png" width={600} />
```

### Tags
Parse `#tag` and `#nested/tag`:

```tsx
// #machine-learning
<TagLink tag="machine-learning">#machine-learning</TagLink>
```

### Highlights
Parse `==highlighted==` and `<mark>`:

```tsx
<mark className="highlight">highlighted text</mark>
```

### Mermaid Diagrams
Parse ` ```mermaid ` blocks:

```tsx
<MermaidCanvas chart={`
  graph TD;
    A-->B;
    A-->C;
`} />
```

**Implementation**: Use `react-mermaid2` or lazy-load mermaid.js

### LaTeX Math
Inline `$...$` and block `$$...$$` with KaTeX:

```tsx
// Inline: $x^2$
<span className="math-inline">x²</span>

// Block: $$ \int_0^\infty $$
<div className="math-block">∫₀^∞</div>
```

---

## Code Highlighting

- **Inline code**: `` `code` `` → `<code className="inline">`
- **Fenced blocks**: ` ```language ` → `<CodeBlock language="ts">`

### Features
- Syntax highlighting (Prism.js or highlight.js)
- Line numbers
- Copy button
- Language label
- Diff highlighting (`+ ` / `- ` prefixes)

### Supported Languages
`ts`, `tsx`, `js`, `jsx`, `python`, `bash`, `shell`, `diff`, `json`, `yaml`, `markdown`, `html`, `css`, `sql`, `graphql`, `go`, `rust`, `c`, `cpp`, `java`, `php`, `ruby`, etc.

---

## Metadata Extraction

Extract metadata for other features:

```tsx
interface MarkdownMetadata {
  headings: Heading[];      // For TOC
  outboundLinks: string[];  // For graph
  tags: string[];           // For search index
  internalLinks: string[];  // For graph
}

function extractMetadata(mdContent: string): MarkdownMetadata {
  // Parse and extract
}
```

---

## Props

```tsx
interface MarkdownRendererProps {
  content: string;
  className?: string;
  onHeadingsExtracted?: (headings: Heading[]) => void;
  onLinksExtracted?: (links: string[]) => void;
  onTagsExtracted?: (tags: string[]) => void;
}
```

---

## Accessibility

- **Semantic HTML**: `<article>` wrapper
- **Heading hierarchy**: Ensure sequential (don't skip levels)
- **Alt text**: All images must have `alt`
- **Code blocks**: `role="region"`, `aria-label="Code block"`
- **Links**: Descriptive text, not "click here"
- **Tables**: `<thead>`, `<tbody>`, `<th scope="col/row">`

---

## Example Usage

```tsx
<MarkdownRenderer 
  content={post.body}
  onHeadingsExtracted={(h) => setHeadings(h)}
  onLinksExtracted={(l) => updateGraph(l)}
  onTagsExtracted={(t) => indexTags(t)}
/>
```

---

## DON'Ts

- **Never** use raw `dangerouslySetInnerHTML` (security risk)
- **Never** skip sanitization (use `rehype-sanitize`)
- **Never** mix RTL/LTR fonts incorrectly
- **Never** forget to lazy-load images and heavy diagrams
- **Never** break heading hierarchy (skip levels)
- **Never** use tiny code fonts (<14px)
