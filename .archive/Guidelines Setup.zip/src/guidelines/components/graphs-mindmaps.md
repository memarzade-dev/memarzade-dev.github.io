# Graphs & Mindmaps Component Guidelines

## Purpose

Interactive knowledge graph and mindmap visualizations from post relationships, tags, categories, and internal links.

---

## When to Use

- **Graph page** (`/graph`): Full-screen interactive knowledge graph
- **Post sidebar**: Mini graph showing related posts
- **Tag cloud page**: Tag relationship visualization
- **Category overview**: Mindmap of nested categories

---

## GraphView Component

### Structure
```tsx
<div className="graph-view">
  <GraphControls 
    onZoom={handleZoom}
    onReset={handleReset}
    onToggle3D={toggle3D}
  />
  
  <ForceGraph
    nodes={nodes}
    links={links}
    onNodeClick={handleNodeClick}
    onNodeHover={handleNodeHover}
  />
  
  <GraphLegend items={legendItems} />
</div>
```

---

## Libraries

Choose one based on requirements:

### Option 1: react-force-graph (Recommended)
- **Pros**: Beautiful 2D/3D force-directed layouts, good performance
- **Cons**: Large bundle size
- **Use for**: Main graph page

### Option 2: vis-network
- **Pros**: Stable, well-documented, physics engine
- **Cons**: Less modern API
- **Use for**: Simple relationship graphs

### Option 3: react-flow
- **Pros**: Great for hierarchical layouts, flowcharts
- **Cons**: Not ideal for force-directed graphs
- **Use for**: Category mindmaps, hierarchical trees

---

## Node Types

### Post Node
```tsx
{
  id: 'post-123',
  type: 'post',
  label: 'Neural Networks Intro',
  url: '/posts/neural-networks-intro',
  tags: ['ai', 'ml'],
  category: 'ai/machine-learning',
  connections: 8,
  color: 'var(--color-accent-primary)',
  size: 10 + (connections * 2), // Size by importance
}
```

### Tag Node
```tsx
{
  id: 'tag-ai',
  type: 'tag',
  label: '#ai',
  postCount: 42,
  color: 'var(--color-accent-secondary)',
  size: 8 + (postCount * 0.5),
}
```

### Category Node
```tsx
{
  id: 'cat-ai',
  type: 'category',
  label: 'AI',
  children: ['cat-ml', 'cat-nlp'],
  color: 'var(--color-info)',
  size: 12,
}
```

---

## Link Types

### Internal Link (Post → Post)
```tsx
{
  source: 'post-123',
  target: 'post-456',
  type: 'internal-link',
  strength: 1,
  color: 'rgba(59, 130, 246, 0.3)',
}
```

### Tag Relation (Post → Tag)
```tsx
{
  source: 'post-123',
  target: 'tag-ai',
  type: 'tag',
  strength: 0.5,
  color: 'rgba(16, 185, 129, 0.2)',
}
```

### Category Relation (Post → Category)
```tsx
{
  source: 'post-123',
  target: 'cat-ai',
  type: 'category',
  strength: 0.7,
  color: 'rgba(59, 130, 246, 0.2)',
}
```

---

## Features

### Force-Directed Layout
- Physics-based positioning
- Attractive force between linked nodes
- Repulsive force between all nodes
- Configurable strength and distance

### Interactions

#### Node Click
- Navigate to post/tag/category
- Highlight connections
- Show node details in sidebar

#### Node Hover
- Tooltip with metadata (title, date, tags)
- Dim unconnected nodes
- Highlight direct connections

#### Drag
- Drag nodes to reposition
- Pin node in place (lock position)
- Unpin to resume physics

#### Zoom & Pan
- Mouse wheel zoom (pinch on mobile)
- Click-drag to pan
- Reset view button

### Filters
- **By type**: Show/hide posts, tags, categories
- **By tag**: Show only nodes with specific tag
- **By date**: Filter posts by date range
- **By connections**: Show only nodes with N+ connections

### Search
- Highlight search term in graph
- Zoom to matching node
- Show path between two nodes

---

## Props

```tsx
interface GraphViewProps {
  nodes: GraphNode[];
  links: GraphLink[];
  width?: number;
  height?: number;
  show3D?: boolean;
  backgroundColor?: string;
  onNodeClick?: (node: GraphNode) => void;
  onNodeHover?: (node: GraphNode | null) => void;
  className?: string;
}

interface GraphNode {
  id: string;
  type: 'post' | 'tag' | 'category';
  label: string;
  url?: string;
  color: string;
  size: number;
  metadata?: Record<string, any>;
}

interface GraphLink {
  source: string;
  target: string;
  type: 'internal-link' | 'tag' | 'category';
  strength: number;
  color: string;
}
```

---

## Styling

- **Background**: `var(--color-bg-base)` (dark)
- **Node colors**: Themed by type (posts blue, tags green, categories purple)
- **Link colors**: Semi-transparent, themed by relationship type
- **Node labels**: Font `var(--font-body)`, size scales with zoom
- **Hover highlight**: Brighten node, bold label, glow effect

---

## Performance

- **Lazy-load**: Use `React.lazy()` for graph component
- **Memoize**: `useMemo` for node/link calculations
- **Limit nodes**: Show max 100-200 nodes at once (paginate or filter)
- **Debounce**: Debounce hover events (50ms)
- **Canvas**: Use canvas rendering (not SVG) for >50 nodes
- **Worker**: Offload physics calculations to Web Worker if available

---

## Accessibility

- **Keyboard navigation**: Tab through nodes, Enter to activate
- **ARIA**: `role="img"`, `aria-label="Knowledge graph of blog posts"`
- **Alternative view**: Provide list view toggle for screen readers
- **Focus**: Visible focus ring on active node
- **Zoom**: Keyboard zoom with `+` / `-` keys

---

## Example Usage

```tsx
<GraphView 
  nodes={allNodes}
  links={allLinks}
  show3D={false}
  onNodeClick={(node) => navigate(node.url)}
  onNodeHover={(node) => setHoveredNode(node)}
/>
```

---

## DON'Ts

- **Never** render >500 nodes without pagination (performance)
- **Never** use tiny nodes (<4px, hard to click)
- **Never** forget to lazy-load (large bundle size)
- **Never** skip memoization (causes constant re-renders)
- **Never** use low-contrast links (hard to see)
- **Never** auto-play 3D mode (can be disorienting)
- **Never** forget alternative view for accessibility
