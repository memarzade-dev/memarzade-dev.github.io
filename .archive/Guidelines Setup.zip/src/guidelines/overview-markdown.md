# Markdown & Obsidian Support Overview

## Scope

The `MarkdownRenderer` component must support **GitHub Flavored Markdown (GFM)** plus **Obsidian extensions** to enable rich, technical, interlinked content.

---

## GitHub Flavored Markdown (Core)

### Headings
- `#` to `######` (H1–H6)
- Render with semantic HTML (`<h1>`–`<h6>`)
- Extract for TOC generation

### Text Formatting
- **Bold**: `**text**`, `__text__`
- *Italic*: `*text*`, `_text_`
- ***Bold Italic***: `***text***`
- ~~Strikethrough~~: `~~text~~`
- Subscript/Superscript: `<sub>`, `<sup>` or Obsidian syntax

### Code
- **Inline code**: `` `code` ``
- **Fenced blocks**: ` ```language ` with syntax highlighting (Prism.js or rehype-highlight)
- Support `ts`, `tsx`, `js`, `jsx`, `python`, `bash`, `diff`, `json`, `yaml`, `markdown`, `html`, `css`, `sql`, etc.

### Lists
- Unordered: `- `, `* `, `+ `
- Ordered: `1. `, `2. `, etc.
- Nested lists (indent with 2 or 4 spaces)
- **Task lists**: `- [ ]` (unchecked), `- [x]` (checked)

### Blockquotes
- `> quote`
- Nested blockquotes: `> > nested`

### Tables
- GFM table syntax with alignment (`:---`, `:---:`, `---:`)
- Render responsive tables with horizontal scroll on mobile

### Links & Images
- Inline links: `[text](url)`
- Reference links: `[text][ref]` + `[ref]: url`
- Images: `![alt](url "title")`
- Image sizing hints (if supported by Obsidian-style syntax)

### Horizontal Rules
- `---`, `***`, `___`

### Footnotes
- `[^1]` in text, `[^1]: definition` at bottom
- Render as superscript links with backlinks

---

## Obsidian Extensions

### Callouts / Admonitions
Syntax:
```markdown
> [!note] Title
> Content here
```

Types: `note`, `tip`, `info`, `warning`, `danger`, `quote`, `example`, `question`, `success`, `failure`, `bug`

**Render as**: `<Callout variant="note" title="Title">Content</Callout>` with appropriate icons and colors

### Internal Links & Transclusions
- `[[Note Name]]` → Link to internal post by slug or title
- `[[Note#Heading|Alias]]` → Link to heading with custom text
- `![[Note#Heading]]` → Embed/transclude content from another note
- `![[Image.jpg|400]]` → Embed image with width

**Render as**: React Router links for internal navigation, or embedded components

### Tags
- Inline tags: `#tag`, `#nested/tag`
- Extract and link to tag filter pages

### Highlights
- `==highlighted text==` or `<mark>highlighted</mark>`
- Render with `<mark>` element and yellow background

### Definition Lists
```markdown
Term
: Definition
```
Render as `<dl><dt>Term</dt><dd>Definition</dd></dl>`

### Abbreviations
```markdown
*[HTML]: Hyper Text Markup Language
```
Render as `<abbr title="Hyper Text Markup Language">HTML</abbr>`

### Details / Collapsible Sections
```html
<details>
<summary>Click to expand</summary>
Hidden content
</details>
```

### Keyboard Keys
`<kbd>Ctrl</kbd> + <kbd>C</kbd>` → Render as styled keyboard keys

### Comments
```markdown
[//]: # (This is a hidden comment)
```
Do not render in output

### Mermaid Diagrams
` ```mermaid ` blocks with graph, sequence, timeline, flowchart, etc.

**Render as**: `<MermaidCanvas>` component using `react-mermaid2` or equivalent

### LaTeX Math
- Inline: `$x^2 + y^2 = z^2$`
- Block: `$$ \int_0^\infty e^{-x^2} dx = \frac{\sqrt{\pi}}{2} $$`

**Render with**: `remark-math` + `rehype-katex`

### CSV / Data Blocks
` ```csv ` blocks → Render as responsive tables or optional charts

---

## RTL/LTR & Font Handling

- **Detect direction per block/paragraph** using script detection (e.g., `rtl-detect` library or regex)
- Apply `dir="auto"`, `dir="rtl"`, or `dir="ltr"` to containing elements
- Use `<bdi>` for mixed-direction inline content
- **Fonts**:
  - RTL (Persian/Arabic): **Vazirmatn**
  - LTR (English UI): **Space Grotesk** (headings), **Inter** (body)
  - Code (all): **Roboto Mono**

---

## Renderer Responsibilities

`MarkdownRenderer.tsx` must:

1. Use `react-markdown` with plugins:
   - `remark-gfm`
   - `remark-math`
   - `rehype-katex`
   - `rehype-raw` (for trusted HTML)
   - `rehype-highlight` (code syntax)
   - `rehype-sanitize` (security)
   - Custom plugins for Obsidian features

2. Map every Markdown feature to **styled React components** respecting:
   - Design tokens (colors, spacing, typography)
   - RTL/LTR direction and fonts
   - Dark/light themes

3. Extract metadata for:
   - **TOC** (headings)
   - **Outbound links** (for graph)
   - **Tags** (for search index)

4. Support **code highlighting** with line numbers and copy button

5. Handle **lazy-loading** for:
   - Mermaid diagrams
   - Embedded images
   - Large tables
