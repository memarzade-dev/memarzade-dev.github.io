# 🤝 Contributing to Vaults

<div dir="rtl">

از اینکه می‌خواهید به پروژه Vaults کمک کنید متشکریم! این راهنما به شما کمک می‌کند تا بهترین مشارکت را داشته باشید.

</div>

## Code of Conduct

By participating in this project, you agree to maintain a respectful and inclusive environment for everyone.

## How to Contribute

### 🐛 Reporting Bugs

If you find a bug, please create an issue with:

1. **Clear title**: Describe the bug briefly
2. **Steps to reproduce**: How to trigger the bug
3. **Expected behavior**: What should happen
4. **Actual behavior**: What actually happens
5. **Environment**: Browser, OS, Node version
6. **Screenshots**: If applicable

**Template:**

```markdown
**Bug Description**
Clear description of the bug

**Steps to Reproduce**
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

**Expected Behavior**
What you expected to happen

**Actual Behavior**
What actually happened

**Environment**
- Browser: Chrome 120
- OS: macOS 14
- Node: 18.17.0

**Screenshots**
Add screenshots here
```

### 💡 Suggesting Features

Feature requests are welcome! Please include:

1. **Use case**: Why is this feature needed?
2. **Proposed solution**: How should it work?
3. **Alternatives**: Other ways to solve this
4. **Additional context**: Mockups, examples, etc.

### 📝 Improving Documentation

Documentation improvements are always appreciated:

- Fix typos or unclear explanations
- Add examples or use cases
- Translate documentation (especially to Persian)
- Update outdated information

### 🔧 Code Contributions

#### Development Setup

```bash
# Fork and clone the repository
git clone https://github.com/yourusername/vaults-blog.git
cd vaults-blog

# Install dependencies
npm install

# Create a new branch
git checkout -b feature/your-feature-name

# Start development server
npm run dev
```

#### Coding Standards

**TypeScript**
- Use strict TypeScript types
- Avoid `any` type unless absolutely necessary
- Use interfaces for object shapes
- Add JSDoc comments for complex functions

**React**
- Use functional components with hooks
- Follow React hooks rules
- Memoize expensive computations
- Use proper prop types

**Styling**
- Follow VaultsDS design system
- Use Tailwind utility classes
- Maintain RTL/LTR support
- Test in both dark and light themes

**File Structure**
```
src/
├── components/       # Reusable UI components
├── pages/           # Route pages
├── hooks/           # Custom React hooks
├── utils/           # Utility functions
├── types/           # TypeScript types
└── contexts/        # React contexts
```

**Naming Conventions**
- Components: PascalCase (e.g., `PostCard.tsx`)
- Hooks: camelCase with 'use' prefix (e.g., `useBookmarks.ts`)
- Utils: camelCase (e.g., `formatDate.ts`)
- Types: PascalCase (e.g., `Post.ts`)
- CSS classes: kebab-case (e.g., `post-card`)

#### Component Guidelines

**Component Structure**
```typescript
/**
 * ComponentName - Brief description
 * 
 * Detailed description of what the component does
 * 
 * @example
 * <ComponentName prop1="value" prop2={value} />
 */

import React from 'react';

// Types
export interface ComponentNameProps {
  /** Description of prop1 */
  prop1: string;
  /** Description of prop2 */
  prop2?: number;
}

// Component
export function ComponentName({ 
  prop1, 
  prop2 = 10 
}: ComponentNameProps): JSX.Element {
  // Implementation
  return (
    <div>
      {/* Content */}
    </div>
  );
}
```

**Hook Structure**
```typescript
/**
 * useHookName - Brief description
 * 
 * Detailed description of what the hook does
 * 
 * @returns Object with hook values and functions
 */

import { useState, useEffect } from 'react';

export function useHookName() {
  const [state, setState] = useState<Type>(initialValue);
  
  useEffect(() => {
    // Side effects
  }, [dependencies]);
  
  return {
    state,
    setState,
  };
}
```

#### Testing

Before submitting:

```bash
# Type check
npm run type-check

# Build test
npm run build

# Manual testing
npm run dev
```

**Test checklist:**
- [ ] Component renders correctly
- [ ] Props work as expected
- [ ] Dark/Light theme support
- [ ] RTL/LTR support (if text-heavy)
- [ ] Mobile responsive
- [ ] Accessibility (keyboard navigation, screen readers)
- [ ] No console errors
- [ ] Performance (no unnecessary re-renders)

#### Commit Messages

Follow conventional commits format:

```
type(scope): subject

body (optional)

footer (optional)
```

**Types:**
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation changes
- `style`: Code style changes (formatting)
- `refactor`: Code refactoring
- `perf`: Performance improvements
- `test`: Adding tests
- `chore`: Build process or auxiliary tool changes

**Examples:**
```
feat(search): add fuzzy search with Fuse.js

Add full-text search functionality using Fuse.js with weighted fields:
- Title: weight 3
- Tags: weight 2
- Content: weight 1

Closes #42

---

fix(markdown): resolve code block highlighting issue

Fixed syntax highlighting not working for TypeScript code blocks
by properly initializing Prism.js

Fixes #38

---

docs(readme): update installation instructions

Added prerequisites and troubleshooting section
```

#### Pull Request Process

1. **Create a branch** from `main`
   ```bash
   git checkout -b feature/your-feature-name
   ```

2. **Make your changes** following coding standards

3. **Commit your changes** with clear messages
   ```bash
   git add .
   git commit -m "feat: add new feature"
   ```

4. **Push to your fork**
   ```bash
   git push origin feature/your-feature-name
   ```

5. **Create Pull Request** on GitHub
   - Fill in the PR template
   - Link related issues
   - Add screenshots if UI changes
   - Request review

6. **Address review feedback**
   - Make requested changes
   - Push additional commits
   - Reply to comments

7. **Wait for approval and merge**

#### Pull Request Template

```markdown
## Description
Brief description of changes

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update

## Related Issues
Fixes #(issue number)

## Screenshots (if applicable)
Add screenshots here

## Testing
- [ ] Type check passed
- [ ] Build successful
- [ ] Manual testing completed
- [ ] Dark/Light theme tested
- [ ] Mobile responsive tested
- [ ] Accessibility checked

## Checklist
- [ ] Code follows project style guidelines
- [ ] Self-reviewed code
- [ ] Commented complex code
- [ ] Updated documentation
- [ ] No new warnings
- [ ] Added tests if applicable
```

## Project-Specific Guidelines

### VaultsDS Design System

Always follow the VaultsDS design system:

**Colors**
```typescript
// Use design tokens
'bg-surface'           // Surface backgrounds
'text-primary'         // Primary text
'accent-primary'       // Primary accent
```

**Typography**
```typescript
// Font families
'font-heading'  // Space Grotesk (LTR), Vazirmatn (RTL)
'font-body'     // Inter (LTR), Vazirmatn (RTL)
'font-mono'     // Roboto Mono (code)
```

**Spacing**
```typescript
// Use consistent spacing
'space-xs'   // 0.5rem (8px)
'space-sm'   // 0.75rem (12px)
'space-md'   // 1rem (16px)
'space-lg'   // 1.5rem (24px)
'space-xl'   // 2rem (32px)
```

### RTL/LTR Support

Always consider RTL languages:

```typescript
import { detectTextDirection } from '@/utils/rtl';

const direction = detectTextDirection(text);
const fontClass = direction === 'rtl' ? 'font-vazirmatn' : 'font-inter';
```

### Accessibility

Maintain WCAG AA compliance:

```typescript
// Always provide alt text
<img src={src} alt="Descriptive text" />

// Use semantic HTML
<button type="button" aria-label="Close">

// Ensure keyboard navigation
<div role="button" tabIndex={0} onKeyDown={handleKeyDown}>

// Maintain focus indicators
className="focus:ring-2 focus:ring-primary"
```

### Performance

Keep performance in mind:

```typescript
// Lazy load heavy components
const HeavyComponent = React.lazy(() => import('./HeavyComponent'));

// Memoize expensive computations
const result = useMemo(() => expensiveCalculation(data), [data]);

// Use callback memoization
const handleClick = useCallback(() => {
  // Handler logic
}, [dependencies]);
```

## Getting Help

- **Documentation**: Check `/guidelines` directory
- **Issues**: Search existing issues first
- **Discussions**: Use GitHub Discussions for questions
- **Email**: contact@memarzade.dev (for sensitive matters)

## Recognition

Contributors will be:
- Listed in `CONTRIBUTORS.md`
- Mentioned in release notes
- Credited in the documentation

## License

By contributing, you agree that your contributions will be licensed under the MIT License.

---

<div align="center" dir="rtl">

**با تشکر از مشارکت شما!** 💙

</div>
