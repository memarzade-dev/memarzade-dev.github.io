/**
 * Tailwind CSS Configuration
 * 
 * پیکربندی Tailwind CSS برای VaultsDS Design System
 * 
 * نکته: اکثر تنظیمات در /styles/globals.css با @theme است
 * این فایل فقط برای کانفیگ‌های اضافی استفاده می‌شود
 */

/** @type {import('tailwindcss').Config} */
export default {
  content: [
    './index.html',
    './App.tsx',
    './main.tsx',
    './src/**/*.{js,ts,jsx,tsx}',
  ],
  darkMode: 'class',
  theme: {
    extend: {},
  },
  plugins: [],
};
