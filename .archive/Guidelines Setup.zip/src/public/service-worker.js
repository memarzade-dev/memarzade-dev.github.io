/**
 * Service Worker for Vaults Blog
 * 
 * این Service Worker قابلیت آفلاین و caching را فراهم می‌کند
 */

const CACHE_NAME = 'vaults-cache-v1';
const RUNTIME_CACHE = 'vaults-runtime-v1';

// فایل‌هایی که باید در نصب cache شوند
const PRECACHE_URLS = [
  '/',
  '/index.html',
  '/offline.html',
  '/manifest.json',
  '/favicon.svg',
];

/**
 * Install Event - نصب Service Worker
 * زمانی که Service Worker برای اولین بار نصب می‌شود
 */
self.addEventListener('install', (event) => {
  console.log('📦 Service Worker: Installing...');
  
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('📦 Service Worker: Caching app shell');
      return cache.addAll(PRECACHE_URLS);
    }).then(() => {
      console.log('✅ Service Worker: Installed');
      return self.skipWaiting();
    })
  );
});

/**
 * Activate Event - فعال‌سازی Service Worker
 * زمانی که Service Worker فعال می‌شود
 */
self.addEventListener('activate', (event) => {
  console.log('🔄 Service Worker: Activating...');
  
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((cacheName) => {
            return cacheName !== CACHE_NAME && cacheName !== RUNTIME_CACHE;
          })
          .map((cacheName) => {
            console.log('🗑️ Service Worker: Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          })
      );
    }).then(() => {
      console.log('✅ Service Worker: Activated');
      return self.clients.claim();
    })
  );
});

/**
 * Fetch Event - مدیریت درخواست‌های شبکه
 * زمانی که یک درخواست شبکه انجام می‌شود
 */
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // فقط درخواست‌های GET را cache می‌کنیم
  if (request.method !== 'GET') {
    return;
  }

  // استراتژی cache-first برای فایل‌های استاتیک
  if (
    request.url.includes('/assets/') ||
    request.url.includes('/fonts/') ||
    request.url.includes('/images/') ||
    request.url.match(/\.(js|css|png|jpg|jpeg|gif|svg|woff|woff2|ttf|eot)$/)
  ) {
    event.respondWith(cacheFirst(request));
    return;
  }

  // استراتژی network-first برای HTML و API
  if (
    request.url.includes('.html') ||
    url.pathname.startsWith('/api/')
  ) {
    event.respondWith(networkFirst(request));
    return;
  }

  // استراتژی پیش‌فرض: network-first
  event.respondWith(networkFirst(request));
});

/**
 * Cache First Strategy
 * ابتدا از cache بخوان، اگر نبود از شبکه
 */
async function cacheFirst(request) {
  const cache = await caches.open(RUNTIME_CACHE);
  const cached = await cache.match(request);
  
  if (cached) {
    return cached;
  }

  try {
    const response = await fetch(request);
    
    if (response.status === 200) {
      cache.put(request, response.clone());
    }
    
    return response;
  } catch (error) {
    console.error('❌ Service Worker: Fetch failed', error);
    
    // اگر آفلاین هستیم، صفحه offline را نمایش بده
    if (request.destination === 'document') {
      return caches.match('/offline.html');
    }
    
    throw error;
  }
}

/**
 * Network First Strategy
 * ابتدا از شبکه بخوان، اگر نشد از cache
 */
async function networkFirst(request) {
  const cache = await caches.open(RUNTIME_CACHE);

  try {
    const response = await fetch(request);
    
    if (response.status === 200) {
      cache.put(request, response.clone());
    }
    
    return response;
  } catch (error) {
    console.warn('⚠️ Service Worker: Network failed, trying cache', error);
    
    const cached = await cache.match(request);
    
    if (cached) {
      return cached;
    }

    // اگر آفلاین هستیم و هیچ cache ای نداریم، صفحه offline را نمایش بده
    if (request.destination === 'document') {
      return caches.match('/offline.html');
    }

    throw error;
  }
}

/**
 * Message Event - دریافت پیام از client
 * برای مدیریت skipWaiting و سایر دستورات
 */
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    console.log('⏭️ Service Worker: Skip waiting');
    self.skipWaiting();
  }
  
  if (event.data && event.data.type === 'CLEAR_CACHE') {
    console.log('🗑️ Service Worker: Clearing cache');
    event.waitUntil(
      caches.keys().then((cacheNames) => {
        return Promise.all(
          cacheNames.map((cacheName) => caches.delete(cacheName))
        );
      })
    );
  }
});

/**
 * Background Sync (optional)
 * همگام‌سازی پس‌زمینه برای آینده
 */
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-posts') {
    console.log('🔄 Service Worker: Background sync');
    event.waitUntil(syncPosts());
  }
});

async function syncPosts() {
  // پیاده‌سازی همگام‌سازی در آینده
  console.log('🔄 Syncing posts...');
}

/**
 * Push Notification (optional)
 * اعلان‌های Push برای آینده
 */
self.addEventListener('push', (event) => {
  if (event.data) {
    const data = event.data.json();
    
    const options = {
      body: data.body,
      icon: '/icon-192.png',
      badge: '/icon-192.png',
      vibrate: [200, 100, 200],
      data: {
        url: data.url || '/',
      },
    };

    event.waitUntil(
      self.registration.showNotification(data.title, options)
    );
  }
});

/**
 * Notification Click (optional)
 * کلیک روی اعلان
 */
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  event.waitUntil(
    clients.openWindow(event.notification.data.url || '/')
  );
});

console.log('🚀 Service Worker: Loaded');
