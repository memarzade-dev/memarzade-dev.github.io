# Icons and Images

این فولدر باید شامل تمام آیکون‌ها و تصاویر مورد نیاز برای PWA و SEO باشد.

## Required Files

### Favicons
- `favicon.svg` - آیکون اصلی (SVG برای مقیاس‌پذیری)
- `favicon-16x16.png` - آیکون 16x16 پیکسل
- `favicon-32x32.png` - آیکون 32x32 پیکسل
- `apple-touch-icon.png` - آیکون Apple Touch (180x180)
- `safari-pinned-tab.svg` - آیکون Safari Pinned Tab

### PWA Icons
- `icon-192.png` - آیکون PWA 192x192
- `icon-512.png` - آیکون PWA 512x512
- `icon-search.png` - آیکون Shortcut Search (96x96)
- `icon-categories.png` - آیکون Shortcut Categories (96x96)
- `icon-graph.png` - آیکون Shortcut Graph (96x96)

### Microsoft Tiles
- `mstile-70x70.png` - Microsoft Tile 70x70
- `mstile-150x150.png` - Microsoft Tile 150x150
- `mstile-310x310.png` - Microsoft Tile 310x310
- `mstile-310x150.png` - Microsoft Tile 310x150 (Wide)

### Social Media
- `og-image.png` - Open Graph Image (1200x630)
- `twitter-card.png` - Twitter Card Image (1200x600)

### Screenshots
- `screenshot-desktop.png` - Screenshot Desktop (1280x720)
- `screenshot-mobile.png` - Screenshot Mobile (750x1334)

## Icon Generation Tools

### Online Tools
- [Favicon Generator](https://realfavicongenerator.net/)
- [PWA Icon Generator](https://www.pwabuilder.com/)
- [Figma](https://www.figma.com/)

### CLI Tools
```bash
# Install sharp-cli for image processing
npm install -g sharp-cli

# Generate icons from a single source
sharp -i source.png -o icon-192.png resize 192 192
sharp -i source.png -o icon-512.png resize 512 512
sharp -i source.png -o apple-touch-icon.png resize 180 180
```

## Design Guidelines

### Favicon (favicon.svg)
- **Size**: 32x32 base, SVG scalable
- **Colors**: Use brand colors (#3b82f6)
- **Style**: Simple, recognizable at small sizes
- **Background**: Transparent

### PWA Icons
- **Size**: 192x192 and 512x512
- **Format**: PNG with transparency
- **Safe Zone**: Keep important content in center 80%
- **Maskable**: Design should work with circular mask

### Open Graph / Twitter Card
- **Size**: 1200x630 (OG), 1200x600 (Twitter)
- **Format**: PNG or JPG
- **Text**: Large, readable text
- **Branding**: Include logo and site name
- **Colors**: Use brand palette

## Example Icon (SVG)

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
  <rect width="32" height="32" fill="#3b82f6" rx="6"/>
  <path d="M8 12 L16 20 L24 12" stroke="white" stroke-width="2" fill="none"/>
  <text x="16" y="28" text-anchor="middle" fill="white" font-size="12" font-weight="bold">V</text>
</svg>
```

## Checklist

- [ ] Create all favicon sizes
- [ ] Create PWA icons (192, 512)
- [ ] Create Microsoft tiles
- [ ] Create Open Graph image
- [ ] Create Twitter Card image
- [ ] Create app shortcuts icons
- [ ] Create screenshots
- [ ] Test icons in all browsers
- [ ] Test PWA install experience
- [ ] Validate meta tags

## Resources

- [Web App Manifest](https://web.dev/add-manifest/)
- [PWA Icons Best Practices](https://web.dev/maskable-icon/)
- [Favicon Guide](https://evilmartians.com/chronicles/how-to-favicon-in-2021-six-files-that-fit-most-needs)
