/**
 * PostCSS Configuration
 * 
 * پیکربندی PostCSS برای پردازش CSS
 */

export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
