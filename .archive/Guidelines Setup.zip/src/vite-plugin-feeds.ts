// Vite plugin to generate RSS feed and sitemap during build
import { Plugin } from 'vite';
import { writeFileSync } from 'fs';
import { resolve } from 'path';

export interface FeedPluginOptions {
  siteUrl?: string;
  posts?: Array<{
    title: string;
    subtitle?: string;
    excerpt?: string;
    slug: string;
    date: string;
    author?: string;
    category?: string;
  }>;
  categories?: string[];
  tags?: string[];
}

export function feedsPlugin(options: FeedPluginOptions = {}): Plugin {
  const {
    siteUrl = 'https://vaults.memarzade.dev',
    posts = [],
    categories = [],
    tags = [],
  } = options;

  return {
    name: 'vite-plugin-feeds',
    
    async buildEnd() {
      console.log('\n🔨 Generating RSS feed and sitemap...\n');

      try {
        // Generate RSS feed
        const rssContent = generateRSS(posts, siteUrl);
        writeFileSync(resolve('public', 'rss.xml'), rssContent, 'utf-8');
        console.log('✅ RSS feed generated: public/rss.xml');
        console.log(`   - ${posts.length} posts included\n`);

        // Generate sitemap
        const sitemapContent = generateSitemap(posts, categories, tags, siteUrl);
        writeFileSync(resolve('public', 'sitemap.xml'), sitemapContent, 'utf-8');
        console.log('✅ Sitemap generated: public/sitemap.xml');
        
        const urlCount = (sitemapContent.match(/<url>/g) || []).length;
        console.log(`   - ${urlCount} URLs included\n`);
      } catch (error) {
        console.error('❌ Error generating feeds:', error);
      }
    },
  };
}

function generateRSS(
  posts: FeedPluginOptions['posts'] = [],
  siteUrl: string
): string {
  const items = posts.map(post => `
    <item>
      <title><![CDATA[${post.title}]]></title>
      <link>${siteUrl}/posts/${post.slug}</link>
      <description><![CDATA[${post.excerpt || post.subtitle || post.title}]]></description>
      <pubDate>${new Date(post.date).toUTCString()}</pubDate>
      ${post.author ? `<author>${post.author}</author>` : ''}
      ${post.category ? `<category>${post.category}</category>` : ''}
      <guid isPermaLink="true">${siteUrl}/posts/${post.slug}</guid>
    </item>`
  ).join('');

  return `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>Vaults - Developer Blog</title>
    <description>A Developer's Free Code License - Deep technical content and digital garden</description>
    <link>${siteUrl}</link>
    <language>en</language>
    <copyright>Copyright ${new Date().getFullYear()} Vaults</copyright>
    <lastBuildDate>${new Date().toUTCString()}</lastBuildDate>
    <pubDate>${new Date().toUTCString()}</pubDate>
    <ttl>60</ttl>
    <category>Technology</category>
    <image>
      <url>${siteUrl}/logo.png</url>
      <title>Vaults - Developer Blog</title>
      <link>${siteUrl}</link>
    </image>
    <atom:link href="${siteUrl}/rss.xml" rel="self" type="application/rss+xml" />
    ${items}
  </channel>
</rss>`;
}

function generateSitemap(
  posts: FeedPluginOptions['posts'] = [],
  categories: string[] = [],
  tags: string[] = [],
  siteUrl: string
): string {
  const urls: string[] = [];

  // Homepage
  urls.push(`
  <url>
    <loc>${siteUrl}</loc>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>`);

  // Static pages
  const staticPages = [
    { path: '/categories', changefreq: 'weekly', priority: 0.8 },
    { path: '/tags', changefreq: 'weekly', priority: 0.8 },
    { path: '/search', changefreq: 'monthly', priority: 0.6 },
    { path: '/graph', changefreq: 'weekly', priority: 0.7 },
    { path: '/bookmarks', changefreq: 'monthly', priority: 0.5 },
    { path: '/history', changefreq: 'monthly', priority: 0.5 },
  ];

  staticPages.forEach(page => {
    urls.push(`
  <url>
    <loc>${siteUrl}${page.path}</loc>
    <changefreq>${page.changefreq}</changefreq>
    <priority>${page.priority}</priority>
  </url>`);
  });

  // Blog posts
  posts.forEach(post => {
    urls.push(`
  <url>
    <loc>${siteUrl}/posts/${post.slug}</loc>
    <lastmod>${new Date(post.date).toISOString().split('T')[0]}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.9</priority>
  </url>`);
  });

  // Category pages
  categories.forEach(category => {
    const slug = category.toLowerCase().replace(/\s+/g, '-');
    urls.push(`
  <url>
    <loc>${siteUrl}/categories/${slug}</loc>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>`);
  });

  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  ${urls.join('')}
</urlset>`;
}
