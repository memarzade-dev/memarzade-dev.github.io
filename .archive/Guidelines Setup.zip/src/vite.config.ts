/**
 * Vite Configuration
 * 
 * پیکربندی کامل Vite برای پروژه Vaults Blog
 * شامل plugins، build options، و تنظیمات optimization
 */

import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { resolve } from 'path';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    react({
      // React Fast Refresh
      fastRefresh: true,
      // JSX runtime automatic
      jsxRuntime: 'automatic',
    }),
  ],
  
  // Base URL for GitHub Pages
  // تغییر بدهید اگر از subdirectory استفاده می‌کنید
  base: '/',
  
  // Build configuration
  build: {
    // خروجی build
    outDir: 'dist',
    
    // تولید sourcemap برای debugging
    sourcemap: true,
    
    // حداقل سایز برای code splitting (KB)
    chunkSizeWarningLimit: 1000,
    
    // Rollup options
    rollupOptions: {
      output: {
        // تقسیم manual chunks برای optimization
        manualChunks: {
          // React و React Router در یک chunk
          'react-vendor': ['react', 'react-dom', 'react-router-dom'],
          
          // Markdown utilities در یک chunk
          'markdown-vendor': ['unified', 'remark-parse', 'remark-gfm', 'remark-math', 'rehype-sanitize'],
          
          // Search و analytics در یک chunk
          'utils-vendor': ['fuse.js'],
        },
        
        // نامگذاری فایل‌های asset
        assetFileNames: (assetInfo) => {
          const info = assetInfo.name?.split('.') || [];
          const ext = info[info.length - 1];
          
          if (/png|jpe?g|svg|gif|tiff|bmp|ico/i.test(ext)) {
            return `assets/images/[name]-[hash][extname]`;
          } else if (/woff2?|ttf|eot/i.test(ext)) {
            return `assets/fonts/[name]-[hash][extname]`;
          }
          
          return `assets/[name]-[hash][extname]`;
        },
        
        // نامگذاری فایل‌های chunk
        chunkFileNames: 'assets/js/[name]-[hash].js',
        
        // نامگذاری فایل‌های entry
        entryFileNames: 'assets/js/[name]-[hash].js',
      },
    },
    
    // Minification
    minify: 'terser',
    terserOptions: {
      compress: {
        drop_console: true, // حذف console.log در production
        drop_debugger: true,
      },
    },
    
    // CSS code splitting
    cssCodeSplit: true,
    
    // Target browsers
    target: 'es2015',
  },
  
  // Development server
  server: {
    port: 3000,
    host: true,
    open: true,
    cors: true,
  },
  
  // Preview server
  preview: {
    port: 4173,
    host: true,
    open: true,
  },
  
  // Path aliases
  resolve: {
    alias: {
      '@': resolve(__dirname, './src'),
      '@components': resolve(__dirname, './src/components'),
      '@pages': resolve(__dirname, './src/pages'),
      '@hooks': resolve(__dirname, './src/hooks'),
      '@utils': resolve(__dirname, './src/utils'),
      '@types': resolve(__dirname, './src/types'),
      '@contexts': resolve(__dirname, './src/contexts'),
      '@layouts': resolve(__dirname, './src/layouts'),
      '@data': resolve(__dirname, './src/data'),
    },
  },
  
  // CSS configuration
  css: {
    devSourcemap: true,
  },
  
  // Optimizations
  optimizeDeps: {
    include: [
      'react',
      'react-dom',
      'react-router-dom',
      'fuse.js',
      'lucide-react',
    ],
  },
  
  // Environment variables prefix
  envPrefix: 'VITE_',
  
  // JSON handling
  json: {
    namedExports: true,
    stringify: false,
  },
});
