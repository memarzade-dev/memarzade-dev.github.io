---
title: Getting Started with Vaults
subtitle: Welcome to your digital garden
date: 2025-12-04
category: Tutorial
tags:
  - Getting Started
  - Guide
  - Introduction
author: Vaults Team
excerpt: Learn how to get started with Vaults, a developer's digital garden for technical content.
coverImage: https://images.unsplash.com/photo-1516116216624-53e697fedbea?w=1200&h=600&fit=crop
featured: true
draft: false
---

# Welcome to Vaults

**Vaults** is an AWWWARDS-level personal blog and digital garden designed for deep technical content. This guide will help you get started with creating and managing your content.

## What is a Digital Garden?

A digital garden is a collection of evolving ideas, notes, and essays that grow over time. Unlike a traditional blog where posts are published and rarely updated, a digital garden is:

- **Evolving**: Content is continuously refined and updated
- **Connected**: Ideas link to each other, forming a knowledge graph
- **Exploratory**: Encourages browsing and discovery rather than chronological reading

> [!NOTE]
> Digital gardens prioritize learning and growth over polished perfection.

## Key Features

### 1. Advanced Markdown Support

Vaults supports GitHub Flavored Markdown with extensions:

```typescript
// Syntax highlighting works out of the box
const greet = (name: string): string => {
  return `Hello, ${name}!`;
};

console.log(greet('World'));
```

### 2. Obsidian-Style Callouts

Use callouts to highlight important information:

> [!TIP]
> You can use different callout types: note, tip, info, warning, danger, success, example, and quote.

> [!WARNING]
> Make sure to always use meaningful frontmatter for better SEO and discoverability.

### 3. Math Equations

Write LaTeX equations inline like $E = mc^2$ or as display blocks:

$$
\int_{-\infty}^{\infty} e^{-x^2} dx = \sqrt{\pi}
$$

### 4. Mermaid Diagrams

Create flowcharts, sequence diagrams, and more:

```mermaid
graph LR
    A[Write Content] --> B[Add Frontmatter]
    B --> C[Save as .md]
    C --> D[Build Site]
    D --> E[Deploy]
```

## Creating Your First Post

1. **Create a new markdown file** in the `/posts` directory
2. **Add frontmatter** with metadata:

```yaml
---
title: Your Post Title
date: 2025-12-04
category: Your Category
tags:
  - tag1
  - tag2
excerpt: A brief description
---
```

3. **Write your content** using Markdown
4. **Build and deploy** your site

## Navigation Features

Vaults includes several ways to discover content:

| Feature | Description |
|---------|-------------|
| **Search** | Full-text search with Fuse.js |
| **Categories** | Organize posts by topic |
| **Tags** | Cross-cutting themes and keywords |
| **Knowledge Graph** | Visual exploration of connections |

## Next Steps

- Explore the [knowledge graph](/graph) to see how posts connect
- Check out [categories](/categories) to browse by topic
- Use [search](/search) to find specific content
- Bookmark posts for later reading

Happy writing! 🚀

## Related Topics

- [[Markdown Guide]]
- [[SEO Best Practices]]
- [[Content Strategy]]
