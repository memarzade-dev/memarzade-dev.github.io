---
title: React Performance Optimization
subtitle: Making your React apps blazingly fast
date: 2025-12-01
category: React
tags:
  - React
  - Performance
  - Optimization
  - Web Development
author: Vaults Team
excerpt: Learn proven techniques to optimize React application performance, from memoization to code splitting.
coverImage: https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=1200&h=600&fit=crop
featured: false
draft: false
readingTime: 10
---

# React Performance Optimization

Building fast React applications requires understanding how React works under the hood and applying the right optimization techniques at the right time.

> [!WARNING]
> Premature optimization is the root of all evil. Always measure before optimizing!

## Understanding React Rendering

React uses a virtual DOM to efficiently update the UI. The rendering process follows these steps:

```mermaid
sequenceDiagram
    participant S as State Change
    participant R as React
    participant V as Virtual DOM
    participant D as Real DOM
    
    S->>R: setState() called
    R->>V: Create new virtual DOM
    V->>V: Diff with old virtual DOM
    V->>D: Apply minimal changes
    D->>D: Browser repaints
```

## Memoization Techniques

### React.memo

Prevent unnecessary re-renders of functional components:

```typescript
import { memo } from 'react';

interface UserProps {
  name: string;
  age: number;
}

const User = memo(({ name, age }: UserProps) => {
  console.log('User rendered');
  return (
    <div>
      <h2>{name}</h2>
      <p>Age: {age}</p>
    </div>
  );
});

export default User;
```

### useMemo

Memoize expensive calculations:

```typescript
import { useMemo } from 'react';

function ExpensiveComponent({ items }: { items: number[] }) {
  const sortedItems = useMemo(() => {
    console.log('Sorting items...');
    return items.sort((a, b) => a - b);
  }, [items]);

  return (
    <ul>
      {sortedItems.map(item => (
        <li key={item}>{item}</li>
      ))}
    </ul>
  );
}
```

> [!TIP]
> Only use `useMemo` for truly expensive computations. Simple operations don't benefit from memoization.

### useCallback

Memoize callback functions to prevent child re-renders:

```typescript
import { useCallback, useState } from 'react';

function Parent() {
  const [count, setCount] = useState(0);

  // This callback will only be created once
  const handleClick = useCallback(() => {
    console.log('Clicked!');
  }, []);

  return <Child onClick={handleClick} />;
}
```

## Code Splitting

Split your bundle into smaller chunks for faster initial load:

### Route-based splitting

```typescript
import { lazy, Suspense } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

// Lazy load route components
const Home = lazy(() => import('./pages/Home'));
const About = lazy(() => import('./pages/About'));
const Profile = lazy(() => import('./pages/Profile'));

function App() {
  return (
    <BrowserRouter>
      <Suspense fallback={<div>Loading...</div>}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/profile" element={<Profile />} />
        </Routes>
      </Suspense>
    </BrowserRouter>
  );
}
```

### Component-based splitting

```typescript
const HeavyComponent = lazy(() => import('./HeavyComponent'));

function App() {
  const [show, setShow] = useState(false);

  return (
    <div>
      <button onClick={() => setShow(true)}>
        Load Heavy Component
      </button>
      {show && (
        <Suspense fallback={<Spinner />}>
          <HeavyComponent />
        </Suspense>
      )}
    </div>
  );
}
```

## Virtualization

For long lists, render only visible items:

```typescript
import { FixedSizeList } from 'react-window';

function VirtualizedList({ items }: { items: string[] }) {
  const Row = ({ index, style }: any) => (
    <div style={style}>
      Item {items[index]}
    </div>
  );

  return (
    <FixedSizeList
      height={400}
      itemCount={items.length}
      itemSize={50}
      width="100%"
    >
      {Row}
    </FixedSizeList>
  );
}
```

## Performance Metrics

Key metrics to track:

| Metric | Target | Description |
|--------|--------|-------------|
| **FCP** | < 1.8s | First Contentful Paint |
| **LCP** | < 2.5s | Largest Contentful Paint |
| **FID** | < 100ms | First Input Delay |
| **CLS** | < 0.1 | Cumulative Layout Shift |
| **TTI** | < 3.8s | Time to Interactive |

## Profiling Your App

Use React DevTools Profiler to identify bottlenecks:

```typescript
import { Profiler } from 'react';

function onRenderCallback(
  id: string,
  phase: 'mount' | 'update',
  actualDuration: number,
  baseDuration: number,
  startTime: number,
  commitTime: number
) {
  console.log(`${id} (${phase}) took ${actualDuration}ms`);
}

function App() {
  return (
    <Profiler id="App" onRender={onRenderCallback}>
      <YourComponent />
    </Profiler>
  );
}
```

> [!INFO]
> The Profiler API is designed for production use and has minimal overhead.

## Image Optimization

Optimize images for better performance:

```typescript
function OptimizedImage({ src, alt }: { src: string; alt: string }) {
  return (
    <picture>
      <source 
        srcSet={`${src}?w=400&fm=webp`} 
        type="image/webp" 
        media="(max-width: 640px)" 
      />
      <source 
        srcSet={`${src}?w=800&fm=webp`} 
        type="image/webp" 
        media="(max-width: 1024px)" 
      />
      <img 
        src={`${src}?w=1200`} 
        alt={alt} 
        loading="lazy"
        decoding="async"
      />
    </picture>
  );
}
```

## Bundle Analysis

Visualize your bundle size:

```bash
# Using webpack-bundle-analyzer
npm install --save-dev webpack-bundle-analyzer

# Add to webpack config
const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;

module.exports = {
  plugins: [
    new BundleAnalyzerPlugin()
  ]
};
```

## Performance Budget

Set and enforce performance budgets:

```json
{
  "budgets": [
    {
      "type": "bundle",
      "name": "main",
      "baseline": "500kb",
      "warning": "400kb",
      "error": "600kb"
    }
  ]
}
```

## Time Complexity Analysis

Understanding algorithm complexity helps choose efficient solutions:

$$
O(n) = \text{Linear time complexity}
$$

$$
O(n^2) = \text{Quadratic time complexity}
$$

$$
O(\log n) = \text{Logarithmic time complexity}
$$

## Best Practices Checklist

- [ ] Enable production builds for deployment
- [ ] Use React.memo for expensive components
- [ ] Implement code splitting for routes
- [ ] Virtualize long lists
- [ ] Optimize images (lazy loading, WebP)
- [ ] Minimize bundle size
- [ ] Use CDN for static assets
- [ ] Implement caching strategies
- [ ] Monitor Core Web Vitals
- [ ] Profile regularly during development

> [!SUCCESS]
> Following these practices will result in faster, more responsive React applications that provide better user experiences.

## Tools & Resources

- React DevTools Profiler
- Chrome DevTools Performance tab
- Lighthouse CI
- webpack-bundle-analyzer
- react-window / react-virtualized

## Related Posts

- [[Advanced TypeScript Patterns]]
- [[Web Performance Fundamentals]]
- [[State Management Best Practices]]
