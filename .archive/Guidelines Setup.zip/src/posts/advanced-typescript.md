---
title: Advanced TypeScript Patterns
subtitle: Mastering type-safe JavaScript
date: 2025-12-03
category: TypeScript
tags:
  - TypeScript
  - JavaScript
  - Programming
  - Type Safety
author: Vaults Team
excerpt: Dive deep into advanced TypeScript patterns including conditional types, mapped types, and template literal types.
coverImage: https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=1200&h=600&fit=crop
featured: true
draft: false
readingTime: 12
---

# Advanced TypeScript Patterns

TypeScript has evolved into a powerful type system that can express complex runtime behaviors at compile time. Let's explore some advanced patterns that will make your code more type-safe and maintainable.

## Conditional Types

Conditional types allow you to create types that depend on a condition:

```typescript
type IsString<T> = T extends string ? true : false;

type A = IsString<'hello'>; // true
type B = IsString<42>;      // false
```

### Practical Example: Extract Return Type

```typescript
type ReturnType<T> = T extends (...args: any[]) => infer R ? R : never;

function greet(): string {
  return 'Hello!';
}

type GreetReturn = ReturnType<typeof greet>; // string
```

> [!TIP]
> The `infer` keyword lets you capture and use types that appear in conditional type branches.

## Mapped Types

Mapped types allow you to create new types by transforming properties of existing types:

```typescript
type Readonly<T> = {
  readonly [P in keyof T]: T[P];
};

type User = {
  name: string;
  age: number;
};

type ReadonlyUser = Readonly<User>;
// { readonly name: string; readonly age: number; }
```

### Advanced Mapping: Deep Partial

```typescript
type DeepPartial<T> = {
  [P in keyof T]?: T[P] extends object
    ? DeepPartial<T[P]>
    : T[P];
};

type Config = {
  server: {
    port: number;
    host: string;
  };
  database: {
    url: string;
  };
};

type PartialConfig = DeepPartial<Config>;
// All properties are optional recursively
```

## Template Literal Types

Template literal types allow you to manipulate string literal types:

```typescript
type EventName = 'click' | 'focus' | 'blur';
type EventHandler = `on${Capitalize<EventName>}`;
// 'onClick' | 'onFocus' | 'onBlur'
```

### Building Type-Safe Routes

```typescript
type Route = '/users' | '/posts' | '/settings';
type RouteWithId = `${Route}/${string}`;

const validRoute: RouteWithId = '/users/123'; // ✅
const invalidRoute: RouteWithId = '/invalid/123'; // ❌
```

> [!WARNING]
> Template literal types can become complex quickly. Use them judiciously and document their purpose.

## Discriminated Unions

Discriminated unions (tagged unions) provide type-safe state management:

```typescript
type LoadingState = {
  status: 'loading';
};

type SuccessState<T> = {
  status: 'success';
  data: T;
};

type ErrorState = {
  status: 'error';
  error: Error;
};

type AsyncState<T> = LoadingState | SuccessState<T> | ErrorState;

function handleState<T>(state: AsyncState<T>) {
  switch (state.status) {
    case 'loading':
      return 'Loading...';
    case 'success':
      return `Data: ${state.data}`;
    case 'error':
      return `Error: ${state.error.message}`;
  }
}
```

## Architecture Diagram

```mermaid
graph TD
    A[TypeScript Source] --> B[Type Checker]
    B --> C{Valid?}
    C -->|Yes| D[JavaScript Output]
    C -->|No| E[Type Errors]
    D --> F[Runtime Execution]
    E --> G[Fix Types]
    G --> A
```

## Utility Types Reference

| Type | Description | Example |
|------|-------------|---------|
| `Partial<T>` | Makes all properties optional | `Partial<User>` |
| `Required<T>` | Makes all properties required | `Required<User>` |
| `Readonly<T>` | Makes all properties readonly | `Readonly<User>` |
| `Pick<T, K>` | Picks specific properties | `Pick<User, 'name'>` |
| `Omit<T, K>` | Omits specific properties | `Omit<User, 'age'>` |
| `Record<K, T>` | Creates an object type | `Record<string, number>` |

## Generic Constraints

Use constraints to limit what types can be used with generics:

```typescript
interface HasLength {
  length: number;
}

function logLength<T extends HasLength>(item: T): void {
  console.log(item.length);
}

logLength('hello');    // ✅ string has length
logLength([1, 2, 3]);  // ✅ array has length
logLength(123);        // ❌ number doesn't have length
```

## Performance Considerations

> [!INFO]
> TypeScript's type checking happens at compile time, so complex types don't affect runtime performance.

However, extremely complex types can slow down your IDE and compilation:

- Keep type complexity reasonable
- Use type aliases to break down complex types
- Consider using `any` or `unknown` for truly dynamic data

## Mathematical Type Theory

TypeScript's type system is based on structural typing, which can be expressed mathematically:

$$
T \subseteq U \iff \forall x \in T, x \in U
$$

This means type $T$ is assignable to type $U$ if every value in $T$ is also in $U$.

## Best Practices

1. **Use strict mode**: Always enable `strict: true` in `tsconfig.json`
2. **Prefer interfaces for objects**: Interfaces are more performant for object types
3. **Use `unknown` over `any`**: `unknown` is type-safe, `any` is not
4. **Leverage inference**: Let TypeScript infer types when possible
5. **Document complex types**: Add JSDoc comments for maintainability

> [!SUCCESS]
> Mastering these patterns will make you a more effective TypeScript developer and help you write safer, more maintainable code.

## Further Reading

- TypeScript Handbook: Advanced Types
- Type-Level Programming in TypeScript
- Building Type-Safe APIs

## Related Posts

- [[React TypeScript Patterns]]
- [[Type-Safe State Management]]
- [[Generic Programming]]
