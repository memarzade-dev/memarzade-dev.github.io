import { useState, useEffect, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search as SearchIcon, X } from 'lucide-react';
import { PostCard } from '../components/PostCard';
import { mockPosts } from '../data/mockPosts';
import { searchPosts } from '../utils/search';

export function Search() {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialQuery = searchParams.get('q') || '';
  const [query, setQuery] = useState(initialQuery);

  // Update query from URL params
  useEffect(() => {
    const urlQuery = searchParams.get('q') || '';
    setQuery(urlQuery);
  }, [searchParams]);

  // Perform search
  const results = useMemo(() => {
    if (!query.trim()) {
      return mockPosts;
    }
    return searchPosts(query, mockPosts);
  }, [query]);

  // Handle search input
  const handleSearch = (value: string) => {
    setQuery(value);
    if (value.trim()) {
      setSearchParams({ q: value });
    } else {
      setSearchParams({});
    }
  };

  const handleClear = () => {
    setQuery('');
    setSearchParams({});
  };

  return (
    <div className="min-h-screen">
      {/* Search Header */}
      <div className="bg-vault-bg-surface border-b border-vault-border-subtle sticky top-0 z-10">
        <div className="max-w-content-wide mx-auto px-4 py-8">
          <h1 className="text-h1 mb-6">Search</h1>

          {/* Search Input */}
          <div className="relative max-w-2xl">
            <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-vault-text-muted" />
            <input
              type="text"
              value={query}
              onChange={(e) => handleSearch(e.target.value)}
              placeholder="Search posts, tags, categories..."
              className="w-full pl-12 pr-12 py-4 bg-vault-bg-elevated border border-vault-border-subtle rounded-lg text-vault-text-primary placeholder:text-vault-text-muted focus:outline-none focus:border-vault-accent-primary transition-colors"
              autoFocus
            />
            {query && (
              <button
                onClick={handleClear}
                className="absolute right-4 top-1/2 -translate-y-1/2 p-1 hover:bg-vault-bg-base rounded transition-colors"
                aria-label="Clear search"
              >
                <X className="w-5 h-5 text-vault-text-muted" />
              </button>
            )}
          </div>

          {/* Results Count */}
          <div className="mt-4 text-vault-text-secondary">
            {query ? (
              <>
                Found <span className="text-vault-accent-primary font-semibold">{results.length}</span>{' '}
                {results.length === 1 ? 'result' : 'results'} for &quot;{query}&quot;
              </>
            ) : (
              <>Showing all <span className="text-vault-accent-primary font-semibold">{results.length}</span> posts</>
            )}
          </div>
        </div>
      </div>

      {/* Search Results */}
      <div className="max-w-content-wide mx-auto px-4 py-section-md">
        {results.length === 0 ? (
          <div className="text-center py-16">
            <SearchIcon className="w-16 h-16 text-vault-text-muted mx-auto mb-4" />
            <h2 className="text-h2 mb-2">No results found</h2>
            <p className="text-vault-text-secondary">
              Try adjusting your search terms or browse all posts below
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {results.map((post) => (
              <PostCard
                key={post.slug}
                post={post}
                variant="default"
                showImage={true}
                showExcerpt={true}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// Default export for lazy loading
export default Search;