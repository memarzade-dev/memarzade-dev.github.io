import { Bookmark, Trash2 } from 'lucide-react';
import { PostCard } from '../components/PostCard';
import { Button } from '../components/Button';
import { useBookmarks } from '../hooks/useBookmarks';
import { mockPosts } from '../data/mockPosts';

export function Bookmarks() {
  const { bookmarks, removeBookmark } = useBookmarks();

  const bookmarkedPosts = mockPosts.filter((post) =>
    bookmarks.includes(post.slug)
  );

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-vault-bg-surface border-b border-vault-border-subtle">
        <div className="max-w-content-wide mx-auto px-4 py-section-sm">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-3 bg-vault-accent-primary/10 rounded-lg border border-vault-accent-primary/20">
              <Bookmark className="w-6 h-6 text-vault-accent-primary" />
            </div>
            <h1 className="text-display">Bookmarks</h1>
          </div>
          <p className="text-vault-text-secondary text-lg">
            Your saved articles for later reading • {bookmarkedPosts.length} bookmark
            {bookmarkedPosts.length !== 1 ? 's' : ''}
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-content-wide mx-auto px-4 py-section-md">
        {bookmarkedPosts.length === 0 ? (
          <div className="text-center py-16">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-vault-bg-elevated rounded-full border border-vault-border-subtle mb-4">
              <Bookmark className="w-8 h-8 text-vault-text-muted" />
            </div>
            <h2 className="text-h2 mb-2">No bookmarks yet</h2>
            <p className="text-vault-text-secondary mb-6">
              Start bookmarking posts to save them for later
            </p>
            <Button as="a" href="/">
              Browse Posts
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {bookmarkedPosts.map((post) => (
              <div key={post.slug} className="relative group">
                <PostCard post={post} />
                <button
                  onClick={() => removeBookmark(post.slug)}
                  className="absolute top-4 right-4 p-2 bg-vault-bg-surface/90 backdrop-blur-sm border border-vault-border-subtle rounded-lg opacity-0 group-hover:opacity-100 transition-opacity hover:bg-vault-danger hover:border-vault-danger hover:text-white"
                  aria-label="Remove bookmark"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// Default export for lazy loading
export default Bookmarks;