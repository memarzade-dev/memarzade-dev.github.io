import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Tag } from 'lucide-react';
import { Button } from '../components/Button';
import { PostCard } from '../components/PostCard';
import { useMarkdownPosts } from '../hooks/useMarkdownPosts';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { mockPosts } from '../data/mockPosts';

export function TagDetail() {
  const { tag } = useParams<{ tag: string }>();
  const navigate = useNavigate();
  const { posts: markdownPosts, loading } = useMarkdownPosts();

  if (!tag) {
    return <div>Tag not found</div>;
  }

  // Use markdown posts if available, otherwise fall back to mock posts
  const allPosts = markdownPosts.length > 0 ? markdownPosts : mockPosts;

  // Filter posts by tag
  const posts = allPosts.filter(post => 
    post.tags?.some(t => t.toLowerCase() === tag.toLowerCase())
  );

  // Get display name for tag (capitalize first letter)
  const tagDisplayName = tag
    .split('-')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-vault-bg-surface border-b border-vault-border-subtle">
        <div className="max-w-content-wide mx-auto px-4 py-12">
          <Button
            variant="ghost"
            onClick={() => navigate('/tags')}
            className="gap-2 mb-6"
          >
            <ArrowLeft className="w-4 h-4" />
            All Tags
          </Button>

          <div className="flex items-start gap-4">
            <div className="p-4 bg-vault-accent-secondary/10 rounded-lg border border-vault-accent-secondary/20">
              <Tag className="w-8 h-8 text-vault-accent-secondary" />
            </div>
            <div>
              <h1 className="text-display mb-2">{tagDisplayName}</h1>
              <p className="text-vault-text-secondary">
                {posts.length} {posts.length === 1 ? 'post' : 'posts'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Posts */}
      <div className="max-w-content-wide mx-auto px-4 py-section-md">
        {posts.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-vault-text-secondary">
              No posts with this tag yet.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {posts.map((post) => (
              <PostCard
                key={post.slug}
                post={post}
                variant="default"
                showImage={true}
                showExcerpt={true}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// Default export for lazy loading
export default TagDetail;
