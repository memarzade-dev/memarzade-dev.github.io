import { useState } from 'react';
import { Network, Filter } from 'lucide-react';
import { KnowledgeGraph } from '../components/KnowledgeGraph';
import { mockPosts, getAllCategories } from '../data/mockPosts';

export function Graph() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const categories = getAllCategories();

  const filteredPosts = selectedCategory
    ? mockPosts.filter((post) => post.categorySlug === selectedCategory)
    : mockPosts;

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-vault-bg-surface border-b border-vault-border-subtle">
        <div className="max-w-content-wide mx-auto px-4 py-section-sm">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-3 bg-vault-accent-primary/10 rounded-lg border border-vault-accent-primary/20">
              <Network className="w-6 h-6 text-vault-accent-primary" />
            </div>
            <h1 className="text-display">Knowledge Graph</h1>
          </div>
          <p className="text-vault-text-secondary text-lg mb-6">
            Explore the connections between posts • Nodes are sized by relationships • Click any node to navigate
          </p>

          {/* Filter */}
          <div className="flex items-center gap-3">
            <Filter className="w-4 h-4 text-vault-text-muted" />
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setSelectedCategory(null)}
                className={`px-3 py-1.5 text-sm rounded-full border transition-all ${
                  selectedCategory === null
                    ? 'bg-vault-accent-primary text-vault-text-inverted border-vault-accent-primary'
                    : 'bg-vault-bg-elevated text-vault-text-secondary border-vault-border-subtle hover:border-vault-accent-primary'
                }`}
              >
                All Categories
              </button>
              {categories.map((category) => (
                <button
                  key={category.slug}
                  onClick={() => setSelectedCategory(category.slug)}
                  className={`px-3 py-1.5 text-sm rounded-full border transition-all ${
                    selectedCategory === category.slug
                      ? 'bg-vault-accent-primary text-vault-text-inverted border-vault-accent-primary'
                      : 'bg-vault-bg-elevated text-vault-text-secondary border-vault-border-subtle hover:border-vault-accent-primary'
                  }`}
                >
                  {category.name}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Graph */}
      <div className="max-w-content-wide mx-auto px-4 py-section-md">
        <KnowledgeGraph posts={filteredPosts} height={700} />

        {/* Info */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-vault-bg-surface p-6 rounded-lg border border-vault-border-subtle">
            <div className="text-2xl font-bold text-vault-accent-primary mb-2">
              {filteredPosts.length}
            </div>
            <div className="text-vault-text-secondary">Total Posts</div>
          </div>

          <div className="bg-vault-bg-surface p-6 rounded-lg border border-vault-border-subtle">
            <div className="text-2xl font-bold text-vault-accent-secondary mb-2">
              {categories.length}
            </div>
            <div className="text-vault-text-secondary">Categories</div>
          </div>

          <div className="bg-vault-bg-surface p-6 rounded-lg border border-vault-border-subtle">
            <div className="text-2xl font-bold text-vault-info mb-2">
              {Array.from(new Set(mockPosts.flatMap((p) => p.tags))).length}
            </div>
            <div className="text-vault-text-secondary">Unique Tags</div>
          </div>
        </div>

        {/* How to Use */}
        <div className="mt-8 bg-vault-bg-surface/50 p-6 rounded-lg border border-vault-border-subtle">
          <h2 className="text-h3 mb-4">How to Use the Knowledge Graph</h2>
          <ul className="space-y-2 text-vault-text-secondary">
            <li className="flex items-start gap-2">
              <span className="text-vault-accent-primary mt-1">•</span>
              <span><strong>Click</strong> on any node to navigate to that post</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-vault-accent-primary mt-1">•</span>
              <span><strong>Drag</strong> the canvas to pan around</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-vault-accent-primary mt-1">•</span>
              <span><strong>Zoom</strong> using the controls or scroll wheel</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-vault-accent-primary mt-1">•</span>
              <span><strong>Connections</strong> represent shared categories or tags</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-vault-accent-primary mt-1">•</span>
              <span><strong>Filter</strong> by category to focus on specific topics</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}

// Default export for lazy loading
export default Graph;