import { useNavigate } from 'react-router-dom';
import { Folder, ChevronRight } from 'lucide-react';
import { mockCategories } from '../data/mockPosts';

export function Categories() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-vault-bg-surface border-b border-vault-border-subtle">
        <div className="max-w-content-wide mx-auto px-4 py-section-sm">
          <h1 className="text-display mb-3">Categories</h1>
          <p className="text-vault-text-secondary text-lg">
            Explore posts organized by topic and technology
          </p>
        </div>
      </div>

      {/* Categories Grid */}
      <div className="max-w-content-wide mx-auto px-4 py-section-md">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {mockCategories.map((category) => (
            <div
              key={category.slug}
              className="bg-vault-bg-elevated border border-vault-border-subtle rounded-lg p-6 hover:border-vault-accent-primary transition-all cursor-pointer group"
              onClick={() => navigate(`/categories/${category.slug}`)}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-vault-accent-primary/10 rounded-lg border border-vault-accent-primary/20 group-hover:bg-vault-accent-primary/20 transition-all">
                    <Folder className="w-6 h-6 text-vault-accent-primary" />
                  </div>
                  <div>
                    <h2 className="text-h3 mb-2 group-hover:text-vault-accent-primary transition-colors">
                      {category.name}
                    </h2>
                    <p className="text-vault-text-muted">
                      {category.count} {category.count === 1 ? 'post' : 'posts'}
                    </p>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-vault-text-muted group-hover:text-vault-accent-primary group-hover:translate-x-1 transition-all" />
              </div>

              {/* Subcategories */}
              {category.children && category.children.length > 0 && (
                <div className="mt-4 pt-4 border-t border-vault-border-subtle">
                  <div className="flex flex-wrap gap-2">
                    {category.children.map((child) => (
                      <div
                        key={child.slug}
                        onClick={(e) => {
                          e.stopPropagation();
                          navigate(`/categories/${child.slug}`);
                        }}
                        className="px-3 py-1 text-sm bg-vault-bg-base text-vault-text-secondary rounded-full border border-vault-border-subtle hover:border-vault-accent-primary hover:text-vault-accent-primary transition-all"
                      >
                        {child.name}
                        <span className="ml-1 text-vault-text-muted">({child.count})</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// Default export for lazy loading
export default Categories;