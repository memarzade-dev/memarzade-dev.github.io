import { useMemo } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Tag, Hash } from 'lucide-react';
import { PostCard } from '../components/PostCard';
import { mockPosts } from '../data/mockPosts';

interface TagWithCount {
  name: string;
  count: number;
  posts: typeof mockPosts;
}

export function Tags() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const selectedTag = searchParams.get('tag');

  // Generate tags with counts
  const allTags = useMemo(() => {
    const tagMap = new Map<string, typeof mockPosts>();

    mockPosts.forEach((post) => {
      post.tags.forEach((tag) => {
        const existing = tagMap.get(tag) || [];
        tagMap.set(tag, [...existing, post]);
      });
    });

    const tags: TagWithCount[] = Array.from(tagMap.entries())
      .map(([name, posts]) => ({
        name,
        count: posts.length,
        posts,
      }))
      .sort((a, b) => b.count - a.count); // Sort by count descending

    return tags;
  }, []);

  const selectedTagData = useMemo(() => {
    return allTags.find((tag) => tag.name === selectedTag);
  }, [allTags, selectedTag]);

  const handleTagClick = (tagName: string) => {
    if (selectedTag === tagName) {
      setSearchParams({});
    } else {
      setSearchParams({ tag: tagName });
    }
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-vault-bg-surface border-b border-vault-border-subtle">
        <div className="max-w-content-wide mx-auto px-4 py-section-sm">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-3 bg-vault-accent-secondary/10 rounded-lg border border-vault-accent-secondary/20">
              <Hash className="w-6 h-6 text-vault-accent-secondary" />
            </div>
            <h1 className="text-display">Tags</h1>
          </div>
          <p className="text-vault-text-secondary text-lg">
            Browse posts by tags • {allTags.length} total tags
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-content-wide mx-auto px-4 py-section-md">
        {/* Tags Cloud */}
        <div className="mb-12">
          <h2 className="text-h2 mb-6">All Tags</h2>
          <div className="flex flex-wrap gap-3">
            {allTags.map((tag) => {
              const isSelected = selectedTag === tag.name;
              const size = Math.min(Math.max(tag.count, 1), 10);
              const fontSize = `${0.875 + (size * 0.125)}rem`; // Scale from 0.875rem to ~2rem

              return (
                <button
                  key={tag.name}
                  onClick={() => handleTagClick(tag.name)}
                  className={`inline-flex items-center gap-2 px-4 py-2 rounded-full border transition-all hover:scale-105 ${
                    isSelected
                      ? 'bg-vault-accent-primary text-vault-text-inverted border-vault-accent-primary shadow-glow-primary'
                      : 'bg-vault-bg-elevated text-vault-text-secondary border-vault-border-subtle hover:border-vault-accent-primary hover:text-vault-accent-primary'
                  }`}
                  style={{ fontSize }}
                >
                  <Tag className="w-4 h-4" />
                  {tag.name}
                  <span
                    className={`text-xs px-2 py-0.5 rounded-full ${
                      isSelected
                        ? 'bg-vault-text-inverted/20'
                        : 'bg-vault-bg-base text-vault-text-muted'
                    }`}
                  >
                    {tag.count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Filtered Posts */}
        {selectedTagData && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-h2">
                Posts tagged &quot;{selectedTagData.name}&quot;
              </h2>
              <button
                onClick={() => setSearchParams({})}
                className="text-vault-text-secondary hover:text-vault-text-primary transition-colors underline"
              >
                Clear filter
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {selectedTagData.posts.map((post) => (
                <PostCard
                  key={post.slug}
                  post={post}
                  variant="default"
                  showImage={true}
                  showExcerpt={true}
                />
              ))}
            </div>
          </div>
        )}

        {/* All Posts (when no filter) */}
        {!selectedTag && (
          <div>
            <h2 className="text-h2 mb-6">All Posts</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {mockPosts.map((post) => (
                <PostCard
                  key={post.slug}
                  post={post}
                  variant="default"
                  showImage={true}
                  showExcerpt={true}
                />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// Default export for lazy loading
export default Tags;