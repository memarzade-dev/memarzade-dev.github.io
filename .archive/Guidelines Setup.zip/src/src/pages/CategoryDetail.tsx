import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Folder } from 'lucide-react';
import { Button } from '../components/Button';
import { PostCard } from '../components/PostCard';
import { mockCategories, getPostsByCategory } from '../data/mockPosts';

export function CategoryDetail() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();

  if (!slug) {
    return <div>Category not found</div>;
  }

  // Find category (check both top-level and nested categories)
  let category = mockCategories.find(cat => cat.slug === slug);
  let parentCategory: typeof category | undefined;

  if (!category) {
    // Check nested categories
    for (const cat of mockCategories) {
      if (cat.children) {
        const nested = cat.children.find(child => child.slug === slug);
        if (nested) {
          category = nested;
          parentCategory = cat;
          break;
        }
      }
    }
  }

  if (!category) {
    return (
      <div className="max-w-content mx-auto px-4 py-16 text-center">
        <h1 className="text-h1 mb-4">Category Not Found</h1>
        <p className="text-vault-text-secondary mb-8">
          The category you're looking for doesn't exist.
        </p>
        <Button onClick={() => navigate('/')}>Return Home</Button>
      </div>
    );
  }

  const posts = getPostsByCategory(slug);

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-vault-bg-surface border-b border-vault-border-subtle">
        <div className="max-w-content-wide mx-auto px-4 py-12">
          <Button
            variant="ghost"
            onClick={() => navigate('/categories')}
            className="gap-2 mb-6"
          >
            <ArrowLeft className="w-4 h-4" />
            All Categories
          </Button>

          <div className="flex items-start gap-4">
            <div className="p-4 bg-vault-accent-primary/10 rounded-lg border border-vault-accent-primary/20">
              <Folder className="w-8 h-8 text-vault-accent-primary" />
            </div>
            <div>
              {parentCategory && (
                <div className="text-sm text-vault-text-muted mb-2">
                  {parentCategory.name}
                </div>
              )}
              <h1 className="text-display mb-2">{category.name}</h1>
              <p className="text-vault-text-secondary">
                {category.count} {category.count === 1 ? 'post' : 'posts'}
              </p>
            </div>
          </div>

          {/* Subcategories */}
          {category.children && category.children.length > 0 && (
            <div className="mt-8">
              <h2 className="text-h3 mb-4">Subcategories</h2>
              <div className="flex flex-wrap gap-3">
                {category.children.map((child) => (
                  <Button
                    key={child.slug}
                    variant="outline"
                    onClick={() => navigate(`/categories/${child.slug}`)}
                    className="gap-2"
                  >
                    <Folder className="w-4 h-4" />
                    {child.name}
                    <span className="text-vault-text-muted">({child.count})</span>
                  </Button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Posts */}
      <div className="max-w-content-wide mx-auto px-4 py-section-md">
        {posts.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-vault-text-secondary">
              No posts in this category yet.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {posts.map((post) => (
              <PostCard
                key={post.slug}
                post={post}
                variant="default"
                showImage={true}
                showExcerpt={true}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// Default export for lazy loading
export default CategoryDetail;