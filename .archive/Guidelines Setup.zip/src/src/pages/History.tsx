import { History as HistoryIcon, Trash2, Clock } from 'lucide-react';
import { Link } from '../components/Link';
import { Button } from '../components/Button';
import { useReadingHistory } from '../hooks/useReadingHistory';

export function History() {
  const { history, clearHistory, removeFromHistory } = useReadingHistory();

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);

    if (diffInSeconds < 60) return 'Just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} minutes ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} hours ago`;
    if (diffInSeconds < 604800) return `${Math.floor(diffInSeconds / 86400)} days ago`;
    
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined,
    });
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-vault-bg-surface border-b border-vault-border-subtle">
        <div className="max-w-content-wide mx-auto px-4 py-section-sm">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-vault-accent-primary/10 rounded-lg border border-vault-accent-primary/20">
                <HistoryIcon className="w-6 h-6 text-vault-accent-primary" />
              </div>
              <h1 className="text-display">Reading History</h1>
            </div>
            {history.length > 0 && (
              <Button
                variant="ghost"
                onClick={clearHistory}
                className="text-vault-danger hover:bg-vault-danger/10"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Clear All
              </Button>
            )}
          </div>
          <p className="text-vault-text-secondary text-lg">
            Recently read articles • {history.length} item{history.length !== 1 ? 's' : ''}
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-content-wide mx-auto px-4 py-section-md">
        {history.length === 0 ? (
          <div className="text-center py-16">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-vault-bg-elevated rounded-full border border-vault-border-subtle mb-4">
              <HistoryIcon className="w-8 h-8 text-vault-text-muted" />
            </div>
            <h2 className="text-h2 mb-2">No reading history</h2>
            <p className="text-vault-text-secondary mb-6">
              Your recently read posts will appear here
            </p>
            <Button as="a" href="/">
              Start Reading
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {history.map((item) => (
              <div
                key={item.slug}
                className="flex items-center justify-between p-4 bg-vault-bg-surface border border-vault-border-subtle rounded-lg hover:border-vault-accent-primary transition-all group"
              >
                <div className="flex-1 min-w-0">
                  <Link
                    to={`/posts/${item.slug}`}
                    className="text-vault-text-primary hover:text-vault-accent-primary font-medium block truncate mb-1"
                  >
                    {item.title}
                  </Link>
                  <div className="flex items-center gap-3 text-sm text-vault-text-muted">
                    <div className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      {formatDate(item.timestamp)}
                    </div>
                    {item.scrollProgress !== undefined && item.scrollProgress > 0 && (
                      <div className="flex items-center gap-2">
                        <div className="w-24 h-1.5 bg-vault-bg-elevated rounded-full overflow-hidden">
                          <div
                            className="h-full bg-vault-accent-primary rounded-full transition-all"
                            style={{ width: `${item.scrollProgress}%` }}
                          />
                        </div>
                        <span className="text-xs">{Math.round(item.scrollProgress)}%</span>
                      </div>
                    )}
                  </div>
                </div>
                <button
                  onClick={() => removeFromHistory(item.slug)}
                  className="ml-4 p-2 text-vault-text-muted hover:text-vault-danger hover:bg-vault-danger/10 rounded transition-all opacity-0 group-hover:opacity-100"
                  aria-label="Remove from history"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// Default export for lazy loading
export default History;