import { Code, Layers, Network, Search, Folder, Hash } from 'lucide-react';
import { Button } from '../components/Button';
import { Link } from '../components/Link';
import { PostCard } from '../components/PostCard';
import { getFeaturedPosts, getRecentPosts } from '../data/mockPosts';

export function Home() {
  const featuredPosts = getFeaturedPosts();
  const recentPosts = getRecentPosts(6);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-section-lg bg-gradient-hero">
        <div className="max-w-content mx-auto text-center px-4">
          <h1 className="text-display gradient-text mb-6">
            Vaults
          </h1>
          <p className="text-h4 text-vault-text-secondary mb-8 max-w-content mx-auto">
            Daily research notes from a software engineer exploring AI, distributed systems, and modern tooling
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link to="/categories" variant="button">
              Browse Categories
            </Link>
            <Link to="/graph" variant="button">
              Explore Knowledge Graph
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-section-sm">
        <div className="max-w-content-wide mx-auto px-4">
          <h2 className="text-h2 mb-8 text-center">What You'll Find Here</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-vault-bg-surface p-6 rounded-lg border border-vault-border-subtle hover:border-vault-accent-primary hover:shadow-card-hover transition-all duration-300">
              <div className="w-12 h-12 bg-vault-accent-primary/10 rounded-lg flex items-center justify-center mb-4">
                <Code className="w-6 h-6 text-vault-accent-primary" />
              </div>
              <h3 className="text-h4 mb-3">Technical Deep Dives</h3>
              <p className="text-vault-text-secondary">
                In-depth explorations of AI, machine learning, neural networks, and cutting-edge development practices
              </p>
            </div>

            <div className="bg-vault-bg-surface p-6 rounded-lg border border-vault-border-subtle hover:border-vault-accent-primary hover:shadow-card-hover transition-all duration-300">
              <div className="w-12 h-12 bg-vault-accent-secondary/10 rounded-lg flex items-center justify-center mb-4">
                <Layers className="w-6 h-6 text-vault-accent-secondary" />
              </div>
              <h3 className="text-h4 mb-3">System Design</h3>
              <p className="text-vault-text-secondary">
                Distributed systems, microservices, consensus algorithms, and scalable architecture patterns
              </p>
            </div>

            <div className="bg-vault-bg-surface p-6 rounded-lg border border-vault-border-subtle hover:border-vault-accent-primary hover:shadow-card-hover transition-all duration-300">
              <div className="w-12 h-12 bg-vault-info/10 rounded-lg flex items-center justify-center mb-4">
                <Network className="w-6 h-6 text-vault-info" />
              </div>
              <h3 className="text-h4 mb-3">Interconnected Knowledge</h3>
              <p className="text-vault-text-secondary">
                Explore topics through an interactive knowledge graph with nested categories and rich internal links
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Posts Section */}
      {featuredPosts.length > 0 && (
        <section className="py-section-md bg-vault-bg-surface/50">
          <div className="max-w-container mx-auto px-4">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-h2">Featured Posts</h2>
              <Link to="/posts" variant="default">
                View All →
              </Link>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredPosts.map((post) => (
                <PostCard 
                  key={post.slug}
                  post={post}
                  variant="default"
                  showImage={true}
                  showExcerpt={true}
                />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Recent Posts Section */}
      <section className="py-section-md">
        <div className="max-w-container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-h2">Recent Posts</h2>
            <Link to="/posts" variant="default">
              View All →
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {recentPosts.map((post) => (
              <PostCard 
                key={post.slug}
                post={post}
                variant="default"
                showImage={true}
                showExcerpt={true}
              />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-section-md">
        <div className="max-w-content mx-auto px-4 text-center bg-gradient-hero p-8 rounded-2xl border border-vault-border-subtle">
          <h2 className="text-h2 mb-4">Start Exploring</h2>
          <p className="text-vault-text-secondary mb-6 max-w-content-narrow mx-auto">
            Browse through categories, search for specific topics, or explore tags to discover connections
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link to="/categories" variant="button" className="gap-2">
              <Folder className="w-4 h-4" />
              Browse Categories
            </Link>
            <Link to="/search" variant="button" className="gap-2">
              <Search className="w-4 h-4" />
              Search Posts
            </Link>
            <Link to="/tags" variant="button" className="gap-2">
              <Hash className="w-4 h-4" />
              Explore Tags
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

// Default export for lazy loading
export default Home;