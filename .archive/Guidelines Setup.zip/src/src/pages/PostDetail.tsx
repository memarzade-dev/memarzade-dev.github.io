import { useParams, useNavigate } from 'react-router-dom';
import { useRef, useState, useEffect } from 'react';
import { 
  Calendar, 
  Clock, 
  Tag, 
  ArrowLeft, 
  BookOpen, 
  Eye, 
  Type, 
  SunMedium 
} from 'lucide-react';
import { BookmarkButton } from '../components/BookmarkButton';
import { ViewCounter } from '../components/ViewCounter';
import { SEO } from '../components/SEO';
import { trackPostView } from '../components/Analytics';
import { getPostBySlug, mockPosts } from '../data/mockPosts';
import { detectTextDirection } from '../utils/rtl';
import { useReadingHistory } from '../hooks/useReadingHistory';
import { MarkdownRenderer } from '../components/MarkdownRenderer';
import { SocialShare } from '../components/SocialShare';
import { Link } from '../components/Link';
import { ReadingProgress } from '../components/ReadingProgress';
import { TableOfContents } from '../components/TableOfContents';
import { RelatedPosts } from '../components/RelatedPosts';
import { Button } from '../components/Button';

type ReadingModeType = 'default' | 'focus' | 'wide';

// Sample markdown content
const sampleMarkdown = `
# Introduction

This is a comprehensive guide to understanding advanced concepts in software engineering. We'll explore various patterns, best practices, and real-world applications.

## Key Concepts

Here are some important things to remember:

> [!tip] Pro Tip
> Always write clean, maintainable code. Your future self will thank you!

### Code Examples

Here's a simple TypeScript example:

\`\`\`typescript
interface User {
  id: string;
  name: string;
  email: string;
}

function getUserById(id: string): User | null {
  // Implementation
  return null;
}
\`\`\`

### Important Notes

> [!warning] Performance Consideration
> This operation has O(n²) complexity. Consider optimizing for large datasets.

## Advanced Topics

Let's dive deeper into some advanced concepts:

1. **Design Patterns**: Essential for scalable architecture
2. **Testing**: Critical for production reliability
3. **Performance**: Always measure before optimizing

## Features

- Clean architecture
- Type safety
- Performance optimization
- Comprehensive testing

> [!example] Real-World Example
> In a production system, we implemented this pattern and saw a 40% improvement in response times.

## Tables

| Feature | Description | Status |
|---------|-------------|--------|
| Type Safety | Full TypeScript support | ✅ Complete |
| Testing | Unit and integration tests | ✅ Complete |
| Documentation | Comprehensive guides | 🚧 In Progress |

## Best Practices

> [!note] Important
> Following these best practices will help you build more maintainable applications.

### Code Quality

Always prioritize:

- **Readability**: Code is read more often than written
- **Testability**: Write testable code from the start
- **Maintainability**: Think about future developers

> [!success] Summary
> By following these principles, you'll build robust, maintainable applications that scale well.

For more information, check out our other posts on [[System Design]] and [[Performance Optimization]].
`;

export function PostDetail() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const contentRef = useRef<HTMLDivElement>(null);
  const [readingMode, setReadingMode] = useState<ReadingModeType>('default');

  if (!slug) {
    return <div>Post not found</div>;
  }

  const post = getPostBySlug(slug);

  if (!post) {
    return (
      <div className="max-w-content mx-auto px-4 py-16 text-center">
        <h1 className="text-h1 mb-4">Post Not Found</h1>
        <p className="text-vault-text-secondary mb-8">
          The post you're looking for doesn't exist.
        </p>
        <Button onClick={() => navigate('/')}>Return Home</Button>
      </div>
    );
  }

  const direction = detectTextDirection(post.title);
  const isRTL = direction === 'rtl';

  // Get related posts (same category, excluding current post)
  const relatedPosts = mockPosts
    .filter(p => p.categorySlug === post.categorySlug && p.slug !== post.slug)
    .slice(0, 3);

  // Format date
  const formattedDate = new Date(post.date).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  // Add post to reading history
  const { addToHistory } = useReadingHistory();
  useEffect(() => {
    addToHistory(post.slug, post.title);
  }, [post.slug, post.title, addToHistory]);

  // Track post view
  useEffect(() => {
    trackPostView(post.slug);
  }, [post.slug]);

  return (
    <div className="min-h-screen">
      {/* SEO Meta Tags */}
      <SEO
        title={post.title}
        description={post.subtitle || post.excerpt}
        keywords={post.tags}
        type="article"
        image={post.coverImage}
        url={`https://vaults.memarzade.dev/posts/${post.slug}`}
        publishedTime={post.date}
        tags={post.tags}
        section={post.category}
      />

      {/* Reading Progress */}
      <ReadingProgress />
      
      {/* Back Button */}
      <div className="max-w-content mx-auto px-4 py-4">
        <Button
          variant="ghost"
          onClick={() => navigate(-1)}
          className="gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </Button>
      </div>

      {/* Cover Image */}
      {post.coverImage && (
        <div className="w-full h-[400px] relative overflow-hidden">
          <img
            src={post.coverImage}
            alt={post.coverAlt || post.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-vault-bg-base via-vault-bg-base/60 to-transparent" />
        </div>
      )}

      {/* Post Header */}
      <article className="max-w-content mx-auto px-4 py-8">
        <div className="mb-8">
          {/* Category */}
          <Link
            to={`/categories/${post.categorySlug}`}
            className="text-vault-accent-primary text-sm mb-3 inline-block"
          >
            {post.category}
          </Link>

          {/* Title */}
          <h1
            className="text-display mb-4 text-vault-text-primary"
            dir={isRTL ? 'rtl' : 'ltr'}
            style={{ fontFamily: isRTL ? 'var(--font-rtl)' : 'var(--font-heading)' }}
          >
            {post.title}
          </h1>

          {/* Subtitle */}
          {post.subtitle && (
            <p className="text-h4 text-vault-text-secondary mb-6">
              {post.subtitle}
            </p>
          )}

          {/* Metadata */}
          <div className="flex flex-wrap items-center gap-4 text-vault-text-muted mb-6 pb-6 border-b border-vault-border-subtle">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              <time dateTime={post.date}>{formattedDate}</time>
            </div>

            {post.readingTimeMinutes && (
              <>
                <span className="text-vault-border-default">•</span>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  <span>{post.readingTimeMinutes} min read</span>
                </div>
              </>
            )}

            <span className="text-vault-border-default">•</span>
            <ViewCounter slug={post.slug} />

            <div className="ml-auto flex items-center gap-2">
              <BookmarkButton slug={post.slug} />
              <SocialShare
                title={post.title}
                url={`https://example.com/posts/${post.slug}`}
              />
            </div>
          </div>

          {/* Tags */}
          {post.tags.length > 0 && (
            <div className="flex flex-wrap items-center gap-2 mb-8">
              <Tag className="w-4 h-4 text-vault-text-muted" />
              {post.tags.map((tag) => (
                <Link
                  key={tag}
                  to={`/tags?tag=${tag}`}
                  className="px-3 py-1 text-sm bg-vault-bg-elevated text-vault-text-secondary rounded-full border border-vault-border-subtle hover:border-vault-accent-primary hover:text-vault-accent-primary transition-all no-underline"
                >
                  #{tag}
                </Link>
              ))}
            </div>
          )}
        </div>
      </article>

      {/* Main Content Area with TOC */}
      <div className="max-w-container-full mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_280px] gap-8">
          {/* Post Content */}
          <div ref={contentRef} className="min-w-0">
            <MarkdownRenderer content={post.content || sampleMarkdown} />
          </div>

          {/* Table of Contents Sidebar (Desktop) */}
          <aside className="hidden lg:block">
            <TableOfContents contentRef={contentRef} sticky={true} />
          </aside>
        </div>
      </div>

      {/* Related Posts using new component */}
      <section className="bg-vault-bg-surface/50 py-section-md mt-16">
        <div className="max-w-content-wide mx-auto px-4">
          <RelatedPosts
            currentPost={post}
            allPosts={mockPosts}
            maxPosts={3}
          />
        </div>
      </section>
    </div>
  );
}

// Default export for lazy loading
export default PostDetail;