/**
 * Hooks Index - نقطه ورود مرکزی برای تمام custom hooks
 * 
 * این فایل تمام custom hooks را export می‌کند
 * 
 * @example
 * import { useBookmarks, useViewCount } from '@/hooks';
 */

// View Count Hook
export { useViewCount } from './useViewCount';

// Bookmarks Hook
export { useBookmarks } from './useBookmarks';

// Reading History Hook
export { useReadingHistory } from './useReadingHistory';

// Markdown Posts Hooks
export {
  useMarkdownPosts,
  useMarkdownPost,
  usePostsByCategory,
  usePostsByTag,
  useFeaturedPosts,
} from './useMarkdownPosts';
