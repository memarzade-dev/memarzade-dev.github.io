// Hook to load markdown posts from /posts directory
import { useState, useEffect } from 'react';
import { loadAllMarkdownFiles, loadMarkdownFile, type MarkdownPost } from '../utils/markdownLoader';

/**
 * Hook to load all markdown posts
 * Falls back to mock data if no markdown files are found
 */
export function useMarkdownPosts() {
  const [posts, setPosts] = useState<MarkdownPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    async function loadPosts() {
      try {
        setLoading(true);
        const loadedPosts = await loadAllMarkdownFiles();
        
        // If no markdown posts found, fall back to mock data
        if (loadedPosts.length === 0) {
          console.warn('No markdown posts found, using mock data');
          const { mockPosts } = await import('../data/mockPosts');
          setPosts(mockPosts as any); // Convert mock posts to markdown format
        } else {
          setPosts(loadedPosts);
        }
        
        setError(null);
      } catch (err) {
        console.error('Error loading markdown posts:', err);
        setError(err as Error);
        
        // Fall back to mock data on error
        const { mockPosts } = await import('../data/mockPosts');
        setPosts(mockPosts as any);
      } finally {
        setLoading(false);
      }
    }

    loadPosts();
  }, []);

  return { posts, loading, error };
}

/**
 * Hook to load a single markdown post by slug
 */
export function useMarkdownPost(slug: string | undefined) {
  const [post, setPost] = useState<MarkdownPost | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    if (!slug) {
      setPost(null);
      setLoading(false);
      return;
    }

    async function loadPost() {
      try {
        setLoading(true);
        const loadedPost = await loadMarkdownFile(slug);
        
        if (!loadedPost) {
          // Fall back to mock data
          const { getPostBySlug } = await import('../data/mockPosts');
          const mockPost = getPostBySlug(slug);
          setPost(mockPost as any);
        } else {
          setPost(loadedPost);
        }
        
        setError(null);
      } catch (err) {
        console.error(`Error loading post ${slug}:`, err);
        setError(err as Error);
        
        // Fall back to mock data on error
        const { getPostBySlug } = await import('../data/mockPosts');
        const mockPost = getPostBySlug(slug);
        setPost(mockPost as any);
      } finally {
        setLoading(false);
      }
    }

    loadPost();
  }, [slug]);

  return { post, loading, error };
}

/**
 * Hook to get posts by category
 */
export function usePostsByCategory(category: string) {
  const { posts, loading, error } = useMarkdownPosts();
  
  const filteredPosts = posts.filter(post => 
    post.frontmatter.category.toLowerCase() === category.toLowerCase()
  );

  return { posts: filteredPosts, loading, error };
}

/**
 * Hook to get posts by tag
 */
export function usePostsByTag(tag: string) {
  const { posts, loading, error } = useMarkdownPosts();
  
  const filteredPosts = posts.filter(post => 
    post.frontmatter.tags?.some(t => t.toLowerCase() === tag.toLowerCase())
  );

  return { posts: filteredPosts, loading, error };
}

/**
 * Hook to get featured posts
 */
export function useFeaturedPosts() {
  const { posts, loading, error } = useMarkdownPosts();
  
  const featuredPosts = posts.filter(post => post.frontmatter.featured === true);

  return { posts: featuredPosts, loading, error };
}
