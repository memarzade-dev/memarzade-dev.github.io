import { useState, useEffect, useCallback } from 'react';

const BOOKMARKS_KEY = 'vaults_bookmarks';

export function useBookmarks() {
  const [bookmarks, setBookmarks] = useState<string[]>([]);

  useEffect(() => {
    // Load bookmarks from localStorage
    const storedBookmarks = localStorage.getItem(BOOKMARKS_KEY);
    if (storedBookmarks) {
      setBookmarks(JSON.parse(storedBookmarks));
    }
  }, []);

  const addBookmark = useCallback((slug: string) => {
    setBookmarks((prevBookmarks) => {
      if (prevBookmarks.includes(slug)) {
        return prevBookmarks;
      }
      const updatedBookmarks = [...prevBookmarks, slug];
      localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(updatedBookmarks));
      return updatedBookmarks;
    });
  }, []);

  const removeBookmark = useCallback((slug: string) => {
    setBookmarks((prevBookmarks) => {
      const updatedBookmarks = prevBookmarks.filter((s) => s !== slug);
      localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(updatedBookmarks));
      return updatedBookmarks;
    });
  }, []);

  const toggleBookmark = useCallback((slug: string) => {
    setBookmarks((prevBookmarks) => {
      const isCurrentlyBookmarked = prevBookmarks.includes(slug);
      const updatedBookmarks = isCurrentlyBookmarked
        ? prevBookmarks.filter((s) => s !== slug)
        : [...prevBookmarks, slug];
      localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(updatedBookmarks));
      return updatedBookmarks;
    });
  }, []);

  const isBookmarked = useCallback((slug: string) => {
    return bookmarks.includes(slug);
  }, [bookmarks]);

  return {
    bookmarks,
    addBookmark,
    removeBookmark,
    toggleBookmark,
    isBookmarked,
  };
}