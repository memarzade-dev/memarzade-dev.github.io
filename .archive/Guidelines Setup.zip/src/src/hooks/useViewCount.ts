import { useState, useEffect, useRef } from 'react';

const VIEW_COUNT_KEY = 'vaults_view_counts';

interface ViewCounts {
  [slug: string]: number;
}

export function useViewCount(slug: string) {
  const [viewCount, setViewCount] = useState<number>(0);
  const hasIncrementedRef = useRef(false);

  useEffect(() => {
    // Only increment once per component mount
    if (hasIncrementedRef.current) {
      return;
    }

    // Get current view counts from localStorage
    const storedCounts = localStorage.getItem(VIEW_COUNT_KEY);
    const counts: ViewCounts = storedCounts ? JSON.parse(storedCounts) : {};

    // Increment view count for this post
    const currentCount = counts[slug] || 0;
    const newCount = currentCount + 1;
    counts[slug] = newCount;

    // Save back to localStorage
    localStorage.setItem(VIEW_COUNT_KEY, JSON.stringify(counts));
    setViewCount(newCount);
    
    hasIncrementedRef.current = true;
  }, [slug]);

  return viewCount;
}

export function getAllViewCounts(): ViewCounts {
  const storedCounts = localStorage.getItem(VIEW_COUNT_KEY);
  return storedCounts ? JSON.parse(storedCounts) : {};
}

export function getTotalViews(): number {
  const counts = getAllViewCounts();
  return Object.values(counts).reduce((sum, count) => sum + count, 0);
}