import { useState, useEffect, useCallback } from 'react';

const READING_HISTORY_KEY = 'vaults_reading_history';
const MAX_HISTORY_ITEMS = 20;

export interface ReadingHistoryItem {
  slug: string;
  title: string;
  timestamp: number;
  scrollProgress?: number;
}

export function useReadingHistory() {
  const [history, setHistory] = useState<ReadingHistoryItem[]>([]);

  useEffect(() => {
    // Load history from localStorage
    const storedHistory = localStorage.getItem(READING_HISTORY_KEY);
    if (storedHistory) {
      setHistory(JSON.parse(storedHistory));
    }
  }, []);

  const addToHistory = useCallback((slug: string, title: string, scrollProgress?: number) => {
    setHistory((prevHistory) => {
      // Remove existing entry if present
      const filteredHistory = prevHistory.filter((item) => item.slug !== slug);
      
      // Add new entry at the beginning
      const newItem: ReadingHistoryItem = {
        slug,
        title,
        timestamp: Date.now(),
        scrollProgress,
      };
      
      const updatedHistory = [newItem, ...filteredHistory].slice(0, MAX_HISTORY_ITEMS);
      localStorage.setItem(READING_HISTORY_KEY, JSON.stringify(updatedHistory));
      return updatedHistory;
    });
  }, []);

  const updateScrollProgress = useCallback((slug: string, scrollProgress: number) => {
    setHistory((prevHistory) => {
      const updatedHistory = prevHistory.map((item) =>
        item.slug === slug ? { ...item, scrollProgress } : item
      );
      localStorage.setItem(READING_HISTORY_KEY, JSON.stringify(updatedHistory));
      return updatedHistory;
    });
  }, []);

  const clearHistory = useCallback(() => {
    setHistory([]);
    localStorage.removeItem(READING_HISTORY_KEY);
  }, []);

  const removeFromHistory = useCallback((slug: string) => {
    setHistory((prevHistory) => {
      const updatedHistory = prevHistory.filter((item) => item.slug !== slug);
      localStorage.setItem(READING_HISTORY_KEY, JSON.stringify(updatedHistory));
      return updatedHistory;
    });
  }, []);

  const getScrollProgress = useCallback((slug: string): number | undefined => {
    const item = history.find((item) => item.slug === slug);
    return item?.scrollProgress;
  }, [history]);

  return {
    history,
    addToHistory,
    updateScrollProgress,
    clearHistory,
    removeFromHistory,
    getScrollProgress,
  };
}