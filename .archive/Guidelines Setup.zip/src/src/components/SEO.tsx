import { useEffect } from 'react';

export interface SEOProps {
  title: string;
  description?: string;
  keywords?: string[];
  author?: string;
  type?: 'website' | 'article';
  image?: string;
  url?: string;
  publishedTime?: string;
  modifiedTime?: string;
  tags?: string[];
  section?: string;
}

export function SEO({
  title,
  description = 'Vaults: A Developer\'s Free Code License - An AWWWARDS-level personal blog and digital garden for deep technical content.',
  keywords = [],
  author = 'Vaults',
  type = 'website',
  image = 'https://vaults.memarzade.dev/og-image.png',
  url = 'https://vaults.memarzade.dev',
  publishedTime,
  modifiedTime,
  tags = [],
  section,
}: SEOProps) {
  useEffect(() => {
    // Update document title
    document.title = title ? `${title} | Vaults` : 'Vaults - Developer Blog';

    // Update or create meta tags
    updateMetaTag('description', description);
    updateMetaTag('keywords', keywords.join(', '));
    updateMetaTag('author', author);

    // Open Graph meta tags
    updateMetaTag('og:title', title, 'property');
    updateMetaTag('og:description', description, 'property');
    updateMetaTag('og:type', type, 'property');
    updateMetaTag('og:image', image, 'property');
    updateMetaTag('og:url', url, 'property');
    updateMetaTag('og:site_name', 'Vaults', 'property');

    // Twitter Card meta tags
    updateMetaTag('twitter:card', 'summary_large_image', 'name');
    updateMetaTag('twitter:title', title, 'name');
    updateMetaTag('twitter:description', description, 'name');
    updateMetaTag('twitter:image', image, 'name');

    // Article-specific meta tags
    if (type === 'article') {
      if (publishedTime) {
        updateMetaTag('article:published_time', publishedTime, 'property');
      }
      if (modifiedTime) {
        updateMetaTag('article:modified_time', modifiedTime, 'property');
      }
      if (section) {
        updateMetaTag('article:section', section, 'property');
      }
      tags.forEach((tag) => {
        updateMetaTag('article:tag', tag, 'property', true);
      });
    }

    // Canonical URL
    updateLinkTag('canonical', url);

    // JSON-LD structured data
    updateStructuredData({
      '@context': 'https://schema.org',
      '@type': type === 'article' ? 'Article' : 'WebSite',
      headline: title,
      description: description,
      image: image,
      url: url,
      author: {
        '@type': 'Person',
        name: author,
      },
      publisher: {
        '@type': 'Organization',
        name: 'Vaults',
        logo: {
          '@type': 'ImageObject',
          url: 'https://vaults.memarzade.dev/logo.png',
        },
      },
      ...(publishedTime && { datePublished: publishedTime }),
      ...(modifiedTime && { dateModified: modifiedTime }),
      ...(tags.length > 0 && { keywords: tags.join(', ') }),
    });
  }, [title, description, keywords, author, type, image, url, publishedTime, modifiedTime, tags, section]);

  return null;
}

function updateMetaTag(
  name: string,
  content: string,
  attribute: 'name' | 'property' = 'name',
  allowMultiple: boolean = false
): void {
  if (!content) return;

  let element = document.querySelector(
    `meta[${attribute}="${name}"]`
  ) as HTMLMetaElement;

  if (!element && !allowMultiple) {
    element = document.createElement('meta');
    element.setAttribute(attribute, name);
    document.head.appendChild(element);
  }

  if (element) {
    element.content = content;
  } else if (allowMultiple) {
    const newElement = document.createElement('meta');
    newElement.setAttribute(attribute, name);
    newElement.content = content;
    document.head.appendChild(newElement);
  }
}

function updateLinkTag(rel: string, href: string): void {
  if (!href) return;

  let element = document.querySelector(`link[rel="${rel}"]`) as HTMLLinkElement;

  if (!element) {
    element = document.createElement('link');
    element.rel = rel;
    document.head.appendChild(element);
  }

  element.href = href;
}

function updateStructuredData(data: any): void {
  const scriptId = 'structured-data';
  let element = document.getElementById(scriptId) as HTMLScriptElement;

  if (!element) {
    element = document.createElement('script');
    element.id = scriptId;
    element.type = 'application/ld+json';
    document.head.appendChild(element);
  }

  element.textContent = JSON.stringify(data);
}
