import { useEffect, useState, useRef } from 'react';
import { List } from 'lucide-react';

export interface TocItem {
  id: string;
  text: string;
  level: number;
}

export interface TableOfContentsProps {
  contentRef: React.RefObject<HTMLElement>;
  className?: string;
  sticky?: boolean;
}

export function TableOfContents({
  contentRef,
  className = '',
  sticky = true,
}: TableOfContentsProps) {
  const [headings, setHeadings] = useState<TocItem[]>([]);
  const [activeId, setActiveId] = useState<string>('');
  const [isExpanded, setIsExpanded] = useState(true);
  const observerRef = useRef<IntersectionObserver | null>(null);

  // Extract headings from content
  useEffect(() => {
    if (!contentRef.current) return;

    const content = contentRef.current;
    const headingElements = content.querySelectorAll('h1, h2, h3, h4, h5, h6');
    
    const items: TocItem[] = Array.from(headingElements).map((heading, index) => {
      const level = parseInt(heading.tagName.substring(1));
      const text = heading.textContent || '';
      let id = heading.id;

      // Create ID if it doesn't exist
      if (!id) {
        id = `heading-${index}-${text.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
        heading.id = id;
      }

      return { id, text, level };
    });

    setHeadings(items);
  }, [contentRef]);

  // Intersection observer for active heading
  useEffect(() => {
    if (!contentRef.current || headings.length === 0) return;

    const observerCallback: IntersectionObserverCallback = (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          setActiveId(entry.target.id);
        }
      });
    };

    observerRef.current = new IntersectionObserver(observerCallback, {
      rootMargin: '-80px 0px -80% 0px',
      threshold: 1.0,
    });

    headings.forEach(({ id }) => {
      const element = document.getElementById(id);
      if (element) {
        observerRef.current?.observe(element);
      }
    });

    return () => {
      observerRef.current?.disconnect();
    };
  }, [headings, contentRef]);

  const scrollToHeading = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 100; // Account for header
      const elementPosition = element.getBoundingClientRect().top + window.pageYOffset;
      window.scrollTo({
        top: elementPosition - offset,
        behavior: 'smooth',
      });
    }
  };

  if (headings.length === 0) {
    return null;
  }

  return (
    <nav
      className={`bg-vault-bg-surface border border-vault-border-subtle rounded-lg ${
        sticky ? 'sticky top-24' : ''
      } ${className}`}
      aria-label="Table of contents"
    >
      {/* Header */}
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between p-4 text-vault-text-primary hover:text-vault-accent-primary transition-colors"
      >
        <div className="flex items-center gap-2">
          <List className="w-5 h-5" />
          <span className="font-heading font-semibold">Table of Contents</span>
        </div>
        <svg
          className={`w-5 h-5 transition-transform ${isExpanded ? 'rotate-180' : ''}`}
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>

      {/* TOC List */}
      {isExpanded && (
        <ul className="px-4 pb-4 space-y-1 max-h-[60vh] overflow-y-auto">
          {headings.map(({ id, text, level }) => (
            <li
              key={id}
              style={{ paddingLeft: `${(level - 1) * 0.75}rem` }}
            >
              <button
                onClick={() => scrollToHeading(id)}
                className={`w-full text-left py-1.5 px-3 rounded text-sm transition-all ${
                  activeId === id
                    ? 'text-vault-accent-primary bg-vault-accent-primary/10 font-medium'
                    : 'text-vault-text-secondary hover:text-vault-text-primary hover:bg-vault-bg-hover'
                }`}
              >
                {text}
              </button>
            </li>
          ))}
        </ul>
      )}
    </nav>
  );
}
