import React, { useState, useEffect } from 'react';
import { Link } from './Link';
import { useNavigate } from 'react-router-dom';
import { useTheme } from '../contexts/ThemeContext';
import { Moon, Sun, Monitor, Search, Menu, X } from 'lucide-react';

export interface HeaderProps {
  className?: string;
  showSearch?: boolean;
  showThemeToggle?: boolean;
  onMenuToggle?: () => void;
}

export function Header({
  className = '',
  showSearch = true,
  showThemeToggle = true,
  onMenuToggle,
}: HeaderProps) {
  const { theme, setTheme } = useTheme();
  const navigate = useNavigate();
  const [searchFocused, setSearchFocused] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Keyboard shortcut for search (Cmd+K / Ctrl+K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        navigate('/search');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [navigate]);

  const cycleTheme = () => {
    const themes: Array<'dark' | 'light' | 'system'> = ['dark', 'light', 'system'];
    const currentIndex = themes.indexOf(theme);
    const nextTheme = themes[(currentIndex + 1) % themes.length];
    setTheme(nextTheme);
  };

  const ThemeIcon = theme === 'dark' ? Moon : theme === 'light' ? Sun : Monitor;

  return (
    <header 
      className={`sticky top-0 z-50 bg-vault-bg-surface/80 backdrop-blur-md border-b border-vault-border-subtle ${className}`}
      style={{ height: 'var(--header-height)' }}
    >
      <div className="max-w-container-full mx-auto px-4 md:px-8 h-full flex items-center justify-between gap-4">
        {/* Left: Logo + Menu Toggle (Mobile) */}
        <div className="flex items-center gap-4">
          {onMenuToggle && (
            <button
              onClick={onMenuToggle}
              className="md:hidden p-2 text-vault-text-secondary hover:text-vault-text-primary transition-colors"
              aria-label="Toggle menu"
            >
              <Menu className="w-5 h-5" />
            </button>
          )}
          
          <Link to="/" className="flex items-center gap-2">
            <span className="font-heading font-bold text-xl gradient-text">
              Vaults
            </span>
          </Link>
        </div>

        {/* Center: Search Bar (Desktop) */}
        {showSearch && (
          <div className="hidden md:flex flex-1 max-w-md">
            <div className={`relative w-full transition-all duration-300 ${searchFocused ? 'scale-105' : ''}`}>
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-vault-text-muted" />
              <input
                type="search"
                placeholder="Search posts... (Cmd+K)"
                className="w-full pl-10 pr-4 py-2 bg-vault-bg-elevated border border-vault-border-subtle rounded-md text-vault-text-primary placeholder:text-vault-text-muted focus:outline-none focus:border-vault-accent-primary focus:shadow-glow-primary transition-all"
                onFocus={() => setSearchFocused(true)}
                onBlur={() => setSearchFocused(false)}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    navigate(`/search?q=${searchQuery}`);
                  }
                }}
              />
            </div>
          </div>
        )}

        {/* Right: Theme Toggle */}
        <div className="flex items-center gap-2">
          {showSearch && (
            <button
              onClick={() => navigate('/search')}
              className="md:hidden p-2 text-vault-text-secondary hover:text-vault-text-primary transition-colors"
              aria-label="Search"
            >
              <Search className="w-5 h-5" />
            </button>
          )}
          
          {showThemeToggle && (
            <button
              onClick={cycleTheme}
              className="p-2 text-vault-text-secondary hover:text-vault-text-primary transition-all hover:rotate-12"
              aria-label={`Current theme: ${theme}. Click to cycle themes.`}
              title={`Theme: ${theme}`}
            >
              <ThemeIcon className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>
    </header>
  );
}