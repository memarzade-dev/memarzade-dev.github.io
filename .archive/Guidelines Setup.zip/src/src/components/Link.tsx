import React from 'react';
import { Link as RouterLink } from 'react-router-dom';
import { ExternalLink } from 'lucide-react';

export interface LinkProps {
  to?: string;
  href?: string;
  external?: boolean;
  anchor?: boolean;
  variant?: 'default' | 'underlined' | 'button';
  className?: string;
  children: React.ReactNode;
  onClick?: (e: React.MouseEvent) => void;
}

export function Link({
  to,
  href,
  external = false,
  anchor = false,
  variant = 'default',
  className = '',
  children,
  onClick,
  ...props
}: LinkProps) {
  const baseClasses = 'transition-all duration-300 focus:outline-none focus:shadow-glow-primary';
  
  const variantClasses = {
    default: 'text-vault-accent-primary hover:text-vault-accent-primary-hover hover:brightness-110',
    underlined: 'text-vault-accent-primary hover:text-vault-accent-primary-hover underline hover:no-underline',
    button: 'inline-flex items-center justify-center px-4 py-2 bg-vault-accent-primary text-vault-text-inverse rounded-md hover:bg-vault-accent-primary-hover hover:-translate-y-0.5',
  };

  const classes = `${baseClasses} ${variantClasses[variant]} ${className}`;

  if (href || external) {
    return (
      <a
        href={href || to}
        className={classes}
        target={external ? '_blank' : undefined}
        rel={external ? 'noopener noreferrer' : undefined}
        onClick={onClick}
        {...props}
      >
        {children}
        {external && (
          <ExternalLink className="inline-block ml-1 w-4 h-4" aria-hidden="true" />
        )}
      </a>
    );
  }

  if (anchor && to) {
    return (
      <a
        href={to}
        className={classes}
        onClick={(e) => {
          e.preventDefault();
          const target = document.querySelector(to);
          if (target) {
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            window.history.pushState(null, '', to);
          }
          onClick?.(e);
        }}
        {...props}
      >
        {children}
      </a>
    );
  }

  if (to) {
    return (
      <RouterLink to={to} className={classes} onClick={onClick} {...props}>
        {children}
      </RouterLink>
    );
  }

  return (
    <span className={classes} {...props}>
      {children}
    </span>
  );
}