import { Bookmark } from 'lucide-react';
import { useBookmarks } from '../hooks/useBookmarks';

export interface BookmarkButtonProps {
  slug: string;
  className?: string;
}

export function BookmarkButton({ slug, className = '' }: BookmarkButtonProps) {
  const { isBookmarked, toggleBookmark } = useBookmarks();
  const bookmarked = isBookmarked(slug);

  return (
    <button
      onClick={() => toggleBookmark(slug)}
      className={`flex items-center gap-2 px-3 py-2 text-sm transition-all rounded-md border ${
        bookmarked
          ? 'bg-vault-accent-primary/10 text-vault-accent-primary border-vault-accent-primary'
          : 'bg-vault-bg-elevated text-vault-text-secondary border-vault-border-subtle hover:text-vault-text-primary hover:border-vault-accent-primary'
      } ${className}`}
      aria-label={bookmarked ? 'Remove bookmark' : 'Add bookmark'}
    >
      <Bookmark
        className={`w-4 h-4 ${bookmarked ? 'fill-current' : ''}`}
      />
      <span className="hidden sm:inline">
        {bookmarked ? 'Bookmarked' : 'Bookmark'}
      </span>
    </button>
  );
}
