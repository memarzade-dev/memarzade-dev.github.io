import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Callout, CalloutVariant } from './Callout';
import { Link } from './Link';
import { detectTextDirection } from '../utils/rtl';

interface MarkdownRendererProps {
  content: string;
  className?: string;
  onHeadingsExtracted?: (headings: Array<{ level: number; text: string; id: string }>) => void;
}

export function MarkdownRenderer({ content, className = '' }: MarkdownRendererProps) {
  // Helper to detect callouts in blockquotes
  const parseCallout = (children: any): { variant: CalloutVariant; title?: string; content: any } | null => {
    if (!children || !Array.isArray(children)) return null;

    const firstChild = children[0];
    if (!firstChild || !firstChild.props || !firstChild.props.children) return null;

    const firstText = Array.isArray(firstChild.props.children) 
      ? firstChild.props.children[0] 
      : firstChild.props.children;

    if (typeof firstText !== 'string') return null;

    // Match [!type] Title or [!type]
    const match = firstText.match(/^\[!(\w+)\]\s*(.*)$/);
    if (!match) return null;

    const [, type, title] = match;
    const variant = type.toLowerCase() as CalloutVariant;

    // Valid callout types
    const validVariants: CalloutVariant[] = [
      'note', 'tip', 'warning', 'danger', 'info', 'quote',
      'example', 'question', 'success', 'failure', 'bug'
    ];

    if (!validVariants.includes(variant)) return null;

    // Remove the callout marker from content
    const content = [...children];
    if (title) {
      // If there's a title on the same line, remove just the marker
      content[0] = {
        ...firstChild,
        props: {
          ...firstChild.props,
          children: Array.isArray(firstChild.props.children)
            ? [firstChild.props.children[0].replace(/^\[!\w+\]\s*/, ''), ...firstChild.props.children.slice(1)]
            : firstChild.props.children.replace(/^\[!\w+\]\s*/, '')
        }
      };
    } else {
      // If no title, remove the entire first paragraph
      content.shift();
    }

    return { variant, title: title || undefined, content };
  };

  return (
    <article className={`markdown-renderer prose prose-invert max-w-none ${className}`}>
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          // Headings with RTL/LTR detection
          h1: ({ children, ...props }) => {
            const text = String(children);
            const dir = detectTextDirection(text);
            return (
              <h1
                dir={dir}
                style={{ fontFamily: dir === 'rtl' ? 'var(--font-rtl)' : 'var(--font-heading)' }}
                className="text-h1 mb-4 mt-8 text-vault-text-primary border-b border-vault-border-subtle pb-2"
                {...props}
              >
                {children}
              </h1>
            );
          },
          h2: ({ children, ...props }) => {
            const text = String(children);
            const dir = detectTextDirection(text);
            return (
              <h2
                dir={dir}
                style={{ fontFamily: dir === 'rtl' ? 'var(--font-rtl)' : 'var(--font-heading)' }}
                className="text-h2 mb-3 mt-7 text-vault-text-primary"
                {...props}
              >
                {children}
              </h2>
            );
          },
          h3: ({ children, ...props }) => {
            const text = String(children);
            const dir = detectTextDirection(text);
            return (
              <h3
                dir={dir}
                style={{ fontFamily: dir === 'rtl' ? 'var(--font-rtl)' : 'var(--font-heading)' }}
                className="text-h3 mb-3 mt-6 text-vault-text-primary"
                {...props}
              >
                {children}
              </h3>
            );
          },
          h4: ({ children, ...props }) => {
            const text = String(children);
            const dir = detectTextDirection(text);
            return (
              <h4
                dir={dir}
                style={{ fontFamily: dir === 'rtl' ? 'var(--font-rtl)' : 'var(--font-heading)' }}
                className="text-h4 mb-2 mt-5 text-vault-text-primary"
                {...props}
              >
                {children}
              </h4>
            );
          },
          h5: ({ children, ...props }) => {
            const text = String(children);
            const dir = detectTextDirection(text);
            return (
              <h5
                dir={dir}
                style={{ fontFamily: dir === 'rtl' ? 'var(--font-rtl)' : 'var(--font-heading)' }}
                className="text-h5 mb-2 mt-4 text-vault-text-primary"
                {...props}
              >
                {children}
              </h5>
            );
          },
          h6: ({ children, ...props }) => {
            const text = String(children);
            const dir = detectTextDirection(text);
            return (
              <h6
                dir={dir}
                style={{ fontFamily: dir === 'rtl' ? 'var(--font-rtl)' : 'var(--font-heading)' }}
                className="text-h6 mb-2 mt-4 text-vault-text-primary"
                {...props}
              >
                {children}
              </h6>
            );
          },

          // Paragraphs with RTL/LTR detection
          p: ({ children, ...props }) => {
            const text = String(children);
            const dir = detectTextDirection(text);
            return (
              <p
                dir={dir}
                style={{ fontFamily: dir === 'rtl' ? 'var(--font-rtl)' : 'var(--font-body)' }}
                className="mb-4 text-vault-text-primary leading-relaxed"
                {...props}
              >
                {children}
              </p>
            );
          },

          // Links
          a: ({ href, children, ...props }) => {
            // Check for internal links [[Note Name]]
            if (href?.startsWith('[[') && href?.endsWith(']]')) {
              const linkText = href.slice(2, -2);
              const slug = linkText.toLowerCase().replace(/\s+/g, '-');
              return (
                <Link to={`/posts/${slug}`} className="text-vault-accent-primary hover:underline">
                  {children || linkText}
                </Link>
              );
            }
            return (
              <a
                href={href}
                className="text-vault-accent-primary hover:underline"
                target={href?.startsWith('http') ? '_blank' : undefined}
                rel={href?.startsWith('http') ? 'noopener noreferrer' : undefined}
                {...props}
              >
                {children}
              </a>
            );
          },

          // Code blocks
          code: ({ inline, className, children, ...props }: any) => {
            if (inline) {
              return (
                <code
                  className="px-1.5 py-0.5 bg-vault-bg-elevated text-vault-accent-primary rounded text-sm border border-vault-border-subtle"
                  style={{ fontFamily: 'var(--font-mono)' }}
                  {...props}
                >
                  {children}
                </code>
              );
            }
            
            const language = className?.replace('language-', '') || '';
            
            return (
              <div className="relative my-4 group">
                {language && (
                  <div className="absolute top-2 right-2 px-2 py-1 bg-vault-bg-base text-vault-text-muted text-xs rounded border border-vault-border-subtle">
                    {language}
                  </div>
                )}
                <pre className="bg-vault-bg-elevated p-4 rounded-lg border border-vault-border-subtle overflow-x-auto">
                  <code
                    className={className}
                    style={{ fontFamily: 'var(--font-mono)' }}
                    {...props}
                  >
                    {children}
                  </code>
                </pre>
              </div>
            );
          },

          // Blockquotes (with Obsidian callout detection)
          blockquote: ({ children, ...props }) => {
            const calloutData = parseCallout(children);
            
            if (calloutData) {
              return (
                <Callout variant={calloutData.variant} title={calloutData.title}>
                  {calloutData.content}
                </Callout>
              );
            }

            return (
              <blockquote
                className="border-l-4 border-vault-accent-primary bg-vault-bg-elevated pl-4 py-2 my-4 italic text-vault-text-secondary"
                {...props}
              >
                {children}
              </blockquote>
            );
          },

          // Lists
          ul: ({ children, ...props }) => (
            <ul className="list-disc list-inside mb-4 space-y-1 text-vault-text-primary" {...props}>
              {children}
            </ul>
          ),
          ol: ({ children, ...props }) => (
            <ol className="list-decimal list-inside mb-4 space-y-1 text-vault-text-primary" {...props}>
              {children}
            </ol>
          ),
          li: ({ children, ...props }) => (
            <li className="ml-4 text-vault-text-primary" {...props}>
              {children}
            </li>
          ),

          // Tables
          table: ({ children, ...props }) => (
            <div className="overflow-x-auto my-6">
              <table className="min-w-full border-collapse border border-vault-border-subtle" {...props}>
                {children}
              </table>
            </div>
          ),
          thead: ({ children, ...props }) => (
            <thead className="bg-vault-bg-elevated" {...props}>
              {children}
            </thead>
          ),
          th: ({ children, ...props }) => (
            <th className="border border-vault-border-subtle px-4 py-2 text-left text-vault-text-primary" {...props}>
              {children}
            </th>
          ),
          td: ({ children, ...props }) => (
            <td className="border border-vault-border-subtle px-4 py-2 text-vault-text-primary" {...props}>
              {children}
            </td>
          ),

          // Images
          img: ({ src, alt, title, ...props }) => (
            <img
              src={src}
              alt={alt || ''}
              title={title}
              loading="lazy"
              className="rounded-lg my-4 max-w-full h-auto border border-vault-border-subtle"
              {...props}
            />
          ),

          // Horizontal rule
          hr: (props) => <hr className="my-8 border-vault-border-subtle" {...props} />,

          // Strong/Bold
          strong: ({ children, ...props }) => (
            <strong className="text-vault-text-primary" {...props}>
              {children}
            </strong>
          ),

          // Emphasis/Italic
          em: ({ children, ...props }) => (
            <em className="text-vault-text-primary" {...props}>
              {children}
            </em>
          ),
        }}
      >
        {content}
      </ReactMarkdown>
    </article>
  );
}