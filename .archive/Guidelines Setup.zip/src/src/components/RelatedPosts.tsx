import { useMemo } from 'react';
import { Post } from '../types/post';
import { PostCard } from './PostCard';
import { Lightbulb } from 'lucide-react';

export interface RelatedPostsProps {
  currentPost: Post;
  allPosts: Post[];
  maxPosts?: number;
  className?: string;
}

export function RelatedPosts({
  currentPost,
  allPosts,
  maxPosts = 3,
  className = '',
}: RelatedPostsProps) {
  const relatedPosts = useMemo(() => {
    // Calculate similarity score based on shared tags and category
    const scoredPosts = allPosts
      .filter((post) => post.slug !== currentPost.slug)
      .map((post) => {
        let score = 0;

        // Same category: +10 points
        if (post.categorySlug === currentPost.categorySlug) {
          score += 10;
        }

        // Shared tags: +5 points per tag
        const sharedTags = post.tags.filter((tag) =>
          currentPost.tags.includes(tag)
        );
        score += sharedTags.length * 5;

        return { post, score, sharedTags: sharedTags.length };
      })
      .filter((item) => item.score > 0) // Only posts with some relevance
      .sort((a, b) => {
        // Sort by score, then by date
        if (b.score !== a.score) {
          return b.score - a.score;
        }
        return new Date(b.post.date).getTime() - new Date(a.post.date).getTime();
      })
      .slice(0, maxPosts);

    return scoredPosts;
  }, [currentPost, allPosts, maxPosts]);

  if (relatedPosts.length === 0) {
    return null;
  }

  return (
    <section className={`${className}`}>
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-vault-accent-secondary/10 rounded-lg border border-vault-accent-secondary/20">
          <Lightbulb className="w-5 h-5 text-vault-accent-secondary" />
        </div>
        <h2 className="text-h2">Related Posts</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {relatedPosts.map(({ post, sharedTags }) => (
          <div key={post.slug} className="relative">
            <PostCard
              post={post}
              variant="default"
              showImage={true}
              showExcerpt={true}
            />
            {sharedTags > 0 && (
              <div className="absolute top-4 right-4 px-2 py-1 bg-vault-accent-secondary/90 backdrop-blur-sm text-vault-text-inverted text-xs rounded-full border border-vault-accent-secondary">
                {sharedTags} shared {sharedTags === 1 ? 'tag' : 'tags'}
              </div>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}
