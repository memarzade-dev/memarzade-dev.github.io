import React from 'react';
import { Link } from './Link';
import { Github, Instagram, Send, Mail } from 'lucide-react';

export interface FooterProps {
  className?: string;
}

export function Footer({ className = '' }: FooterProps) {
  return (
    <footer className={`bg-vault-bg-surface border-t border-vault-border-subtle mt-auto ${className}`}>
      <div className="max-w-container mx-auto px-4 md:px-8 py-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Left: Branding */}
          <div className="flex flex-col items-center md:items-start">
            <Link to="/" className="flex items-center gap-2 mb-2">
              <span className="font-heading font-bold text-xl gradient-text">
                Vaults
              </span>
            </Link>
            <p className="text-sm text-vault-text-muted text-center md:text-left">
              A Developer's Free Code License
            </p>
            <p className="text-xs text-vault-text-muted mt-1">
              © {new Date().getFullYear()} memarzade-dev. All rights reserved.
            </p>
          </div>

          {/* Center: Quick Links */}
          <div className="flex items-center gap-6">
            <Link to="/" variant="default" className="text-sm">
              Home
            </Link>
            <Link to="/categories" variant="default" className="text-sm">
              Categories
            </Link>
            <Link to="/graph" variant="default" className="text-sm">
              Graph
            </Link>
          </div>

          {/* Right: Social Links */}
          <div className="flex items-center gap-4">
            <Link
              href="https://github.com/memarzade-dev"
              external
              className="p-2 text-vault-text-secondary hover:text-vault-text-primary transition-all hover:-translate-y-1"
              aria-label="GitHub"
            >
              <Github className="w-5 h-5" />
            </Link>
            <Link
              href="https://instagram.com/memarzade.dev"
              external
              className="p-2 text-vault-text-secondary hover:text-vault-text-primary transition-all hover:-translate-y-1"
              aria-label="Instagram"
            >
              <Instagram className="w-5 h-5" />
            </Link>
            <Link
              href="https://t.me/memarzade.ali"
              external
              className="p-2 text-vault-text-secondary hover:text-vault-text-primary transition-all hover:-translate-y-1"
              aria-label="Telegram"
            >
              <Send className="w-5 h-5" />
            </Link>
            <Link
              href="mailto:memarzade.dev@gmail.com"
              external
              className="p-2 text-vault-text-secondary hover:text-vault-text-primary transition-all hover:-translate-y-1"
              aria-label="Email"
            >
              <Mail className="w-5 h-5" />
            </Link>
          </div>
        </div>

        {/* Wave Animation */}
        <div className="mt-8 h-1 w-full bg-gradient-primary rounded-full opacity-30" />
      </div>
    </footer>
  );
}