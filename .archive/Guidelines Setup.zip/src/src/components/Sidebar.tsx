import React, { useState } from 'react';
import { Link } from './Link';
import { ChevronRight, ChevronDown, Home, Search, Folder, Tag, Network, Bookmark, History } from 'lucide-react';

export interface NestedCategory {
  name: string;
  slug: string;
  children?: NestedCategory[];
  postCount?: number;
}

export interface SidebarProps {
  categories: NestedCategory[];
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
  className?: string;
}

function CategoryTreeItem({ 
  category, 
  level = 0,
  activePath = '',
}: { 
  category: NestedCategory; 
  level?: number;
  activePath?: string;
}) {
  const [isExpanded, setIsExpanded] = useState(
    activePath.includes(category.slug)
  );
  const hasChildren = category.children && category.children.length > 0;
  const isActive = activePath === category.slug;

  return (
    <li className="mb-1">
      <div className="flex items-center gap-1">
        {hasChildren && (
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 text-vault-text-muted hover:text-vault-text-primary transition-colors"
            aria-label={isExpanded ? 'Collapse' : 'Expand'}
          >
            {isExpanded ? (
              <ChevronDown className="w-4 h-4" />
            ) : (
              <ChevronRight className="w-4 h-4" />
            )}
          </button>
        )}
        
        <Link
          to={`/categories/${category.slug}`}
          className={`flex-1 px-3 py-2 rounded-md text-sm transition-all ${
            isActive 
              ? 'bg-vault-accent-primary/10 text-vault-accent-primary font-medium' 
              : 'text-vault-text-secondary hover:text-vault-text-primary hover:bg-vault-bg-hover'
          }`}
          style={{ paddingLeft: hasChildren ? undefined : `${(level + 1) * 0.75 + 0.75}rem` }}
        >
          <div className="flex items-center justify-between">
            <span>{category.name}</span>
            {category.postCount !== undefined && (
              <span className="text-xs text-vault-text-muted">
                {category.postCount}
              </span>
            )}
          </div>
        </Link>
      </div>

      {hasChildren && isExpanded && (
        <ul className="ml-3 mt-1 border-l border-vault-border-subtle pl-2">
          {category.children!.map((child) => (
            <CategoryTreeItem
              key={child.slug}
              category={child}
              level={level + 1}
              activePath={activePath}
            />
          ))}
        </ul>
      )}
    </li>
  );
}

export function Sidebar({
  categories,
  isCollapsed = false,
  onToggleCollapse,
  className = '',
}: SidebarProps) {
  const [activeCategory, setActiveCategory] = useState<string>('');

  return (
    <aside
      className={`bg-vault-bg-surface border-r border-vault-border-subtle transition-all duration-300 ${className}`}
      style={{
        width: isCollapsed ? 'var(--sidebar-width-collapsed)' : 'var(--sidebar-width)',
      }}
      aria-label="Category navigation"
    >
      <nav className="p-4 h-full overflow-y-auto">
        {/* Navigation Links */}
        {!isCollapsed && (
          <div className="mb-6 space-y-1">
            <Link
              to="/"
              className="flex items-center gap-3 px-3 py-2 rounded-md text-vault-text-secondary hover:text-vault-text-primary hover:bg-vault-bg-hover transition-all"
            >
              <Home className="w-4 h-4" />
              <span>Home</span>
            </Link>
            <Link
              to="/search"
              className="flex items-center gap-3 px-3 py-2 rounded-md text-vault-text-secondary hover:text-vault-text-primary hover:bg-vault-bg-hover transition-all"
            >
              <Search className="w-4 h-4" />
              <span>Search</span>
            </Link>
            <Link
              to="/categories"
              className="flex items-center gap-3 px-3 py-2 rounded-md text-vault-text-secondary hover:text-vault-text-primary hover:bg-vault-bg-hover transition-all"
            >
              <Folder className="w-4 h-4" />
              <span>All Categories</span>
            </Link>
            <Link
              to="/tags"
              className="flex items-center gap-3 px-3 py-2 rounded-md text-vault-text-secondary hover:text-vault-text-primary hover:bg-vault-bg-hover transition-all"
            >
              <Tag className="w-4 h-4" />
              <span>Tags</span>
            </Link>
            <Link
              to="/graph"
              className="flex items-center gap-3 px-3 py-2 rounded-md text-vault-text-secondary hover:text-vault-text-primary hover:bg-vault-bg-hover transition-all"
            >
              <Network className="w-4 h-4" />
              <span>Knowledge Graph</span>
            </Link>
            <Link
              to="/bookmarks"
              className="flex items-center gap-3 px-3 py-2 rounded-md text-vault-text-secondary hover:text-vault-text-primary hover:bg-vault-bg-hover transition-all"
            >
              <Bookmark className="w-4 h-4" />
              <span>Bookmarks</span>
            </Link>
            <Link
              to="/history"
              className="flex items-center gap-3 px-3 py-2 rounded-md text-vault-text-secondary hover:text-vault-text-primary hover:bg-vault-bg-hover transition-all"
            >
              <History className="w-4 h-4" />
              <span>History</span>
            </Link>
          </div>
        )}

        <div className="mb-4 flex items-center justify-between">
          <h2 className={`font-heading font-semibold text-vault-text-primary ${isCollapsed ? 'hidden' : ''}`}>
            Categories
          </h2>
          {onToggleCollapse && (
            <button
              onClick={onToggleCollapse}
              className="p-1 text-vault-text-muted hover:text-vault-text-primary transition-colors"
              aria-label={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            >
              <ChevronRight className={`w-4 h-4 transition-transform ${isCollapsed ? '' : 'rotate-180'}`} />
            </button>
          )}
        </div>

        {!isCollapsed && (
          <ul className="space-y-1">
            {categories.map((category) => (
              <li key={category.slug}>
                <Link
                  to={`/categories/${category.slug}`}
                  className={`flex items-center justify-between p-2 rounded-md transition-all hover:bg-vault-bg-hover group ${
                    activeCategory === category.slug ? 'bg-vault-bg-elevated text-vault-accent-primary' : 'text-vault-text-secondary'
                  }`}
                >
                  <span className="font-medium">
                    {category.name}
                  </span>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${
                    activeCategory === category.slug 
                      ? 'bg-vault-accent-primary/20 text-vault-accent-primary' 
                      : 'bg-vault-bg-elevated text-vault-text-muted group-hover:bg-vault-bg-hover'
                  }`}>
                    {category.count || 0}
                  </span>
                </Link>
                
                {category.children && category.children.length > 0 && (
                  <ul className="ml-4 mt-1 space-y-1">
                    {category.children.map((child) => (
                      <li key={child.slug}>
                        <Link
                          to={`/categories/${child.slug}`}
                          className={`flex items-center justify-between p-2 pl-3 rounded-md text-sm transition-all hover:bg-vault-bg-hover ${
                            activeCategory === child.slug ? 'bg-vault-bg-elevated text-vault-accent-primary' : 'text-vault-text-muted'
                          }`}
                        >
                          <span>{child.name}</span>
                          <span className="text-xs">{child.count || 0}</span>
                        </Link>
                      </li>
                    ))}
                  </ul>
                )}
              </li>
            ))}
          </ul>
        )}

        {isCollapsed && (
          <div className="space-y-2">
            {categories.map((category) => (
              <Link
                key={category.slug}
                to={`/categories/${category.slug}`}
                className="block p-2 text-vault-text-secondary hover:text-vault-text-primary hover:bg-vault-bg-hover rounded-md transition-all"
                title={category.name}
              >
                <span className="text-xs uppercase font-medium">
                  {category.name.substring(0, 2)}
                </span>
              </Link>
            ))}
          </div>
        )}
      </nav>
    </aside>
  );
}