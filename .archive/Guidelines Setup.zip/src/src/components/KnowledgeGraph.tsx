import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Network, ZoomIn, ZoomOut, Maximize2 } from 'lucide-react';
import { Post } from '../types/post';

interface GraphNode {
  id: string;
  label: string;
  category: string;
  categorySlug: string;
  tags: string[];
  x?: number;
  y?: number;
  vx?: number;
  vy?: number;
}

interface GraphLink {
  source: string;
  target: string;
  strength: number;
}

export interface KnowledgeGraphProps {
  posts: Post[];
  currentPostSlug?: string;
  className?: string;
  height?: number;
}

export function KnowledgeGraph({
  posts,
  currentPostSlug,
  className = '',
  height = 600,
}: KnowledgeGraphProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const navigate = useNavigate();
  const [hoveredNode, setHoveredNode] = useState<GraphNode | null>(null);
  const [zoom, setZoom] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

  // Generate graph data
  const graphData = useRef<{ nodes: GraphNode[]; links: GraphLink[] }>({
    nodes: [],
    links: [],
  });

  useEffect(() => {
    // Create nodes from posts
    const nodes: GraphNode[] = posts.map((post) => ({
      id: post.slug,
      label: post.title,
      category: post.category,
      categorySlug: post.categorySlug,
      tags: post.tags,
      x: Math.random() * 800,
      y: Math.random() * 600,
      vx: 0,
      vy: 0,
    }));

    // Create links based on shared tags and categories
    const links: GraphLink[] = [];
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const node1 = nodes[i];
        const node2 = nodes[j];

        let strength = 0;

        // Same category
        if (node1.categorySlug === node2.categorySlug) {
          strength += 2;
        }

        // Shared tags
        const sharedTags = node1.tags.filter((tag) => node2.tags.includes(tag));
        strength += sharedTags.length;

        if (strength > 0) {
          links.push({
            source: node1.id,
            target: node2.id,
            strength: Math.min(strength, 5),
          });
        }
      }
    }

    graphData.current = { nodes, links };
  }, [posts]);

  // Simple force simulation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { nodes, links } = graphData.current;
    if (nodes.length === 0) return;

    let animationFrame: number;

    const simulate = () => {
      // Apply forces
      nodes.forEach((node) => {
        // Center force
        const centerX = canvas.width / 2;
        const centerY = canvas.height / 2;
        const dx = centerX - (node.x || 0);
        const dy = centerY - (node.y || 0);
        node.vx = (node.vx || 0) + dx * 0.001;
        node.vy = (node.vy || 0) + dy * 0.001;
      });

      // Link forces
      links.forEach((link) => {
        const source = nodes.find((n) => n.id === link.source);
        const target = nodes.find((n) => n.id === link.target);
        if (!source || !target) return;

        const dx = (target.x || 0) - (source.x || 0);
        const dy = (target.y || 0) - (source.y || 0);
        const distance = Math.sqrt(dx * dx + dy * dy) || 1;
        const force = (distance - 100) * 0.01 * link.strength;

        const fx = (dx / distance) * force;
        const fy = (dy / distance) * force;

        source.vx = (source.vx || 0) + fx;
        source.vy = (source.vy || 0) + fy;
        target.vx = (target.vx || 0) - fx;
        target.vy = (target.vy || 0) - fy;
      });

      // Repulsion forces
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const node1 = nodes[i];
          const node2 = nodes[j];

          const dx = (node2.x || 0) - (node1.x || 0);
          const dy = (node2.y || 0) - (node1.y || 0);
          const distance = Math.sqrt(dx * dx + dy * dy) || 1;

          if (distance < 150) {
            const force = (150 - distance) * 0.05;
            const fx = (dx / distance) * force;
            const fy = (dy / distance) * force;

            node1.vx = (node1.vx || 0) - fx;
            node1.vy = (node1.vy || 0) - fy;
            node2.vx = (node2.vx || 0) + fx;
            node2.vy = (node2.vy || 0) + fy;
          }
        }
      }

      // Update positions
      nodes.forEach((node) => {
        node.x = (node.x || 0) + (node.vx || 0);
        node.y = (node.y || 0) + (node.vy || 0);
        node.vx = (node.vx || 0) * 0.9; // Damping
        node.vy = (node.vy || 0) * 0.9;
      });

      // Draw
      draw();

      animationFrame = requestAnimationFrame(simulate);
    };

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      ctx.save();
      ctx.translate(offset.x, offset.y);
      ctx.scale(zoom, zoom);

      // Draw links
      ctx.strokeStyle = 'rgba(100, 116, 139, 0.2)';
      ctx.lineWidth = 1;
      links.forEach((link) => {
        const source = nodes.find((n) => n.id === link.source);
        const target = nodes.find((n) => n.id === link.target);
        if (!source || !target) return;

        ctx.beginPath();
        ctx.moveTo(source.x || 0, source.y || 0);
        ctx.lineTo(target.x || 0, target.y || 0);
        ctx.stroke();
      });

      // Draw nodes
      nodes.forEach((node) => {
        const isCurrentPost = node.id === currentPostSlug;
        const isHovered = hoveredNode?.id === node.id;

        ctx.beginPath();
        ctx.arc(node.x || 0, node.y || 0, isCurrentPost ? 10 : 6, 0, Math.PI * 2);
        
        // Fill
        if (isCurrentPost) {
          ctx.fillStyle = '#3b82f6'; // Primary color
        } else if (isHovered) {
          ctx.fillStyle = '#10b981'; // Secondary color
        } else {
          ctx.fillStyle = '#1e293b';
        }
        ctx.fill();

        // Stroke
        ctx.strokeStyle = isCurrentPost || isHovered ? '#3b82f6' : '#334155';
        ctx.lineWidth = isCurrentPost || isHovered ? 3 : 1;
        ctx.stroke();

        // Label
        if (isCurrentPost || isHovered) {
          ctx.fillStyle = '#f8fafc';
          ctx.font = '12px Inter, sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText(
            node.label.length > 30 ? node.label.substring(0, 30) + '...' : node.label,
            node.x || 0,
            (node.y || 0) - 15
          );
        }
      });

      ctx.restore();
    };

    simulate();

    return () => {
      cancelAnimationFrame(animationFrame);
    };
  }, [zoom, offset, currentPostSlug, hoveredNode]);

  // Handle mouse interactions
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left - offset.x) / zoom;
    const y = (e.clientY - rect.top - offset.y) / zoom;

    if (isDragging) {
      setOffset({
        x: offset.x + (e.clientX - dragStart.x),
        y: offset.y + (e.clientY - dragStart.y),
      });
      setDragStart({ x: e.clientX, y: e.clientY });
      return;
    }

    // Check for hovered node
    const { nodes } = graphData.current;
    const hovered = nodes.find((node) => {
      const dx = (node.x || 0) - x;
      const dy = (node.y || 0) - y;
      return Math.sqrt(dx * dx + dy * dy) < 10;
    });

    setHoveredNode(hovered || null);
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left - offset.x) / zoom;
    const y = (e.clientY - rect.top - offset.y) / zoom;

    // Check if clicking on a node
    const { nodes } = graphData.current;
    const clicked = nodes.find((node) => {
      const dx = (node.x || 0) - x;
      const dy = (node.y || 0) - y;
      return Math.sqrt(dx * dx + dy * dy) < 10;
    });

    if (clicked) {
      navigate(`/posts/${clicked.id}`);
    } else {
      setIsDragging(true);
      setDragStart({ x: e.clientX, y: e.clientY });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleZoomIn = () => {
    setZoom((z) => Math.min(z + 0.2, 3));
  };

  const handleZoomOut = () => {
    setZoom((z) => Math.max(z - 0.2, 0.5));
  };

  const handleReset = () => {
    setZoom(1);
    setOffset({ x: 0, y: 0 });
  };

  return (
    <div className={`relative bg-vault-bg-elevated rounded-lg border border-vault-border-subtle overflow-hidden ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-vault-border-subtle bg-vault-bg-surface">
        <div className="flex items-center gap-2">
          <Network className="w-5 h-5 text-vault-accent-primary" />
          <h3 className="font-heading font-semibold text-vault-text-primary">
            Knowledge Graph
          </h3>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleZoomOut}
            className="p-1.5 text-vault-text-secondary hover:text-vault-text-primary transition-colors"
            aria-label="Zoom out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <button
            onClick={handleZoomIn}
            className="p-1.5 text-vault-text-secondary hover:text-vault-text-primary transition-colors"
            aria-label="Zoom in"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            onClick={handleReset}
            className="p-1.5 text-vault-text-secondary hover:text-vault-text-primary transition-colors"
            aria-label="Reset view"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Canvas */}
      <canvas
        ref={canvasRef}
        width={800}
        height={height}
        className="w-full cursor-grab active:cursor-grabbing"
        onMouseMove={handleMouseMove}
        onMouseDown={handleMouseDown}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      />

      {/* Tooltip */}
      {hoveredNode && (
        <div className="absolute bottom-4 left-4 px-3 py-2 bg-vault-bg-surface/90 backdrop-blur-sm border border-vault-border-subtle rounded-lg text-sm">
          <div className="font-medium text-vault-text-primary">{hoveredNode.label}</div>
          <div className="text-xs text-vault-text-muted">{hoveredNode.category}</div>
        </div>
      )}

      {/* Legend */}
      <div className="absolute top-16 right-4 px-3 py-2 bg-vault-bg-surface/90 backdrop-blur-sm border border-vault-border-subtle rounded-lg text-xs">
        <div className="flex items-center gap-2 mb-1">
          <div className="w-3 h-3 rounded-full bg-vault-accent-primary border-2 border-vault-accent-primary" />
          <span className="text-vault-text-secondary">Current Post</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-vault-bg-elevated border border-vault-border-default" />
          <span className="text-vault-text-secondary">Related Posts</span>
        </div>
      </div>
    </div>
  );
}
