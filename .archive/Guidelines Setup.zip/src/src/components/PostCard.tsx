import { Calendar, Clock, Star } from 'lucide-react';
import { Link } from './Link';
import { detectTextDirection } from '../utils/rtl';

interface PostCardProps {
  post: {
    title: string;
    subtitle?: string;
    slug: string;
    url: string;
    excerpt?: string;
    coverImage?: string;
    coverAlt?: string;
    date: string;
    readingTimeMinutes?: number;
    tags: string[];
    lang: string;
    featured?: boolean;
  };
  variant?: 'default' | 'compact' | 'wide';
  showImage?: boolean;
  showExcerpt?: boolean;
  className?: string;
}

export function PostCard({
  post,
  variant = 'default',
  showImage = true,
  showExcerpt = true,
  className = '',
}: PostCardProps) {
  const direction = detectTextDirection(post.title);
  const isRTL = direction === 'rtl';
  
  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays <= 7) {
      return `${diffDays} days ago`;
    }
    
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  const variantClasses = {
    default: 'flex flex-col',
    compact: 'flex flex-col',
    wide: 'flex flex-col md:flex-row md:items-center',
  };

  const imageClasses = {
    default: 'w-full aspect-[16/9]',
    compact: 'w-full aspect-[16/9]',
    wide: 'md:w-2/5 w-full aspect-[16/9] md:aspect-[2/1]',
  };

  const contentClasses = {
    default: 'p-6',
    compact: 'p-4',
    wide: 'p-6 md:w-3/5',
  };

  return (
    <article
      className={`group relative bg-vault-bg-surface rounded-lg border border-vault-border-subtle overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-card-hover hover:border-vault-accent-primary ${variantClasses[variant]} ${className}`}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Cover Image */}
      {showImage && post.coverImage && (
        <div className={`relative overflow-hidden ${imageClasses[variant]}`}>
          <img
            src={post.coverImage}
            alt={post.coverAlt || post.title}
            loading="lazy"
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-vault-bg-base/60 to-transparent" />
        </div>
      )}

      {/* Content */}
      <div className={contentClasses[variant]}>
        {/* Metadata */}
        <div className="flex items-center gap-3 mb-3 text-sm text-vault-text-muted">
          <div className="flex items-center gap-1">
            <Calendar className="w-3.5 h-3.5" />
            <time dateTime={post.date} aria-label={formatDate(post.date)}>
              {formatDate(post.date)}
            </time>
          </div>
          
          {post.readingTimeMinutes && (
            <>
              <span className="text-vault-border-default">•</span>
              <div className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                <span>{post.readingTimeMinutes} min read</span>
              </div>
            </>
          )}
          
          {post.lang && (
            <>
              <span className="text-vault-border-default">•</span>
              <span className="uppercase text-xs">{post.lang}</span>
            </>
          )}
        </div>

        {/* Title */}
        <h3
          className="mb-2 transition-all duration-300 group-hover:gradient-text line-clamp-2"
          style={{
            fontFamily: isRTL ? 'var(--font-rtl)' : 'var(--font-heading)',
          }}
        >
          <Link 
            to={post.url} 
            className="text-vault-text-primary hover:text-vault-accent-primary no-underline"
          >
            {post.title}
          </Link>
        </h3>

        {/* Subtitle */}
        {post.subtitle && (
          <p className="text-vault-text-muted text-sm mb-2 line-clamp-1">
            {post.subtitle}
          </p>
        )}

        {/* Excerpt */}
        {showExcerpt && post.excerpt && variant !== 'compact' && (
          <p className="text-vault-text-secondary mb-4 line-clamp-3">
            {post.excerpt}
          </p>
        )}

        {/* Tags */}
        {post.tags && post.tags.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {post.tags.slice(0, 3).map((tag) => (
              <Link
                key={tag}
                to={`/tags/${tag}`}
                className="px-2 py-1 text-xs bg-vault-bg-elevated text-vault-text-secondary rounded-md border border-vault-border-subtle hover:border-vault-accent-primary hover:text-vault-accent-primary transition-all no-underline"
              >
                #{tag}
              </Link>
            ))}
            {post.tags.length > 3 && (
              <span className="px-2 py-1 text-xs text-vault-text-muted">
                +{post.tags.length - 3} more
              </span>
            )}
          </div>
        )}
      </div>

      {/* Featured Badge */}
      {post.featured && (
        <div className="absolute top-4 right-4 bg-vault-accent-primary text-white p-2 rounded-full shadow-lg">
          <Star className="w-4 h-4 fill-current" />
        </div>
      )}
    </article>
  );
}