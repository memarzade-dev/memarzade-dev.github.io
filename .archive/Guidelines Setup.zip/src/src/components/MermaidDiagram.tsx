import { useEffect, useRef, useState } from 'react';

export interface MermaidDiagramProps {
  chart: string;
  className?: string;
}

export function MermaidDiagram({ chart, className = '' }: MermaidDiagramProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    async function renderDiagram() {
      try {
        // Dynamically import mermaid
        const mermaid = (await import('mermaid')).default;
        
        if (!mounted) return;

        // Initialize mermaid with dark theme
        mermaid.initialize({
          startOnLoad: false,
          theme: 'dark',
          themeVariables: {
            primaryColor: '#3b82f6',
            primaryTextColor: '#e2e8f0',
            primaryBorderColor: '#475569',
            lineColor: '#64748b',
            secondaryColor: '#10b981',
            tertiaryColor: '#8b5cf6',
            background: '#1e293b',
            mainBkg: '#1e293b',
            textColor: '#e2e8f0',
          },
          fontFamily: 'ui-monospace, monospace',
        });

        if (containerRef.current) {
          const id = `mermaid-${Math.random().toString(36).substr(2, 9)}`;
          const { svg } = await mermaid.render(id, chart);
          containerRef.current.innerHTML = svg;
          setLoading(false);
        }
      } catch (err) {
        if (mounted) {
          console.error('Mermaid rendering error:', err);
          setError('Failed to render diagram');
          setLoading(false);
        }
      }
    }

    renderDiagram();

    return () => {
      mounted = false;
    };
  }, [chart]);

  if (loading) {
    return (
      <div className={`flex items-center justify-center p-8 bg-vault-bg-elevated rounded-lg border border-vault-border-subtle ${className}`}>
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-4 border-vault-accent-primary border-t-transparent rounded-full animate-spin" />
          <span className="text-sm text-vault-text-muted">Loading diagram...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={`p-4 bg-vault-danger/10 border border-vault-danger rounded-lg ${className}`}>
        <p className="text-vault-danger text-sm">{error}</p>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className={`mermaid-diagram overflow-auto p-4 bg-vault-bg-elevated rounded-lg border border-vault-border-subtle ${className}`}
    />
  );
}
