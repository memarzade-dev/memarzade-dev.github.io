import { useState, useEffect, useRef } from 'react';
import { Check, Copy } from 'lucide-react';

export interface CodeBlockProps {
  code: string;
  language?: string;
  showLineNumbers?: boolean;
  className?: string;
}

export function CodeBlock({
  code,
  language = 'text',
  showLineNumbers = true,
  className = '',
}: CodeBlockProps) {
  const [copied, setCopied] = useState(false);
  const [highlighted, setHighlighted] = useState<string | null>(null);
  const codeRef = useRef<HTMLElement>(null);

  useEffect(() => {
    let mounted = true;

    async function highlightCode() {
      try {
        // Dynamically import Prism
        const Prism = (await import('prismjs')).default;
        
        // Import common language support
        await import('prismjs/components/prism-typescript');
        await import('prismjs/components/prism-javascript');
        await import('prismjs/components/prism-jsx');
        await import('prismjs/components/prism-tsx');
        await import('prismjs/components/prism-css');
        await import('prismjs/components/prism-json');
        await import('prismjs/components/prism-markdown');
        await import('prismjs/components/prism-bash');
        await import('prismjs/components/prism-python');
        await import('prismjs/components/prism-rust');
        await import('prismjs/components/prism-go');
        
        // Import Prism theme CSS
        await import('prismjs/themes/prism-tomorrow.css');

        if (!mounted) return;

        // Get the correct language identifier
        const lang = language.toLowerCase();
        const grammar = Prism.languages[lang] || Prism.languages.text;

        // Highlight the code
        const highlightedCode = Prism.highlight(code, grammar, lang);
        setHighlighted(highlightedCode);
      } catch (err) {
        console.error('Syntax highlighting error:', err);
        // Fallback to plain code
        setHighlighted(code);
      }
    }

    highlightCode();

    return () => {
      mounted = false;
    };
  }, [code, language]);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy code:', err);
    }
  };

  const lines = code.split('\n');

  return (
    <div className={`relative group ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2 bg-vault-bg-elevated border-b border-vault-border-subtle rounded-t-lg">
        <span className="text-xs text-vault-text-muted uppercase font-mono">
          {language}
        </span>
        <button
          onClick={handleCopy}
          className="flex items-center gap-1.5 px-2 py-1 text-xs text-vault-text-secondary hover:text-vault-text-primary bg-vault-bg-hover rounded transition-all hover:bg-vault-bg-surface"
          aria-label="Copy code"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-vault-success" />
              <span>Copied!</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>Copy</span>
            </>
          )}
        </button>
      </div>

      {/* Code Content */}
      <div className="relative overflow-x-auto">
        <pre className="p-4 bg-vault-bg-elevated rounded-b-lg">
          {highlighted ? (
            showLineNumbers ? (
              <code className="text-sm font-mono">
                <table className="w-full">
                  <tbody>
                    {highlighted.split('\n').map((line, index) => (
                      <tr key={index}>
                        <td className="pr-4 text-right text-vault-text-muted select-none w-8">
                          {index + 1}
                        </td>
                        <td
                          className="text-vault-text-primary"
                          dangerouslySetInnerHTML={{ __html: line || '<br/>' }}
                        />
                      </tr>
                    ))}
                  </tbody>
                </table>
              </code>
            ) : (
              <code
                ref={codeRef}
                className="text-sm font-mono"
                dangerouslySetInnerHTML={{ __html: highlighted }}
              />
            )
          ) : (
            <code className="text-sm font-mono text-vault-text-primary">
              {showLineNumbers ? (
                <table className="w-full">
                  <tbody>
                    {lines.map((line, index) => (
                      <tr key={index}>
                        <td className="pr-4 text-right text-vault-text-muted select-none w-8">
                          {index + 1}
                        </td>
                        <td className="text-vault-text-primary">
                          {line || '\n'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                code
              )}
            </code>
          )}
        </pre>
      </div>
    </div>
  );
}