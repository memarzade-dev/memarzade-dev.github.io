import { useState } from 'react';
import { Share2, Twitter, Linkedin, Facebook, Link as LinkIcon, Check } from 'lucide-react';

export interface SocialShareProps {
  url: string;
  title: string;
  description?: string;
  className?: string;
}

export function SocialShare({
  url,
  title,
  description = '',
  className = '',
}: SocialShareProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  const encodedUrl = encodeURIComponent(url);
  const encodedTitle = encodeURIComponent(title);
  const encodedDescription = encodeURIComponent(description);

  const shareLinks = [
    {
      name: 'Twitter',
      icon: Twitter,
      url: `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedTitle}`,
      color: 'hover:text-[#1DA1F2]',
    },
    {
      name: 'LinkedIn',
      icon: Linkedin,
      url: `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`,
      color: 'hover:text-[#0A66C2]',
    },
    {
      name: 'Facebook',
      icon: Facebook,
      url: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`,
      color: 'hover:text-[#1877F2]',
    },
  ];

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy link:', err);
    }
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title,
          text: description,
          url,
        });
        setIsOpen(false);
      } catch (err) {
        // User cancelled or error occurred
        console.error('Share failed:', err);
      }
    }
  };

  return (
    <div className={`relative ${className}`}>
      <button
        onClick={() => {
          // Use native share if available on mobile
          if (navigator.share && window.innerWidth < 768) {
            handleNativeShare();
          } else {
            setIsOpen(!isOpen);
          }
        }}
        className="flex items-center gap-2 px-3 py-2 text-sm text-vault-text-secondary hover:text-vault-text-primary bg-vault-bg-elevated border border-vault-border-subtle rounded-md transition-all hover:border-vault-accent-primary"
        aria-label="Share this post"
      >
        <Share2 className="w-4 h-4" />
        <span className="hidden sm:inline">Share</span>
      </button>

      {/* Dropdown */}
      {isOpen && (
        <>
          <div
            className="fixed inset-0 z-40"
            onClick={() => setIsOpen(false)}
          />
          <div className="absolute right-0 top-full mt-2 w-56 bg-vault-bg-surface border border-vault-border-subtle rounded-lg shadow-lg z-50 overflow-hidden">
            <div className="p-2 space-y-1">
              {/* Social platforms */}
              {shareLinks.map((platform) => {
                const Icon = platform.icon;
                return (
                  <a
                    key={platform.name}
                    href={platform.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`flex items-center gap-3 px-3 py-2 text-vault-text-secondary ${platform.color} rounded transition-colors hover:bg-vault-bg-hover`}
                    onClick={() => setIsOpen(false)}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{platform.name}</span>
                  </a>
                );
              })}

              {/* Divider */}
              <div className="h-px bg-vault-border-subtle my-1" />

              {/* Copy link */}
              <button
                onClick={handleCopyLink}
                className="w-full flex items-center gap-3 px-3 py-2 text-vault-text-secondary hover:text-vault-text-primary rounded transition-colors hover:bg-vault-bg-hover"
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4 text-vault-success" />
                    <span>Link copied!</span>
                  </>
                ) : (
                  <>
                    <LinkIcon className="w-4 h-4" />
                    <span>Copy link</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
