import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

export interface AnalyticsProps {
  trackingId?: string;
}

export function Analytics({ trackingId }: AnalyticsProps) {
  const location = useLocation();

  useEffect(() => {
    if (!trackingId || import.meta.env.DEV) {
      return;
    }

    // Load Google Analytics script
    const script = document.createElement('script');
    script.src = `https://www.googletagmanager.com/gtag/js?id=${trackingId}`;
    script.async = true;
    document.head.appendChild(script);

    // Initialize gtag
    window.dataLayer = window.dataLayer || [];
    function gtag(...args: any[]) {
      window.dataLayer.push(args);
    }
    gtag('js', new Date());
    gtag('config', trackingId, {
      page_path: location.pathname + location.search,
    });

    // Store gtag in window
    window.gtag = gtag as any;
  }, [trackingId]);

  // Track page views on route change
  useEffect(() => {
    if (window.gtag && trackingId) {
      window.gtag('config', trackingId, {
        page_path: location.pathname + location.search,
      });
    }
  }, [location, trackingId]);

  return null;
}

// Analytics tracking functions
export function trackEvent(
  action: string,
  category: string,
  label?: string,
  value?: number
): void {
  if (window.gtag) {
    window.gtag('event', action, {
      event_category: category,
      event_label: label,
      value: value,
    });
  }
}

export function trackPageView(path: string, title?: string): void {
  if (window.gtag) {
    window.gtag('event', 'page_view', {
      page_path: path,
      page_title: title,
    });
  }
}

export function trackSearch(searchTerm: string, resultsCount: number): void {
  trackEvent('search', 'Search', searchTerm, resultsCount);
}

export function trackPostView(slug: string, title: string, category?: string): void {
  trackEvent('view_post', 'Engagement', title);
  
  if (window.gtag) {
    window.gtag('event', 'view_item', {
      items: [
        {
          item_id: slug,
          item_name: title,
          item_category: category,
        },
      ],
    });
  }
}

export function trackShare(platform: string, postTitle: string): void {
  trackEvent('share', 'Social', `${platform} - ${postTitle}`);
}

export function trackBookmark(action: 'add' | 'remove', postTitle: string): void {
  trackEvent(`bookmark_${action}`, 'Engagement', postTitle);
}

// Type declarations
declare global {
  interface Window {
    dataLayer: any[];
    gtag?: (...args: any[]) => void;
  }
}
