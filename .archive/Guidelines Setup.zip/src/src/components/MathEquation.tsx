import { useEffect, useRef, useState } from 'react';

export interface MathEquationProps {
  math: string;
  display?: boolean;
  className?: string;
}

export function MathEquation({ math, display = false, className = '' }: MathEquationProps) {
  const containerRef = useRef<HTMLSpanElement>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    async function renderMath() {
      try {
        // Dynamically import katex
        const katex = (await import('katex')).default;
        await import('katex/dist/katex.min.css');

        if (!mounted || !containerRef.current) return;

        katex.render(math, containerRef.current, {
          displayMode: display,
          throwOnError: false,
          errorColor: '#ef4444',
          strict: false,
          trust: false,
          output: 'html',
        });

        setLoading(false);
      } catch (err) {
        if (mounted) {
          console.error('KaTeX rendering error:', err);
          setError('Failed to render equation');
          setLoading(false);
        }
      }
    }

    renderMath();

    return () => {
      mounted = false;
    };
  }, [math, display]);

  if (loading) {
    return (
      <span className={`inline-flex items-center gap-2 px-2 py-1 bg-vault-bg-elevated rounded text-sm text-vault-text-muted ${className}`}>
        <span className="w-3 h-3 border-2 border-vault-accent-primary border-t-transparent rounded-full animate-spin" />
        Loading equation...
      </span>
    );
  }

  if (error) {
    return (
      <span className={`inline-block px-2 py-1 bg-vault-danger/10 border border-vault-danger rounded text-sm text-vault-danger ${className}`}>
        {error}
      </span>
    );
  }

  return (
    <span
      ref={containerRef}
      className={`math-equation ${display ? 'block my-4 overflow-x-auto' : 'inline'} ${className}`}
    />
  );
}
