import { useState } from 'react';
import { Eye, EyeOff, BookOpen, Maximize2 } from 'lucide-react';

export type ReadingModeType = 'default' | 'focus' | 'comfort';

export interface ReadingModeProps {
  currentMode: ReadingModeType;
  onModeChange: (mode: ReadingModeType) => void;
  className?: string;
}

export function ReadingMode({
  currentMode,
  onModeChange,
  className = '',
}: ReadingModeProps) {
  const [isOpen, setIsOpen] = useState(false);

  const modes = [
    {
      type: 'default' as ReadingModeType,
      label: 'Default',
      icon: Eye,
      description: 'Standard layout with all UI elements',
    },
    {
      type: 'focus' as ReadingModeType,
      label: 'Focus',
      icon: Maximize2,
      description: 'Hide sidebars for distraction-free reading',
    },
    {
      type: 'comfort' as ReadingModeType,
      label: 'Comfort',
      icon: BookOpen,
      description: 'Optimized line length and spacing',
    },
  ];

  return (
    <div className={`relative ${className}`}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 text-sm text-vault-text-secondary hover:text-vault-text-primary bg-vault-bg-elevated border border-vault-border-subtle rounded-md transition-all hover:border-vault-accent-primary"
        aria-label="Reading mode options"
      >
        {currentMode === 'focus' && <Maximize2 className="w-4 h-4" />}
        {currentMode === 'comfort' && <BookOpen className="w-4 h-4" />}
        {currentMode === 'default' && <Eye className="w-4 h-4" />}
        <span className="hidden sm:inline">Reading Mode</span>
      </button>

      {/* Dropdown */}
      {isOpen && (
        <>
          <div
            className="fixed inset-0 z-40"
            onClick={() => setIsOpen(false)}
          />
          <div className="absolute right-0 top-full mt-2 w-64 bg-vault-bg-surface border border-vault-border-subtle rounded-lg shadow-lg z-50 overflow-hidden">
            {modes.map((mode) => {
              const Icon = mode.icon;
              const isActive = currentMode === mode.type;

              return (
                <button
                  key={mode.type}
                  onClick={() => {
                    onModeChange(mode.type);
                    setIsOpen(false);
                  }}
                  className={`w-full flex items-start gap-3 px-4 py-3 text-left transition-colors ${
                    isActive
                      ? 'bg-vault-accent-primary/10 text-vault-accent-primary'
                      : 'text-vault-text-secondary hover:bg-vault-bg-hover hover:text-vault-text-primary'
                  }`}
                >
                  <Icon className="w-5 h-5 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <div className="font-medium mb-0.5">{mode.label}</div>
                    <div className="text-xs text-vault-text-muted">
                      {mode.description}
                    </div>
                  </div>
                  {isActive && (
                    <div className="w-2 h-2 rounded-full bg-vault-accent-primary mt-2" />
                  )}
                </button>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}
