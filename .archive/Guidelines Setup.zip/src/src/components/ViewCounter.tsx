import { Eye } from 'lucide-react';
import { useViewCount } from '../hooks/useViewCount';

export interface ViewCounterProps {
  slug: string;
  className?: string;
  showIcon?: boolean;
}

export function ViewCounter({ slug, className = '', showIcon = true }: ViewCounterProps) {
  const viewCount = useViewCount(slug);

  return (
    <div className={`flex items-center gap-1.5 text-vault-text-muted ${className}`}>
      {showIcon && <Eye className="w-4 h-4" />}
      <span className="text-sm">
        {viewCount} view{viewCount !== 1 ? 's' : ''}
      </span>
    </div>
  );
}
