import { useEffect, useState } from 'react';

export interface ReadingProgressProps {
  targetRef?: React.RefObject<HTMLElement>;
  className?: string;
  showPercentage?: boolean;
}

export function ReadingProgress({
  targetRef,
  className = '',
  showPercentage = false,
}: ReadingProgressProps) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const calculateProgress = () => {
      const target = targetRef?.current || document.documentElement;
      const totalHeight = target.scrollHeight - target.clientHeight;
      const windowScrollTop = targetRef?.current 
        ? target.scrollTop 
        : window.pageYOffset || document.documentElement.scrollTop;
      
      if (totalHeight > 0) {
        const scrollProgress = (windowScrollTop / totalHeight) * 100;
        setProgress(Math.min(100, Math.max(0, scrollProgress)));
      }
    };

    const handleScroll = () => {
      window.requestAnimationFrame(calculateProgress);
    };

    const scrollElement = targetRef?.current || window;
    scrollElement.addEventListener('scroll', handleScroll as any);
    calculateProgress(); // Initial calculation

    return () => {
      scrollElement.removeEventListener('scroll', handleScroll as any);
    };
  }, [targetRef]);

  return (
    <div className={`fixed top-0 left-0 right-0 z-50 ${className}`}>
      {/* Progress Bar */}
      <div className="h-1 bg-vault-bg-elevated/50 backdrop-blur-sm">
        <div
          className="h-full bg-gradient-to-r from-vault-accent-primary to-vault-accent-secondary transition-all duration-150 ease-out"
          style={{ width: `${progress}%` }}
          role="progressbar"
          aria-valuenow={Math.round(progress)}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-label="Reading progress"
        />
      </div>

      {/* Optional Percentage Display */}
      {showPercentage && progress > 0 && (
        <div className="absolute top-2 right-4 px-2 py-1 bg-vault-bg-elevated/90 backdrop-blur-sm border border-vault-border-subtle rounded text-xs text-vault-text-secondary">
          {Math.round(progress)}%
        </div>
      )}
    </div>
  );
}
