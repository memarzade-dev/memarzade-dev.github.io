import { ChevronRight, Home } from 'lucide-react';
import { Link } from './Link';

export interface BreadcrumbItem {
  label: string;
  href: string;
}

export interface BreadcrumbsProps {
  items: BreadcrumbItem[];
  className?: string;
}

export function Breadcrumbs({ items, className = '' }: BreadcrumbsProps) {
  return (
    <nav
      aria-label="Breadcrumb"
      className={`flex items-center gap-2 text-sm ${className}`}
    >
      {/* Home */}
      <Link
        to="/"
        className="text-vault-text-muted hover:text-vault-text-primary transition-colors flex items-center gap-1"
        aria-label="Home"
      >
        <Home className="w-4 h-4" />
      </Link>

      {items.map((item, index) => {
        const isLast = index === items.length - 1;
        
        return (
          <div key={item.href} className="flex items-center gap-2">
            <ChevronRight className="w-4 h-4 text-vault-text-muted" />
            {isLast ? (
              <span className="text-vault-text-primary font-medium">
                {item.label}
              </span>
            ) : (
              <Link
                to={item.href}
                className="text-vault-text-muted hover:text-vault-text-primary transition-colors"
              >
                {item.label}
              </Link>
            )}
          </div>
        );
      })}
    </nav>
  );
}
