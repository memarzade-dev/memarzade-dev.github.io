import { useState } from 'react';
import {
  Info,
  Lightbulb,
  AlertTriangle,
  AlertOctagon,
  Quote,
  Code,
  HelpCircle,
  CheckCircle,
  XCircle,
  Bug,
  ChevronDown,
} from 'lucide-react';

export type CalloutVariant =
  | 'note'
  | 'tip'
  | 'warning'
  | 'danger'
  | 'info'
  | 'quote'
  | 'example'
  | 'question'
  | 'success'
  | 'failure'
  | 'bug';

interface CalloutProps {
  variant: CalloutVariant;
  title?: string;
  collapsible?: boolean;
  defaultCollapsed?: boolean;
  icon?: React.ReactNode;
  className?: string;
  children: React.ReactNode;
}

const iconMap: Record<CalloutVariant, React.ComponentType<{ className?: string }>> = {
  note: Info,
  tip: Lightbulb,
  warning: AlertTriangle,
  danger: AlertOctagon,
  info: Info,
  quote: Quote,
  example: Code,
  question: HelpCircle,
  success: CheckCircle,
  failure: XCircle,
  bug: Bug,
};

const variantStyles: Record<CalloutVariant, { border: string; bg: string; text: string }> = {
  note: {
    border: 'border-l-vault-info',
    bg: 'bg-vault-info/10',
    text: 'text-vault-info',
  },
  tip: {
    border: 'border-l-vault-success',
    bg: 'bg-vault-success/10',
    text: 'text-vault-success',
  },
  warning: {
    border: 'border-l-vault-warning',
    bg: 'bg-vault-warning/10',
    text: 'text-vault-warning',
  },
  danger: {
    border: 'border-l-vault-danger',
    bg: 'bg-vault-danger/10',
    text: 'text-vault-danger',
  },
  info: {
    border: 'border-l-vault-info',
    bg: 'bg-vault-info/10',
    text: 'text-vault-info',
  },
  quote: {
    border: 'border-l-vault-text-muted',
    bg: 'bg-vault-bg-elevated',
    text: 'text-vault-text-muted',
  },
  example: {
    border: 'border-l-vault-accent-secondary',
    bg: 'bg-vault-accent-secondary/10',
    text: 'text-vault-accent-secondary',
  },
  question: {
    border: 'border-l-vault-info',
    bg: 'bg-vault-info/10',
    text: 'text-vault-info',
  },
  success: {
    border: 'border-l-vault-success',
    bg: 'bg-vault-success/10',
    text: 'text-vault-success',
  },
  failure: {
    border: 'border-l-vault-danger',
    bg: 'bg-vault-danger/10',
    text: 'text-vault-danger',
  },
  bug: {
    border: 'border-l-vault-warning',
    bg: 'bg-vault-warning/10',
    text: 'text-vault-warning',
  },
};

export function Callout({
  variant,
  title,
  collapsible = false,
  defaultCollapsed = false,
  icon,
  className = '',
  children,
}: CalloutProps) {
  const [isOpen, setIsOpen] = useState(!defaultCollapsed);
  const Icon = iconMap[variant];
  const styles = variantStyles[variant];

  return (
    <aside
      className={`rounded-lg border-l-4 ${styles.border} ${styles.bg} p-4 my-6 ${className}`}
      role="note"
      aria-label={`${variant} callout`}
    >
      <div
        className={`flex items-center gap-2 ${collapsible ? 'cursor-pointer' : ''}`}
        onClick={collapsible ? () => setIsOpen(!isOpen) : undefined}
        onKeyDown={
          collapsible
            ? (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  setIsOpen(!isOpen);
                }
              }
            : undefined
        }
        tabIndex={collapsible ? 0 : undefined}
        role={collapsible ? 'button' : undefined}
        aria-expanded={collapsible ? isOpen : undefined}
      >
        {icon || <Icon className={`w-5 h-5 ${styles.text}`} />}
        {title && (
          <span className={`font-semibold ${styles.text}`} style={{ fontFamily: 'var(--font-heading)' }}>
            {title}
          </span>
        )}
        {collapsible && (
          <ChevronDown
            className={`w-4 h-4 ml-auto transition-transform ${styles.text} ${
              isOpen ? 'rotate-180' : ''
            }`}
          />
        )}
      </div>

      {isOpen && (
        <div className="mt-3 text-vault-text-primary prose-sm">
          {children}
        </div>
      )}
    </aside>
  );
}
