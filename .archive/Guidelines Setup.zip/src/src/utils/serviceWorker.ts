// Service Worker Registration Utilities
// ابزارهای ثبت و مدیریت Service Worker برای قابلیت آفلاین

/**
 * Service Worker Registration Utilities
 * 
 * ابزارهای ثبت و مدیریت Service Worker برای قابلیت آفلاین
 */

/**
 * Register service worker
 * ثبت service worker برای پشتیبانی آفلاین
 */
export function registerServiceWorker(): void {
  // Check if service worker is supported and we're in production
  const isProduction = typeof import.meta !== 'undefined' && 
                       import.meta.env && 
                       import.meta.env.PROD === true;
  
  if ('serviceWorker' in navigator && isProduction) {
    window.addEventListener('load', () => {
      navigator.serviceWorker
        .register('/service-worker.js')
        .then((registration) => {
          console.log('✅ Service Worker registered:', registration.scope);

          // Check for updates periodically
          setInterval(() => {
            registration.update();
          }, 60 * 60 * 1000); // Check every hour

          // Handle updates
          registration.addEventListener('updatefound', () => {
            const newWorker = registration.installing;
            if (newWorker) {
              newWorker.addEventListener('statechange', () => {
                if (
                  newWorker.state === 'installed' &&
                  navigator.serviceWorker.controller
                ) {
                  // New service worker available
                  console.log('🔄 New content available, please refresh.');
                  
                  // Optionally show a notification to the user
                  if (window.confirm('New version available! Reload to update?')) {
                    newWorker.postMessage({ type: 'SKIP_WAITING' });
                    window.location.reload();
                  }
                }
              });
            }
          });
        })
        .catch((error) => {
          console.error('❌ Service Worker registration failed:', error);
        });

      // Handle controller change (after skipWaiting)
      navigator.serviceWorker.addEventListener('controllerchange', () => {
        window.location.reload();
      });
    });
  }
}

/**
 * Unregister service worker
 * حذف ثبت service worker
 */
export function unregisterServiceWorker(): Promise<boolean> {
  if ('serviceWorker' in navigator) {
    return navigator.serviceWorker
      .getRegistrations()
      .then((registrations) => {
        return Promise.all(
          registrations.map((registration) => registration.unregister())
        ).then(() => true);
      })
      .catch((error) => {
        console.error('❌ Service Worker unregistration failed:', error);
        return false;
      });
  }
  return Promise.resolve(false);
}

/**
 * Check service worker status
 * بررسی وضعیت service worker
 */
export function checkServiceWorkerStatus(): Promise<boolean> {
  if ('serviceWorker' in navigator) {
    return navigator.serviceWorker.getRegistration().then((registration) => {
      return !!registration;
    });
  }
  return Promise.resolve(false);
}

/**
 * Check for service worker updates
 * بررسی به‌روزرسانی‌های service worker
 */
export function checkForUpdates(): void {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.getRegistration().then((registration) => {
      if (registration) {
        registration.update();
      }
    });
  }
}

/**
 * Initialize performance monitoring
 * راه‌اندازی نظارت بر عملکرد (placeholder for backward compatibility)
 */
export function initPerformanceMonitoring(): void {
  // This function is kept for backward compatibility
  // Actual implementation is in performance.ts
  if (typeof import.meta !== 'undefined' && import.meta.env && import.meta.env.DEV) {
    console.log('📊 Performance monitoring initialized');
  }
}