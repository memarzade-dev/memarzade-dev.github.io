// Markdown file loader with frontmatter parsing
// This utility loads markdown files from the /posts directory and parses their frontmatter

export interface MarkdownPost {
  slug: string;
  content: string;
  frontmatter: {
    title: string;
    subtitle?: string;
    date: string;
    category: string;
    tags: string[];
    author?: string;
    excerpt?: string;
    coverImage?: string;
    featured?: boolean;
    draft?: boolean;
    readingTime?: number;
    relatedPosts?: string[];
    [key: string]: any;
  };
}

// This is a placeholder for dynamic import-based markdown loading
// In a real build setup, you would use Vite's glob import feature:
// const modules = import.meta.glob('/posts/**/*.md', { as: 'raw' })

export async function loadMarkdownFile(slug: string): Promise<MarkdownPost | null> {
  try {
    // Dynamic import using Vite's glob import
    // This would be configured in vite.config.ts to load markdown files
    const modules = import.meta.glob('/posts/**/*.md', { as: 'raw', eager: false });
    
    // Find the matching file
    const filePath = Object.keys(modules).find(path => 
      path.includes(`/${slug}.md`)
    );
    
    if (!filePath) {
      return null;
    }
    
    // Load the file content
    const loadModule = modules[filePath];
    const rawContent = await loadModule() as string;
    
    // Parse frontmatter and content
    const parsed = parseFrontmatter(rawContent);
    
    return {
      slug,
      content: parsed.content,
      frontmatter: parsed.frontmatter as MarkdownPost['frontmatter'],
    };
  } catch (error) {
    console.error(`Error loading markdown file ${slug}:`, error);
    return null;
  }
}

export async function loadAllMarkdownFiles(): Promise<MarkdownPost[]> {
  try {
    // Dynamic import using Vite's glob import
    const modules = import.meta.glob('/posts/**/*.md', { as: 'raw', eager: false });
    
    const posts: MarkdownPost[] = [];
    
    for (const [filePath, loadModule] of Object.entries(modules)) {
      try {
        const rawContent = await loadModule() as string;
        const parsed = parseFrontmatter(rawContent);
        
        // Extract slug from file path
        const slug = filePath
          .replace('/posts/', '')
          .replace('.md', '')
          .split('/')
          .pop() || '';
        
        // Skip draft posts in production
        if (parsed.frontmatter.draft && import.meta.env.PROD) {
          continue;
        }
        
        posts.push({
          slug,
          content: parsed.content,
          frontmatter: parsed.frontmatter as MarkdownPost['frontmatter'],
        });
      } catch (error) {
        console.error(`Error loading ${filePath}:`, error);
      }
    }
    
    // Sort by date (newest first)
    return posts.sort((a, b) => 
      new Date(b.frontmatter.date).getTime() - new Date(a.frontmatter.date).getTime()
    );
  } catch (error) {
    console.error('Error loading markdown files:', error);
    return [];
  }
}

// Simple frontmatter parser (similar to gray-matter)
export function parseFrontmatter(content: string): {
  frontmatter: Record<string, any>;
  content: string;
} {
  const frontmatterRegex = /^---\s*\n([\s\S]*?)\n---\s*\n([\s\S]*)$/;
  const match = content.match(frontmatterRegex);
  
  if (!match) {
    return {
      frontmatter: {},
      content: content,
    };
  }
  
  const [, frontmatterString, bodyContent] = match;
  const frontmatter: Record<string, any> = {};
  
  // Parse YAML-like frontmatter
  const lines = frontmatterString.split('\n');
  let currentKey = '';
  let currentArray: string[] = [];
  
  for (const line of lines) {
    const trimmed = line.trim();
    
    if (!trimmed) continue;
    
    // Handle array items
    if (trimmed.startsWith('-')) {
      const value = trimmed.substring(1).trim();
      currentArray.push(value);
      continue;
    }
    
    // Handle key-value pairs
    const colonIndex = trimmed.indexOf(':');
    if (colonIndex > 0) {
      // Save previous array if exists
      if (currentKey && currentArray.length > 0) {
        frontmatter[currentKey] = currentArray;
        currentArray = [];
      }
      
      const key = trimmed.substring(0, colonIndex).trim();
      const value = trimmed.substring(colonIndex + 1).trim();
      
      currentKey = key;
      
      if (value) {
        // Parse boolean
        if (value === 'true') {
          frontmatter[key] = true;
        } else if (value === 'false') {
          frontmatter[key] = false;
        }
        // Parse number
        else if (!isNaN(Number(value))) {
          frontmatter[key] = Number(value);
        }
        // Parse string (remove quotes)
        else {
          frontmatter[key] = value.replace(/^['"]|['"]$/g, '');
        }
      }
    }
  }
  
  // Save last array if exists
  if (currentKey && currentArray.length > 0) {
    frontmatter[currentKey] = currentArray;
  }
  
  return {
    frontmatter,
    content: bodyContent.trim(),
  };
}

// Calculate reading time from content
export function calculateReadingTime(content: string): number {
  const wordsPerMinute = 200;
  const words = content.trim().split(/\s+/).length;
  return Math.ceil(words / wordsPerMinute);
}

// Get posts by category
export function getPostsByCategory(posts: MarkdownPost[], category: string): MarkdownPost[] {
  return posts.filter(post => 
    post.frontmatter.category.toLowerCase() === category.toLowerCase()
  );
}

// Get posts by tag
export function getPostsByTag(posts: MarkdownPost[], tag: string): MarkdownPost[] {
  return posts.filter(post => 
    post.frontmatter.tags?.some(t => t.toLowerCase() === tag.toLowerCase())
  );
}

// Get featured posts
export function getFeaturedPosts(posts: MarkdownPost[]): MarkdownPost[] {
  return posts.filter(post => post.frontmatter.featured === true);
}

// Get related posts
export function getRelatedPosts(posts: MarkdownPost[], currentPost: MarkdownPost, limit: number = 3): MarkdownPost[] {
  const scores = posts
    .filter(post => post.slug !== currentPost.slug)
    .map(post => {
      let score = 0;
      
      // Same category: +10 points
      if (post.frontmatter.category === currentPost.frontmatter.category) {
        score += 10;
      }
      
      // Shared tags: +5 points each
      const sharedTags = post.frontmatter.tags?.filter(tag =>
        currentPost.frontmatter.tags?.includes(tag)
      ) || [];
      score += sharedTags.length * 5;
      
      return { post, score };
    })
    .filter(({ score }) => score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
  
  return scores.map(({ post }) => post);
}
