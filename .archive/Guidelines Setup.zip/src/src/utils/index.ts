/**
 * Utils Index - نقطه ورود مرکزی برای تمام utility functions
 * 
 * این فایل تمام توابع کمکی را export می‌کند تا import آسان‌تر شود
 * 
 * @example
 * import { detectTextDirection, searchPosts } from '@/utils';
 */

// RTL/LTR Detection
export { detectTextDirection, getFontFamily } from './rtl';

// Search Utilities
export { searchPosts, createSearchIndex } from './search';

// Service Worker
export {
  registerServiceWorker,
  unregisterServiceWorker,
  checkForUpdates,
  checkServiceWorkerStatus,
} from './serviceWorker';

// Performance Monitoring
export {
  logPerformanceMetrics,
  initPerformanceMonitoring,
  trackWebVitals,
  measurePageLoad,
  measureWebVitals,
  reportToAnalytics,
} from './performance';
export type { PerformanceMetrics } from './performance';

// Markdown Loading
export {
  loadMarkdownFile,
  loadAllMarkdownFiles,
  parseFrontmatter,
  calculateReadingTime,
  getPostsByCategory,
  getPostsByTag,
  getFeaturedPosts,
  getRelatedPosts,
} from './markdownLoader';
export type { MarkdownPost } from './markdownLoader';

// RSS Feed Generation
export {
  generateRSSFeed,
  generateBlogRSS,
  saveRSSFeed,
} from './rss';
export type { RSSItem, RSSFeedConfig } from './rss';

// Sitemap Generation
export {
  generateSitemap,
  generateBlogSitemap,
  saveSitemap,
} from './sitemap';
export type { SitemapURL } from './sitemap';

// Constants
export * from './constants';