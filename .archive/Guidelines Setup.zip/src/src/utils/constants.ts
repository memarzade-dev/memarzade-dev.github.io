/**
 * Constants - ثوابت و تنظیمات ثابت اپلیکیشن
 * 
 * این فایل تمام ثوابت مورد استفاده در پروژه را در یک مکان مرکزی نگه می‌دارد
 */

/**
 * اطلاعات سایت
 */
export const SITE_INFO = {
  title: 'Vaults: A Developer\'s Free Code License',
  shortTitle: 'Vaults',
  description: 'AWWWARDS-level personal blog and digital garden for deep technical content',
  author: 'Memarzade',
  email: 'contact@memarzade.dev',
  url: import.meta.env.VITE_SITE_URL || 'https://vaults.memarzade.dev',
  version: '9.0.0',
} as const;

/**
 * تنظیمات Google Analytics
 */
export const ANALYTICS = {
  trackingId: import.meta.env.VITE_GA_TRACKING_ID || '',
  enabled: import.meta.env.VITE_ENABLE_ANALYTICS === 'true',
} as const;

/**
 * تنظیمات Service Worker
 */
export const SERVICE_WORKER = {
  enabled: import.meta.env.VITE_ENABLE_SERVICE_WORKER === 'true',
  cacheName: 'vaults-cache-v1',
  cacheUrls: [
    '/',
    '/index.html',
    '/offline.html',
    '/manifest.json',
  ],
} as const;

/**
 * تنظیمات Performance Monitoring
 */
export const PERFORMANCE = {
  enabled: import.meta.env.VITE_ENABLE_PERFORMANCE_MONITORING === 'true',
  logInDevelopment: true,
  webVitalsThresholds: {
    fcp: { good: 1800, needsImprovement: 3000 },
    lcp: { good: 2500, needsImprovement: 4000 },
    fid: { good: 100, needsImprovement: 300 },
    cls: { good: 0.1, needsImprovement: 0.25 },
  },
} as const;

/**
 * تنظیمات localStorage
 */
export const STORAGE_KEYS = {
  theme: 'vaults-theme',
  bookmarks: 'vaults-bookmarks',
  history: 'vaults-history',
  viewCounts: 'vaults-view-counts',
  readingProgress: 'vaults-reading-progress',
} as const;

/**
 * تنظیمات جستجو
 */
export const SEARCH_CONFIG = {
  minLength: 2,
  maxResults: 50,
  threshold: 0.4,
  keys: [
    { name: 'title', weight: 3 },
    { name: 'tags', weight: 2 },
    { name: 'content', weight: 1 },
    { name: 'excerpt', weight: 2 },
    { name: 'category', weight: 1.5 },
  ],
} as const;

/**
 * تنظیمات Reading History
 */
export const HISTORY_CONFIG = {
  maxItems: 20,
  saveProgressThreshold: 0.1, // حداقل 10% خوانده شده باشد
} as const;

/**
 * تنظیمات Related Posts
 */
export const RELATED_POSTS_CONFIG = {
  maxItems: 3,
  sameCategoryScore: 10,
  sharedTagScore: 5,
  minScore: 0,
} as const;

/**
 * تنظیمات Knowledge Graph
 */
export const GRAPH_CONFIG = {
  canvas: {
    width: 1200,
    height: 800,
    minZoom: 0.5,
    maxZoom: 2,
  },
  physics: {
    repulsionStrength: 5000,
    springLength: 100,
    springStrength: 0.05,
    friction: 0.9,
  },
  node: {
    radius: 8,
    color: '#3b82f6',
    hoverColor: '#60a5fa',
    textColor: '#e5e7eb',
    fontSize: 12,
  },
  edge: {
    color: '#475569',
    width: 1,
    hoverWidth: 2,
  },
} as const;

/**
 * تنظیمات Markdown
 */
export const MARKDOWN_CONFIG = {
  rehypePlugins: {
    sanitize: true,
    highlight: true,
    katex: true,
    raw: true,
  },
  remarkPlugins: {
    gfm: true,
    math: true,
  },
  extensions: {
    callouts: true,
    internalLinks: true,
    mermaid: true,
    codeHighlight: true,
  },
} as const;

/**
 * تنظیمات Code Highlighting
 */
export const CODE_CONFIG = {
  theme: 'tomorrow',
  languages: [
    'typescript',
    'javascript',
    'jsx',
    'tsx',
    'python',
    'rust',
    'go',
    'bash',
    'json',
    'yaml',
    'markdown',
    'css',
    'html',
  ],
  features: {
    lineNumbers: true,
    copyButton: true,
    highlightLines: true,
  },
} as const;

/**
 * تنظیمات Social Media
 */
export const SOCIAL_LINKS = {
  twitter: 'https://twitter.com/memarzade',
  github: 'https://github.com/memarzade',
  linkedin: 'https://linkedin.com/in/memarzade',
  email: 'mailto:contact@memarzade.dev',
} as const;

/**
 * تنظیمات Routes
 */
export const ROUTES = {
  home: '/',
  post: '/posts/:slug',
  categories: '/categories',
  category: '/categories/:slug',
  search: '/search',
  tags: '/tags',
  graph: '/graph',
  bookmarks: '/bookmarks',
  history: '/history',
} as const;

/**
 * تنظیمات Breakpoints
 */
export const BREAKPOINTS = {
  xs: 320,
  sm: 640,
  md: 768,
  lg: 1024,
  xl: 1280,
  '2xl': 1536,
  '3xl': 1920,
} as const;

/**
 * تنظیمات Theme
 */
export const THEME_CONFIG = {
  default: 'dark' as const,
  modes: ['light', 'dark', 'system'] as const,
  transitionDuration: 200, // milliseconds
} as const;

/**
 * تنظیمات Fonts
 */
export const FONTS = {
  heading: {
    ltr: 'Space Grotesk',
    rtl: 'Vazirmatn',
  },
  body: {
    ltr: 'Inter',
    rtl: 'Vazirmatn',
  },
  mono: 'Roboto Mono',
} as const;

/**
 * تنظیمات Animation
 */
export const ANIMATION_CONFIG = {
  duration: {
    fast: 150,
    normal: 200,
    slow: 300,
  },
  easing: {
    easeIn: 'cubic-bezier(0.4, 0, 1, 1)',
    easeOut: 'cubic-bezier(0, 0, 0.2, 1)',
    easeInOut: 'cubic-bezier(0.4, 0, 0.2, 1)',
  },
} as const;

/**
 * تنظیمات RSS Feed
 */
export const RSS_CONFIG = {
  title: SITE_INFO.title,
  description: SITE_INFO.description,
  link: SITE_INFO.url,
  language: 'en',
  copyright: `Copyright ${new Date().getFullYear()} ${SITE_INFO.author}`,
  ttl: 60, // minutes
} as const;

/**
 * تنظیمات Sitemap
 */
export const SITEMAP_CONFIG = {
  changefreq: {
    home: 'daily',
    posts: 'monthly',
    categories: 'weekly',
    tags: 'weekly',
    static: 'monthly',
  } as const,
  priority: {
    home: 1.0,
    posts: 0.9,
    categories: 0.7,
    tags: 0.6,
    static: 0.5,
  } as const,
} as const;

/**
 * تنظیمات Meta Tags
 */
export const META_CONFIG = {
  ogImage: `${SITE_INFO.url}/og-image.png`,
  twitterCard: 'summary_large_image',
  twitterImage: `${SITE_INFO.url}/twitter-card.png`,
  twitterCreator: '@memarzade',
} as const;

/**
 * Feature Flags
 */
export const FEATURES = {
  serviceWorker: SERVICE_WORKER.enabled,
  analytics: ANALYTICS.enabled,
  performanceMonitoring: PERFORMANCE.enabled,
  knowledgeGraph: true,
  search: true,
  bookmarks: true,
  history: true,
  socialShare: true,
  comments: false, // Coming in v9.1.0
  newsletter: false, // Coming in v9.2.0
} as const;

/**
 * API Endpoints (for future use)
 */
export const API_ENDPOINTS = {
  posts: '/api/posts',
  search: '/api/search',
  analytics: '/api/analytics',
} as const;

/**
 * Error Messages
 */
export const ERROR_MESSAGES = {
  notFound: 'Post not found',
  loadError: 'Failed to load content',
  networkError: 'Network error occurred',
  parseError: 'Failed to parse markdown',
  generic: 'Something went wrong',
} as const;

/**
 * Success Messages
 */
export const SUCCESS_MESSAGES = {
  bookmarkAdded: 'Post bookmarked',
  bookmarkRemoved: 'Bookmark removed',
  linkCopied: 'Link copied to clipboard',
  postShared: 'Post shared successfully',
} as const;

/**
 * Loading Messages
 */
export const LOADING_MESSAGES = {
  posts: 'Loading posts...',
  search: 'Searching...',
  graph: 'Loading knowledge graph...',
  content: 'Loading content...',
} as const;

/**
 * Empty State Messages
 */
export const EMPTY_STATE_MESSAGES = {
  noPosts: 'No posts found',
  noBookmarks: 'No bookmarks yet',
  noHistory: 'No reading history',
  noResults: 'No results found',
  noTags: 'No tags available',
  noCategories: 'No categories available',
} as const;
