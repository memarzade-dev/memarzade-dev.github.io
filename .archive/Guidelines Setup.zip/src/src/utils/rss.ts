// RSS feed generator for the blog

export interface RSSItem {
  title: string;
  link: string;
  description: string;
  pubDate: string;
  author?: string;
  category?: string;
  guid?: string;
}

export interface RSSFeedConfig {
  title: string;
  description: string;
  link: string;
  language?: string;
  copyright?: string;
  managingEditor?: string;
  webMaster?: string;
  category?: string;
  imageUrl?: string;
}

export function generateRSSFeed(config: RSSFeedConfig, items: RSSItem[]): string {
  const {
    title,
    description,
    link,
    language = 'en',
    copyright = `Copyright ${new Date().getFullYear()}`,
    managingEditor,
    webMaster,
    category,
    imageUrl,
  } = config;

  const buildDate = new Date().toUTCString();

  const itemsXML = items
    .map(
      (item) => `
    <item>
      <title><![CDATA[${escapeXML(item.title)}]]></title>
      <link>${escapeXML(item.link)}</link>
      <description><![CDATA[${escapeXML(item.description)}]]></description>
      <pubDate>${item.pubDate}</pubDate>
      ${item.author ? `<author>${escapeXML(item.author)}</author>` : ''}
      ${item.category ? `<category>${escapeXML(item.category)}</category>` : ''}
      ${item.guid ? `<guid isPermaLink="true">${escapeXML(item.guid)}</guid>` : `<guid isPermaLink="true">${escapeXML(item.link)}</guid>`}
    </item>`
    )
    .join('');

  return `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>${escapeXML(title)}</title>
    <description>${escapeXML(description)}</description>
    <link>${escapeXML(link)}</link>
    <language>${language}</language>
    <copyright>${escapeXML(copyright)}</copyright>
    <lastBuildDate>${buildDate}</lastBuildDate>
    <pubDate>${buildDate}</pubDate>
    <ttl>60</ttl>
    ${managingEditor ? `<managingEditor>${escapeXML(managingEditor)}</managingEditor>` : ''}
    ${webMaster ? `<webMaster>${escapeXML(webMaster)}</webMaster>` : ''}
    ${category ? `<category>${escapeXML(category)}</category>` : ''}
    ${imageUrl ? `
    <image>
      <url>${escapeXML(imageUrl)}</url>
      <title>${escapeXML(title)}</title>
      <link>${escapeXML(link)}</link>
    </image>` : ''}
    <atom:link href="${escapeXML(link)}/rss.xml" rel="self" type="application/rss+xml" />
    ${itemsXML}
  </channel>
</rss>`;
}

function escapeXML(str: string): string {
  return str
    .replace(/&/g, '&')
    .replace(/</g, '<')
    .replace(/>/g, '>')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

// Generate RSS feed from blog posts
export function generateBlogRSS(
  posts: Array<{
    title: string;
    subtitle?: string;
    excerpt?: string;
    slug: string;
    date: string;
    author?: string;
    category?: string;
  }>,
  siteUrl: string = 'https://vaults.memarzade.dev'
): string {
  const items: RSSItem[] = posts.map((post) => ({
    title: post.title,
    link: `${siteUrl}/posts/${post.slug}`,
    description: post.excerpt || post.subtitle || post.title,
    pubDate: new Date(post.date).toUTCString(),
    author: post.author,
    category: post.category,
    guid: `${siteUrl}/posts/${post.slug}`,
  }));

  return generateRSSFeed(
    {
      title: 'Vaults - Developer Blog',
      description: "A Developer's Free Code License - Deep technical content and digital garden",
      link: siteUrl,
      language: 'en',
      copyright: `Copyright ${new Date().getFullYear()} Vaults`,
      category: 'Technology',
      imageUrl: `${siteUrl}/logo.png`,
    },
    items
  );
}

// Save RSS feed to file (for build process)
export function saveRSSFeed(content: string, outputPath: string = 'public/rss.xml'): void {
  if (typeof window !== 'undefined') {
    console.warn('RSS feed generation should be done during build, not in browser');
    return;
  }

  // This would be used in a build script
  // For Vite, you'd create a plugin or use a build hook
  console.log(`RSS feed should be saved to: ${outputPath}`);
  console.log('Content length:', content.length);
}
