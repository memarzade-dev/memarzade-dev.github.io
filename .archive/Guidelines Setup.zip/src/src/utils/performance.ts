// Performance Monitoring Utilities
// ابزارهای نظارت بر عملکرد برای اندازه‌گیری Web Vitals و metrics

export interface PerformanceMetrics {
  timeToFirstByte: number;
  domContentLoaded: number;
  windowLoad: number;
  firstContentfulPaint?: number;
  largestContentfulPaint?: number;
  firstInputDelay?: number;
  cumulativeLayoutShift?: number;
}

export function measurePageLoad(): PerformanceMetrics | null {
  if (!window.performance || !window.performance.timing) {
    return null;
  }

  const timing = window.performance.timing;
  const navigation = timing.navigationStart;

  const metrics: PerformanceMetrics = {
    timeToFirstByte: timing.responseStart - navigation,
    domContentLoaded: timing.domContentLoadedEventEnd - navigation,
    windowLoad: timing.loadEventEnd - navigation,
  };

  return metrics;
}

export function measureWebVitals(
  callback: (metric: { name: string; value: number; rating: string }) => void
): void {
  // First Contentful Paint (FCP)
  if ('PerformanceObserver' in window) {
    try {
      const fcpObserver = new PerformanceObserver((entryList) => {
        for (const entry of entryList.getEntries()) {
          if (entry.name === 'first-contentful-paint') {
            const value = entry.startTime;
            callback({
              name: 'FCP',
              value,
              rating: value < 1800 ? 'good' : value < 3000 ? 'needs-improvement' : 'poor',
            });
            fcpObserver.disconnect();
          }
        }
      });
      fcpObserver.observe({ entryTypes: ['paint'] });
    } catch (e) {
      console.warn('FCP observation failed:', e);
    }

    // Largest Contentful Paint (LCP)
    try {
      const lcpObserver = new PerformanceObserver((entryList) => {
        const entries = entryList.getEntries();
        const lastEntry = entries[entries.length - 1];
        const value = lastEntry.startTime;
        callback({
          name: 'LCP',
          value,
          rating: value < 2500 ? 'good' : value < 4000 ? 'needs-improvement' : 'poor',
        });
      });
      lcpObserver.observe({ entryTypes: ['largest-contentful-paint'] });
    } catch (e) {
      console.warn('LCP observation failed:', e);
    }

    // First Input Delay (FID)
    try {
      const fidObserver = new PerformanceObserver((entryList) => {
        for (const entry of entryList.getEntries()) {
          const fidEntry = entry as PerformanceEventTiming;
          const value = fidEntry.processingStart - fidEntry.startTime;
          callback({
            name: 'FID',
            value,
            rating: value < 100 ? 'good' : value < 300 ? 'needs-improvement' : 'poor',
          });
          fidObserver.disconnect();
        }
      });
      fidObserver.observe({ entryTypes: ['first-input'] });
    } catch (e) {
      console.warn('FID observation failed:', e);
    }

    // Cumulative Layout Shift (CLS)
    try {
      let clsValue = 0;
      const clsObserver = new PerformanceObserver((entryList) => {
        for (const entry of entryList.getEntries()) {
          const layoutShiftEntry = entry as any;
          if (!layoutShiftEntry.hadRecentInput) {
            clsValue += layoutShiftEntry.value;
          }
        }
      });
      clsObserver.observe({ entryTypes: ['layout-shift'] });

      // Report CLS after 5 seconds
      setTimeout(() => {
        callback({
          name: 'CLS',
          value: clsValue,
          rating: clsValue < 0.1 ? 'good' : clsValue < 0.25 ? 'needs-improvement' : 'poor',
        });
        clsObserver.disconnect();
      }, 5000);
    } catch (e) {
      console.warn('CLS observation failed:', e);
    }
  }
}

export function logPerformanceMetrics(): void {
  const isDevelopment = typeof import.meta !== 'undefined' && 
                        import.meta.env && 
                        import.meta.env.DEV === true;
  
  if (isDevelopment) {
    // Log basic metrics
    const pageLoad = measurePageLoad();
    if (pageLoad) {
      console.group('📊 Performance Metrics');
      console.log('⏱️ Time to First Byte:', pageLoad.timeToFirstByte, 'ms');
      console.log('📄 DOM Content Loaded:', pageLoad.domContentLoaded, 'ms');
      console.log('🎉 Window Load:', pageLoad.windowLoad, 'ms');
      console.groupEnd();
    }

    // Log Web Vitals
    measureWebVitals((metric) => {
      const icon = metric.rating === 'good' ? '✅' : metric.rating === 'needs-improvement' ? '⚠️' : '❌';
      console.log(`${icon} ${metric.name}:`, metric.value.toFixed(2), 'ms', `(${metric.rating})`);
    });
  }
}

export function reportToAnalytics(metric: { name: string; value: number; rating: string }): void {
  // Send to analytics service
  // Example: Google Analytics, Vercel Analytics, etc.
  if (window.gtag) {
    window.gtag('event', metric.name, {
      event_category: 'Web Vitals',
      value: Math.round(metric.value),
      event_label: metric.rating,
      non_interaction: true,
    });
  }
}

// Type for Google Analytics gtag function
declare global {
  interface Window {
    gtag?: (
      command: string,
      eventName: string,
      params: Record<string, any>
    ) => void;
  }
}

/**
 * Initialize performance monitoring
 * راه‌اندازی نظارت بر عملکرد
 */
export function initPerformanceMonitoring(): void {
  // Log performance metrics in development
  logPerformanceMetrics();
  
  // Track Web Vitals and send to analytics
  measureWebVitals((metric) => {
    const isDevelopment = typeof import.meta !== 'undefined' && 
                          import.meta.env && 
                          import.meta.env.DEV === true;
    
    if (isDevelopment) {
      const icon = metric.rating === 'good' ? '✅' : metric.rating === 'needs-improvement' ? '⚠️' : '❌';
      console.log(`${icon} ${metric.name}:`, metric.value.toFixed(2), 'ms', `(${metric.rating})`);
    }
    
    // Report to analytics in production
    reportToAnalytics(metric);
  });
}

/**
 * Track web vitals
 * ردیابی Web Vitals
 */
export function trackWebVitals(
  callback: (metric: { name: string; value: number; rating: string }) => void
): void {
  measureWebVitals(callback);
}