// Sitemap generator for SEO

export interface SitemapURL {
  loc: string;
  lastmod?: string;
  changefreq?: 'always' | 'hourly' | 'daily' | 'weekly' | 'monthly' | 'yearly' | 'never';
  priority?: number;
}

export function generateSitemap(urls: SitemapURL[]): string {
  const urlsXML = urls
    .map(
      (url) => `
  <url>
    <loc>${escapeXML(url.loc)}</loc>
    ${url.lastmod ? `<lastmod>${url.lastmod}</lastmod>` : ''}
    ${url.changefreq ? `<changefreq>${url.changefreq}</changefreq>` : ''}
    ${url.priority !== undefined ? `<priority>${url.priority.toFixed(1)}</priority>` : ''}
  </url>`
    )
    .join('');

  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  ${urlsXML}
</urlset>`;
}

function escapeXML(str: string): string {
  return str
    .replace(/&/g, '&')
    .replace(/</g, '<')
    .replace(/>/g, '>')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

// Generate sitemap from blog posts and static pages
export function generateBlogSitemap(
  posts: Array<{
    slug: string;
    date: string;
  }>,
  categories: string[] = [],
  tags: string[] = [],
  siteUrl: string = 'https://vaults.memarzade.dev'
): string {
  const urls: SitemapURL[] = [];

  // Homepage
  urls.push({
    loc: siteUrl,
    changefreq: 'daily',
    priority: 1.0,
  });

  // Static pages
  urls.push(
    {
      loc: `${siteUrl}/categories`,
      changefreq: 'weekly',
      priority: 0.8,
    },
    {
      loc: `${siteUrl}/tags`,
      changefreq: 'weekly',
      priority: 0.8,
    },
    {
      loc: `${siteUrl}/search`,
      changefreq: 'monthly',
      priority: 0.6,
    },
    {
      loc: `${siteUrl}/graph`,
      changefreq: 'weekly',
      priority: 0.7,
    },
    {
      loc: `${siteUrl}/bookmarks`,
      changefreq: 'monthly',
      priority: 0.5,
    },
    {
      loc: `${siteUrl}/history`,
      changefreq: 'monthly',
      priority: 0.5,
    }
  );

  // Blog posts
  posts.forEach((post) => {
    urls.push({
      loc: `${siteUrl}/posts/${post.slug}`,
      lastmod: new Date(post.date).toISOString().split('T')[0],
      changefreq: 'monthly',
      priority: 0.9,
    });
  });

  // Category pages
  categories.forEach((category) => {
    const slug = category.toLowerCase().replace(/\s+/g, '-');
    urls.push({
      loc: `${siteUrl}/categories/${slug}`,
      changefreq: 'weekly',
      priority: 0.7,
    });
  });

  // Tag pages (optional - might be too many)
  // Uncomment if you want tag pages in sitemap
  /*
  tags.forEach((tag) => {
    const slug = tag.toLowerCase().replace(/\s+/g, '-');
    urls.push({
      loc: `${siteUrl}/tags?tag=${encodeURIComponent(slug)}`,
      changefreq: 'weekly',
      priority: 0.6,
    });
  });
  */

  return generateSitemap(urls);
}

// Save sitemap to file (for build process)
export function saveSitemap(content: string, outputPath: string = 'public/sitemap.xml'): void {
  if (typeof window !== 'undefined') {
    console.warn('Sitemap generation should be done during build, not in browser');
    return;
  }

  // This would be used in a build script
  // For Vite, you'd create a plugin or use a build hook
  console.log(`Sitemap should be saved to: ${outputPath}`);
  console.log('URLs count:', (content.match(/<url>/g) || []).length);
}
