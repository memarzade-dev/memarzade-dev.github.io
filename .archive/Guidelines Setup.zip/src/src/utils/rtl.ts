export function detectTextDirection(text: string): 'rtl' | 'ltr' | 'auto' {
  if (!text) return 'auto';

  const rtlPattern = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/;
  const ltrPattern = /[A-Za-z]/;

  const hasRTL = rtlPattern.test(text);
  const hasLTR = ltrPattern.test(text);

  if (hasRTL && !hasLTR) return 'rtl';
  if (hasLTR && !hasRTL) return 'ltr';
  return 'auto';
}

export function getFontFamily(direction: 'rtl' | 'ltr' | 'auto'): string {
  if (direction === 'rtl') {
    return 'var(--font-rtl)';
  }
  return 'var(--font-body)';
}

export function getHeadingFontFamily(direction: 'rtl' | 'ltr' | 'auto'): string {
  if (direction === 'rtl') {
    return 'var(--font-rtl)';
  }
  return 'var(--font-heading)';
}

export function extractPlainText(node: React.ReactNode): string {
  if (typeof node === 'string') return node;
  if (typeof node === 'number') return String(node);
  if (Array.isArray(node)) return node.map(extractPlainText).join('');
  if (node && typeof node === 'object' && 'props' in node) {
    return extractPlainText(node.props.children);
  }
  return '';
}
