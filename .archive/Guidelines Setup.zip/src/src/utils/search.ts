import Fuse from 'fuse.js';
import { Post } from '../types/post';

export interface SearchOptions {
  threshold?: number;
  keys?: string[];
}

export function createSearchIndex(posts: Post[], options?: SearchOptions) {
  const defaultOptions: Fuse.IFuseOptions<Post> = {
    threshold: options?.threshold || 0.3,
    keys: options?.keys || [
      { name: 'title', weight: 2 },
      { name: 'subtitle', weight: 1.5 },
      { name: 'excerpt', weight: 1.2 },
      { name: 'tags', weight: 1.5 },
      { name: 'category', weight: 1 },
      { name: 'content', weight: 0.5 },
    ],
    includeScore: true,
    includeMatches: true,
    minMatchCharLength: 2,
    ignoreLocation: true,
  };

  return new Fuse(posts, defaultOptions);
}

export function searchPosts(query: string, posts: Post[], options?: SearchOptions): Post[] {
  if (!query.trim()) {
    return posts;
  }

  const fuse = createSearchIndex(posts, options);
  const results = fuse.search(query);

  return results.map(result => result.item);
}

export function highlightMatches(text: string, matches: readonly Fuse.RangeTuple[]): string {
  if (!matches || matches.length === 0) {
    return text;
  }

  let result = '';
  let lastIndex = 0;

  matches.forEach(([start, end]) => {
    result += text.slice(lastIndex, start);
    result += `<mark>${text.slice(start, end + 1)}</mark>`;
    lastIndex = end + 1;
  });

  result += text.slice(lastIndex);
  return result;
}
