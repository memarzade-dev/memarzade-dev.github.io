import React, { useState } from 'react';
import { Header } from '../components/Header';
import { Sidebar, NestedCategory } from '../components/Sidebar';
import { Footer } from '../components/Footer';
import { mockCategories } from '../data/mockPosts';

export interface LayoutShellProps {
  children: React.ReactNode;
  showSidebar?: boolean;
  sidebarCollapsed?: boolean;
  className?: string;
}

// Convert our Category type to NestedCategory type for Sidebar
const convertCategories = (): NestedCategory[] => {
  return mockCategories.map(cat => ({
    name: cat.name,
    slug: cat.slug,
    postCount: cat.count,
    children: cat.children?.map(child => ({
      name: child.name,
      slug: child.slug,
      postCount: child.count,
    })),
  }));
};

export function LayoutShell({
  children,
  showSidebar = true,
  sidebarCollapsed: initialCollapsed = false,
  className = '',
}: LayoutShellProps) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(initialCollapsed);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const categories = convertCategories();

  return (
    <div className={`min-h-screen flex flex-col ${className}`}>
      {/* Skip to content link for accessibility */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:px-4 focus:py-2 focus:bg-vault-accent-primary focus:text-vault-text-inverse focus:rounded-md"
      >
        Skip to content
      </a>

      <Header 
        onMenuToggle={() => setMobileMenuOpen(!mobileMenuOpen)}
      />

      <div className="flex flex-1">
        {/* Sidebar - Desktop */}
        {showSidebar && (
          <>
            <div className="hidden md:block">
              <Sidebar
                categories={categories}
                isCollapsed={sidebarCollapsed}
                onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
              />
            </div>

            {/* Sidebar - Mobile Overlay */}
            {mobileMenuOpen && (
              <>
                <div
                  className="fixed inset-0 bg-black/50 z-40 md:hidden"
                  onClick={() => setMobileMenuOpen(false)}
                  aria-hidden="true"
                />
                <div className="fixed inset-y-0 left-0 z-50 md:hidden transform transition-transform duration-300">
                  <Sidebar
                    categories={categories}
                    isCollapsed={false}
                    className="h-full shadow-2xl"
                  />
                </div>
              </>
            )}
          </>
        )}

        {/* Main Content */}
        <main
          id="main-content"
          className="flex-1 overflow-x-hidden"
          role="main"
        >
          {children}
        </main>
      </div>

      <Footer />
    </div>
  );
}