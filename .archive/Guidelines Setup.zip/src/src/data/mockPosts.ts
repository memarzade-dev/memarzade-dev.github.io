import { Post, Category } from '../types/post';

export const mockCategories: Category[] = [
  {
    name: 'Machine Learning',
    slug: 'machine-learning',
    count: 12,
    children: [
      { name: 'Neural Networks', slug: 'neural-networks', count: 5 },
      { name: 'Deep Learning', slug: 'deep-learning', count: 4 },
      { name: 'NLP', slug: 'nlp', count: 3 },
    ],
  },
  {
    name: 'System Design',
    slug: 'system-design',
    count: 8,
    children: [
      { name: 'Distributed Systems', slug: 'distributed-systems', count: 4 },
      { name: 'Microservices', slug: 'microservices', count: 4 },
    ],
  },
  {
    name: 'Web Development',
    slug: 'web-development',
    count: 15,
    children: [
      { name: 'React', slug: 'react', count: 6 },
      { name: 'TypeScript', slug: 'typescript', count: 5 },
      { name: 'Performance', slug: 'performance', count: 4 },
    ],
  },
  {
    name: 'DevOps',
    slug: 'devops',
    count: 6,
  },
];

export const mockPosts: Post[] = [
  {
    title: 'Understanding Transformer Architecture',
    subtitle: 'A deep dive into attention mechanisms',
    slug: 'understanding-transformer-architecture',
    url: '/posts/understanding-transformer-architecture',
    excerpt: 'Transformers have revolutionized natural language processing. In this article, we explore the core mechanisms behind this groundbreaking architecture, including self-attention, multi-head attention, and positional encoding.',
    coverImage: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&h=450&fit=crop',
    coverAlt: 'Abstract visualization of neural network',
    date: '2024-12-01',
    readingTimeMinutes: 12,
    tags: ['transformers', 'nlp', 'deep-learning', 'attention'],
    category: 'Machine Learning',
    categorySlug: 'machine-learning',
    lang: 'en-US',
    featured: true,
  },
  {
    title: 'Building Scalable Microservices with Event Sourcing',
    subtitle: 'Event-driven architecture patterns',
    slug: 'microservices-event-sourcing',
    url: '/posts/microservices-event-sourcing',
    excerpt: 'Event sourcing provides a robust foundation for building distributed systems. Learn how to implement event-driven microservices with CQRS patterns, handle eventual consistency, and design resilient architectures.',
    coverImage: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&h=450&fit=crop',
    coverAlt: 'Distributed system network visualization',
    date: '2024-11-28',
    readingTimeMinutes: 15,
    tags: ['microservices', 'event-sourcing', 'cqrs', 'distributed-systems'],
    category: 'System Design',
    categorySlug: 'system-design',
    lang: 'en-US',
    featured: true,
  },
  {
    title: 'React Server Components: The Future of React',
    subtitle: 'Zero-bundle-size components',
    slug: 'react-server-components',
    url: '/posts/react-server-components',
    excerpt: 'React Server Components represent a paradigm shift in how we think about component rendering. Explore how RSC enables zero-bundle-size components, automatic code splitting, and improved performance.',
    coverImage: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=800&h=450&fit=crop',
    coverAlt: 'React code on screen',
    date: '2024-11-25',
    readingTimeMinutes: 10,
    tags: ['react', 'server-components', 'performance', 'web-dev'],
    category: 'Web Development',
    categorySlug: 'web-development',
    lang: 'en-US',
  },
  {
    title: 'Consensus Algorithms in Distributed Systems',
    subtitle: 'Raft vs Paxos explained',
    slug: 'consensus-algorithms-distributed-systems',
    url: '/posts/consensus-algorithms-distributed-systems',
    excerpt: 'Achieving consensus in distributed systems is fundamental to building reliable services. Compare Raft and Paxos algorithms, understand their trade-offs, and learn when to use each approach.',
    coverImage: 'https://images.unsplash.com/photo-1639322537228-f710d846310a?w=800&h=450&fit=crop',
    coverAlt: 'Network nodes and connections',
    date: '2024-11-20',
    readingTimeMinutes: 18,
    tags: ['distributed-systems', 'consensus', 'raft', 'paxos'],
    category: 'System Design',
    categorySlug: 'system-design',
    lang: 'en-US',
  },
  {
    title: 'TypeScript Advanced Types: A Practical Guide',
    subtitle: 'Utility types and type narrowing',
    slug: 'typescript-advanced-types',
    url: '/posts/typescript-advanced-types',
    excerpt: 'Master TypeScript\'s advanced type system including conditional types, mapped types, template literal types, and advanced type narrowing techniques for building type-safe applications.',
    coverImage: 'https://images.unsplash.com/photo-1516116216624-53e697fedbea?w=800&h=450&fit=crop',
    coverAlt: 'TypeScript code editor',
    date: '2024-11-15',
    readingTimeMinutes: 14,
    tags: ['typescript', 'type-system', 'web-dev', 'programming'],
    category: 'Web Development',
    categorySlug: 'web-development',
    lang: 'en-US',
    featured: true,
  },
  {
    title: 'Optimizing Neural Network Training',
    subtitle: 'Techniques for faster convergence',
    slug: 'optimizing-neural-network-training',
    url: '/posts/optimizing-neural-network-training',
    excerpt: 'Learn advanced optimization techniques for training deep neural networks including learning rate scheduling, gradient clipping, batch normalization, and mixed precision training.',
    coverImage: 'https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=800&h=450&fit=crop',
    coverAlt: 'Neural network training visualization',
    date: '2024-11-10',
    readingTimeMinutes: 16,
    tags: ['deep-learning', 'optimization', 'training', 'neural-networks'],
    category: 'Machine Learning',
    categorySlug: 'machine-learning',
    lang: 'en-US',
  },
  {
    title: 'Container Orchestration with Kubernetes',
    subtitle: 'From pods to production',
    slug: 'kubernetes-orchestration',
    url: '/posts/kubernetes-orchestration',
    excerpt: 'A comprehensive guide to Kubernetes orchestration covering pods, services, deployments, StatefulSets, and production-ready patterns for running containerized applications at scale.',
    coverImage: 'https://images.unsplash.com/photo-1667372393119-3d4c48d07fc9?w=800&h=450&fit=crop',
    coverAlt: 'Kubernetes cluster visualization',
    date: '2024-11-05',
    readingTimeMinutes: 20,
    tags: ['kubernetes', 'devops', 'containers', 'orchestration'],
    category: 'DevOps',
    categorySlug: 'devops',
    lang: 'en-US',
  },
  {
    title: 'Fine-Tuning Large Language Models',
    subtitle: 'PEFT and LoRA explained',
    slug: 'fine-tuning-llms',
    url: '/posts/fine-tuning-llms',
    excerpt: 'Explore parameter-efficient fine-tuning techniques for large language models including LoRA, QLoRA, and adapter methods. Learn how to customize LLMs for your specific use case.',
    coverImage: 'https://images.unsplash.com/photo-1676277791608-ac52b45c6e43?w=800&h=450&fit=crop',
    coverAlt: 'AI language model concept',
    date: '2024-10-30',
    readingTimeMinutes: 22,
    tags: ['llm', 'fine-tuning', 'nlp', 'machine-learning'],
    category: 'Machine Learning',
    categorySlug: 'machine-learning',
    lang: 'en-US',
  },
];

export const getFeaturedPosts = (): Post[] => {
  return mockPosts.filter(post => post.featured);
};

export const getRecentPosts = (limit: number = 6): Post[] => {
  return mockPosts
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, limit);
};

export const getPostsByCategory = (categorySlug: string): Post[] => {
  return mockPosts.filter(post => post.categorySlug === categorySlug);
};

export const getPostBySlug = (slug: string): Post | undefined => {
  return mockPosts.find(post => post.slug === slug);
};

export const getAllCategories = (): Category[] => {
  return mockCategories;
};