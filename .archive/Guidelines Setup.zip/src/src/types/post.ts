export interface Post {
  title: string;
  subtitle?: string;
  slug: string;
  url: string;
  excerpt?: string;
  coverImage?: string;
  coverAlt?: string;
  date: string;
  readingTimeMinutes?: number;
  tags: string[];
  category: string;
  categorySlug: string;
  lang: string;
  featured?: boolean;
  content?: string;
  relatedPosts?: string[]; // Array of slugs
}

export interface Category {
  name: string;
  slug: string;
  count: number;
  children?: Category[];
}
