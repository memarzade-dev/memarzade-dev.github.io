import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class", '[data-theme="dark"]'],
  content: [
    "./pages/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./app/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}",
    "/*.tsx",
  ],
  theme: {
    extend: {
      colors: {
        // Background colors
        'vault-bg-base': "var(--color-bg-base)",
        'vault-bg-surface': "var(--color-bg-surface)",
        'vault-bg-elevated': "var(--color-bg-elevated)",
        'vault-bg-hover': "var(--color-bg-hover)",
        
        // Text colors
        'vault-text-primary': "var(--color-text-primary)",
        'vault-text-secondary': "var(--color-text-secondary)",
        'vault-text-muted': "var(--color-text-muted)",
        'vault-text-inverse': "var(--color-text-inverse)",
        
        // Accent colors
        'vault-accent-primary': "var(--color-accent-primary)",
        'vault-accent-primary-hover': "var(--color-accent-primary-hover)",
        'vault-accent-primary-dim': "var(--color-accent-primary-dim)",
        'vault-accent-secondary': "var(--color-accent-secondary)",
        'vault-accent-secondary-hover': "var(--color-accent-secondary-hover)",
        'vault-accent-secondary-dim': "var(--color-accent-secondary-dim)",
        
        // Border colors
        'vault-border-subtle': "var(--color-border-subtle)",
        'vault-border-default': "var(--color-border-default)",
        'vault-border-emphasis': "var(--color-border-emphasis)",
        
        // Code colors
        'vault-code-bg': "var(--color-code-bg)",
        'vault-code-text': "var(--color-code-text)",
        'vault-code-comment': "var(--color-code-comment)",
        'vault-code-keyword': "var(--color-code-keyword)",
        'vault-code-string': "var(--color-code-string)",
        'vault-code-function': "var(--color-code-function)",
        'vault-code-number': "var(--color-code-number)",
        
        // Semantic colors
        'vault-info': "var(--color-info)",
        'vault-info-bg': "var(--color-info-bg)",
        'vault-info-border': "var(--color-info-border)",
        'vault-success': "var(--color-success)",
        'vault-success-bg': "var(--color-success-bg)",
        'vault-success-border': "var(--color-success-border)",
        'vault-warning': "var(--color-warning)",
        'vault-warning-bg': "var(--color-warning-bg)",
        'vault-warning-border': "var(--color-warning-border)",
        'vault-danger': "var(--color-danger)",
        'vault-danger-bg': "var(--color-danger-bg)",
        'vault-danger-border': "var(--color-danger-border)",
      },
      fontFamily: {
        rtl: ["var(--font-rtl)"],
        heading: ["var(--font-heading)"],
        body: ["var(--font-body)"],
        code: ["var(--font-code)"],
      },
      fontSize: {
        display: ["var(--font-size-display)", { lineHeight: "var(--line-height-display)" }],
        h1: ["var(--font-size-h1)", { lineHeight: "var(--line-height-heading)" }],
        h2: ["var(--font-size-h2)", { lineHeight: "var(--line-height-heading)" }],
        h3: ["var(--font-size-h3)", { lineHeight: "var(--line-height-heading)" }],
        h4: ["var(--font-size-h4)", { lineHeight: "var(--line-height-heading)" }],
        h5: ["var(--font-size-h5)", { lineHeight: "var(--line-height-heading)" }],
        h6: ["var(--font-size-h6)", { lineHeight: "var(--line-height-heading)" }],
        body: ["var(--font-size-body)", { lineHeight: "var(--line-height-body)" }],
        small: ["var(--font-size-small)", { lineHeight: "var(--line-height-small)" }],
        caption: ["var(--font-size-caption)", { lineHeight: "var(--line-height-caption)" }],
        "code-inline": "var(--font-size-code-inline)",
        "code-block": ["var(--font-size-code-block)", { lineHeight: "var(--line-height-code)" }],
      },
      spacing: {
        xs: "var(--spacing-xs)",
        sm: "var(--spacing-sm)",
        md: "var(--spacing-md)",
        lg: "var(--spacing-lg)",
        xl: "var(--spacing-xl)",
        "2xl": "var(--spacing-2xl)",
        "3xl": "var(--spacing-3xl)",
        "4xl": "var(--spacing-4xl)",
        "5xl": "var(--spacing-5xl)",
        "section-sm": "var(--spacing-section-sm)",
        "section-md": "var(--spacing-section-md)",
        "section-lg": "var(--spacing-section-lg)",
      },
      maxWidth: {
        "content-narrow": "var(--width-content-narrow)",
        content: "var(--width-content)",
        "content-wide": "var(--width-content-wide)",
        container: "var(--width-container)",
        "container-full": "var(--width-container-full)",
      },
      gap: {
        xs: "var(--spacing-xs)",
        sm: "var(--spacing-sm)",
        md: "var(--spacing-md)",
        lg: "var(--spacing-lg)",
        xl: "var(--spacing-xl)",
      },
      borderRadius: {
        sm: "var(--radius-sm)",
        md: "var(--radius-md)",
        lg: "var(--radius-lg)",
        xl: "var(--radius-xl)",
        "2xl": "var(--radius-2xl)",
        full: "var(--radius-full)",
      },
      boxShadow: {
        sm: "var(--shadow-sm)",
        md: "var(--shadow-md)",
        lg: "var(--shadow-lg)",
        xl: "var(--shadow-xl)",
        "2xl": "var(--shadow-2xl)",
        "glow-primary": "var(--shadow-glow-primary)",
        "glow-secondary": "var(--shadow-glow-secondary)",
        inset: "var(--shadow-inset)",
        hover: "var(--shadow-hover)",
        "card-hover": "var(--shadow-card-hover)",
      },
      backgroundImage: {
        "gradient-primary": "var(--gradient-primary)",
        "gradient-hero": "var(--gradient-hero)",
      },
    },
  },
  plugins: [],
};

export default config;