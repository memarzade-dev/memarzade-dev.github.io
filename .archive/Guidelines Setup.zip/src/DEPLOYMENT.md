# 🚀 Deployment Guide

<div dir="rtl">

راهنمای کامل استقرار Vaults Blog

</div>

## Prerequisites

```bash
Node.js >= 18.0.0
npm >= 9.0.0
Git
```

## Build Process

### 1. Development Build

```bash
# Start development server
npm run dev

# Server runs on http://localhost:3000
# Hot Module Replacement (HMR) enabled
```

### 2. Production Build

```bash
# Type check
npm run type-check

# Build for production
npm run build

# Output: dist/ directory
```

### 3. Preview Production Build

```bash
npm run preview

# Server runs on http://localhost:4173
```

## Deployment Options

### Option 1: GitHub Pages (Recommended)

#### 1.1. Repository Setup

```bash
# Initialize git repository
git init
git add .
git commit -m "Initial commit"

# Add remote repository
git remote add origin https://github.com/yourusername/vaults-blog.git
git branch -M main
git push -u origin main
```

#### 1.2. GitHub Actions Workflow

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [ main ]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: "pages"
  cancel-in-progress: false

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4
        
      - name: Setup Node
        uses: actions/setup-node@v4
        with:
          node-version: '18'
          cache: 'npm'
          
      - name: Install dependencies
        run: npm ci
        
      - name: Build
        run: npm run build
        
      - name: Generate RSS and Sitemap
        run: npm run generate-feeds
        
      - name: Upload artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: ./dist

  deploy:
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    needs: build
    steps:
      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
```

#### 1.3. GitHub Pages Configuration

1. Go to repository Settings
2. Navigate to Pages section
3. Select "GitHub Actions" as source
4. Push to main branch to trigger deployment

### Option 2: Vercel

#### 2.1. Install Vercel CLI

```bash
npm install -g vercel
```

#### 2.2. Deploy

```bash
# Login to Vercel
vercel login

# Deploy
vercel

# Deploy to production
vercel --prod
```

#### 2.3. vercel.json Configuration

```json
{
  "version": 2,
  "builds": [
    {
      "src": "package.json",
      "use": "@vercel/static-build",
      "config": {
        "distDir": "dist"
      }
    }
  ],
  "routes": [
    {
      "handle": "filesystem"
    },
    {
      "src": "/.*",
      "dest": "/index.html"
    }
  ]
}
```

### Option 3: Netlify

#### 3.1. netlify.toml Configuration

```toml
[build]
  command = "npm run build && npm run generate-feeds"
  publish = "dist"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200

[build.environment]
  NODE_VERSION = "18"
```

#### 3.2. Deploy

```bash
# Install Netlify CLI
npm install -g netlify-cli

# Login
netlify login

# Deploy
netlify deploy

# Deploy to production
netlify deploy --prod
```

### Option 4: Custom Server (VPS)

#### 4.1. Build and Transfer

```bash
# Build locally
npm run build
npm run generate-feeds

# Transfer to server
scp -r dist/* user@server:/var/www/vaults
```

#### 4.2. Nginx Configuration

```nginx
server {
    listen 80;
    server_name vaults.memarzade.dev;
    
    root /var/www/vaults;
    index index.html;
    
    # Gzip compression
    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;
    
    # Cache static assets
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
    
    # SPA routing
    location / {
        try_files $uri $uri/ /index.html;
    }
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    
    # SSL (with Let's Encrypt)
    listen 443 ssl http2;
    ssl_certificate /etc/letsencrypt/live/vaults.memarzade.dev/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/vaults.memarzade.dev/privkey.pem;
}

# Redirect HTTP to HTTPS
server {
    listen 80;
    server_name vaults.memarzade.dev;
    return 301 https://$server_name$request_uri;
}
```

## Environment Variables

### Development (.env.development)

```bash
VITE_SITE_URL=http://localhost:3000
VITE_GA_TRACKING_ID=
VITE_ENABLE_ANALYTICS=false
VITE_ENABLE_SERVICE_WORKER=false
```

### Production (.env.production)

```bash
VITE_SITE_URL=https://vaults.memarzade.dev
VITE_GA_TRACKING_ID=G-XXXXXXXXXX
VITE_ENABLE_ANALYTICS=true
VITE_ENABLE_SERVICE_WORKER=true
```

## Post-Deployment Checklist

### ✅ Functionality

- [ ] All routes work correctly
- [ ] Search functionality works
- [ ] Knowledge graph renders
- [ ] Markdown rendering is correct
- [ ] Code syntax highlighting works
- [ ] Math equations render
- [ ] Mermaid diagrams display
- [ ] Images load properly
- [ ] Service Worker registers (production only)

### ✅ Performance

- [ ] Lighthouse score > 90
- [ ] First Contentful Paint < 2s
- [ ] Time to Interactive < 4s
- [ ] Images are optimized
- [ ] Bundle size is acceptable
- [ ] No console errors

### ✅ SEO

- [ ] robots.txt is accessible
- [ ] sitemap.xml is accessible
- [ ] RSS feed is accessible
- [ ] Meta tags are correct
- [ ] Open Graph tags work
- [ ] Twitter Cards work
- [ ] JSON-LD structured data is valid

### ✅ Analytics

- [ ] Google Analytics is tracking
- [ ] Page views are logged
- [ ] Events are tracked
- [ ] Web Vitals are reported

### ✅ Accessibility

- [ ] Screen reader compatible
- [ ] Keyboard navigation works
- [ ] Focus indicators visible
- [ ] Color contrast meets WCAG AA
- [ ] Alt text on images

## Monitoring

### Google Analytics

1. Create GA4 property
2. Get Measurement ID (G-XXXXXXXXXX)
3. Add to `.env.production`
4. Deploy

### Google Search Console

1. Verify site ownership
2. Submit sitemap.xml
3. Monitor indexing status
4. Check for errors

### Performance Monitoring

```bash
# Lighthouse CI
npm install -g @lhci/cli

# Run audit
lhci autorun --upload.target=temporary-public-storage
```

## Troubleshooting

### Issue: Routes not working (404)

**Solution**: Configure server for SPA routing

```nginx
# Nginx
location / {
    try_files $uri $uri/ /index.html;
}
```

### Issue: Images not loading

**Solution**: Check base URL in vite.config.ts

```typescript
export default defineConfig({
  base: '/', // or '/vaults-blog/' for GitHub Pages
});
```

### Issue: Service Worker not updating

**Solution**: Clear browser cache and Service Worker

```javascript
// In browser console
navigator.serviceWorker.getRegistrations().then(registrations => {
  registrations.forEach(registration => registration.unregister());
});
```

### Issue: Build fails

**Solution**: Clear cache and reinstall

```bash
rm -rf node_modules dist
npm install
npm run build
```

## Continuous Deployment

### GitHub Actions (Recommended)

- Automatically deploys on push to main
- Runs type checking and tests
- Generates RSS and Sitemap
- Optimizes assets

### Vercel/Netlify

- Connect GitHub repository
- Auto-deploys on push
- Preview deployments for PRs
- Environment variables in dashboard

## Performance Optimization

### 1. Image Optimization

```bash
# Use next-gen formats
convert image.jpg -quality 85 image.webp

# Optimize PNGs
pngquant image.png --output optimized.png
```

### 2. Bundle Analysis

```bash
npm install -D rollup-plugin-visualizer

# Add to vite.config.ts
import { visualizer } from 'rollup-plugin-visualizer';

plugins: [
  visualizer({
    open: true,
    gzipSize: true,
  }),
]
```

### 3. CDN Integration

```typescript
// vite.config.ts
export default defineConfig({
  build: {
    rollupOptions: {
      output: {
        assetFileNames: 'assets/[name].[hash][extname]',
      },
    },
  },
});
```

## Backup Strategy

### Database (if applicable)

```bash
# Backup localStorage data
localStorage.getItem('vaults-bookmarks')
localStorage.getItem('vaults-history')
```

### Content

```bash
# Backup markdown files
tar -czf posts-backup-$(date +%Y%m%d).tar.gz posts/
```

### Configuration

```bash
# Backup configuration files
git add .
git commit -m "Backup configuration"
git push
```

## Rollback Strategy

### GitHub Actions

1. Go to Actions tab
2. Find previous successful deployment
3. Re-run workflow

### Manual Rollback

```bash
# Revert to previous commit
git revert HEAD
git push

# Or checkout specific version
git checkout <commit-hash>
git push -f
```

---

<div align="center" dir="rtl">

**آماده برای استقرار!** 🚀

</div>
