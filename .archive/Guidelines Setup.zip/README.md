
  # Guidelines Setup

  This is a code bundle for Guidelines Setup. The original project is available at https://www.figma.com/design/T6g31Scu70rwFU9UNq44OC/Guidelines-Setup.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  